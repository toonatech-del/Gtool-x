# GTOOL X

> **100% Offline-First Document Utility & Productivity Workspace**
>
> *Powered by GSD*

GTOOL X is an independent, professional-grade, strictly on-device utility application designed to bring together modern AI-powered optical character recognition (OCR), single-word deep document indexing and retrieval, rich document scanning, custom image compression/resizing, and streamlined invoice formatting.

---

## Key Features & Capabilities

### 1. Unified Deep Indexing & Instant Retrieval (FTS5)
* **Zero Data Silos:** All images, PDFs, notes, formatted bills, and text snippets are processed and structured within a single local SQLite FTS5 database (`universal_search_index`).
* **Deep Single-Word Search:** Find any specific keyword, alphanumeric code, serial number, price token, or date fragment instantly. Supports prefix and wildcard (`MATCH :query || '*'`) query expansion.
* **Smart Citation Extraction:** Displays matching contextual sentences or rows with highlighted search targets, with 1-tap fast copy actions.

### 2. OCR Ingestion Pipeline
* **Full Body Processing:** Utilizes Google ML Kit's highly accurate on-device text recognizer. It parses every single paragraph, block, and visual element instead of stopping at headers.
* **Selectable Transcripts:** Offers scrollable, selectable text review panels with robust instant copying.

### 3. Smart Invoice Maker
* **Frictionless Creation:** Employs a zero-mandatory-field design allowing quick formatting with as little as a single business name or entry.
* **Clean Rendering:** Dynamically hides omitted fields (Bank account info, PAN, GSTIN, custom terms, or signatures) so that generated TXT, DOC, and PDF invoices never display empty labels or placeholder rows.
* **Public Storage Saves:** Saves directly to the public user storage directory at `Documents/GTOOL X/Invoices/` with real-time `MediaScanner` indexing.

### 4. Photo Resizer & Compressor
* **Portal Aspect Presets:** Features built-in aspect ratios and layout requirements for major portals (SSC, UPSC, Banking, Visas, and Exam Portals).
* **Precise Cropping:** Allows exact manual crop adjustment and live target KB size limits with lossless/lossy compression scales.

### 5. Smart Document Scanner
* **Camera Capture:** Captures files via live camera stream or photo pickers, auto-detects edges, applies perspective enhancement, and transforms receipts or certificates into clean high-contrast PDFs.

---

## 🔒 100% Offline Privacy & Data Ownership Policy

GTOOL X is engineered on a strict **zero-telemetry, zero-collection** architecture.

* **No Remote Databases:** All databases, generated receipts, cropped photos, and OCR transcriptions reside strictly within your local device's internal private storage.
* **No Behavioral Tracking:** The app contains absolutely no analytics packages, advertising SDKs, device identifiers, or tracking tokens.
* **No Government Affiliation:** GTOOL X is an independent offline helper utility tool and is not associated with, sponsored by, or endorsed by any public, government, or state exam body.
* **Complete User Sovereignty:** You retain 100% exclusive ownership of your files. Our developers have zero access, visibility, or control over your local records.

---

## 🛠️ Build & Configuration

### Prerequisites
* Android SDK (API Level 24+)
* Java Development Kit (JDK 11+)
* Gradle (Kotlin DSL)

### Secrets Management Configuration
GTOOL X utilizes the `Secrets Gradle Plugin` to inject values securely during build time.

1. Create a `.env` file in the root directory (based on `.env.example`).
2. Add your custom non-committed keys (e.g., project IDs, testing variables) to the local `.env`.
3. To build with specific Firebase services, place your private configuration inside `app/google-services.json` (do not commit to version control).

### Build Release Artifact
To compile and generate a clean release APK/AAB with ProGuard optimization and shrinking enabled:
```bash
gradle :app:assembleRelease
```

---

*GTOOL X is a private document utility workspace.*
**Powered by GSD**
