package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material.icons.outlined.Notifications
import com.example.ui.theme.LocalIsDarkMode
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.theme.AmberWarm
import com.example.ui.theme.DarkIconTint
import com.example.ui.theme.SyncGreen
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSubtitleColor
import com.example.ui.theme.WarmGold
import com.example.ui.theme.WhiteAccentBadge

@Composable
fun TopHeader(
    unreadCount: Int,
    accountName: String = "User",
    userEmail: String = "user@example.com",
    profileImageUrl: String? = null,
    onAvatarClick: () -> Unit,
    onNotificationClick: () -> Unit,
    onThemeToggle: () -> Unit = {},
    onAddClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val isDarkMode = LocalIsDarkMode.current
    val animProgress = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        animProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 650, easing = FastOutSlowInEasing)
        )
    }

    val initials = remember(accountName, userEmail) {
        val nameParts = accountName.trim().split(" ")
        if (nameParts.size >= 2) {
            "${nameParts[0].firstOrNull()?.uppercaseChar() ?: ""}${nameParts[1].firstOrNull()?.uppercaseChar() ?: ""}"
        } else if (accountName.isNotBlank() && !accountName.equals("Google Account", ignoreCase = true)) {
            accountName.take(2).uppercase()
        } else {
            "GA"
        }
    }

    val displayName = remember(accountName, userEmail) {
        if (!accountName.equals("Google Account", ignoreCase = true) && accountName.isNotBlank()) {
            accountName
        } else if (userEmail.contains("@")) {
            userEmail.substringBefore("@").replaceFirstChar { it.uppercase() }
        } else {
            "User"
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 12.dp)
            .testTag("app_header")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Top-Left Upper Area: Stylish 'GTOOL X' title + Mascot Animation + Real Google User Greeting
            Column(modifier = Modifier.weight(1f)) {
                Box {
                    // Mascot Character Overlay
                    GtoolMascotCharacter(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(bottom = 2.dp)
                    )

                    Text(
                        text = "GTOOL X",
                        style = MaterialTheme.typography.displayMedium.copy(
                            fontWeight = FontWeight.ExtraBold, // 800
                            fontSize = 28.sp,
                            letterSpacing = (-0.5).sp,
                            fontFamily = FontFamily.SansSerif,
                            brush = if (isDarkMode) {
                                Brush.linearGradient(
                                    colors = listOf(
                                        Color(0xFFFFFFFF),
                                        WarmGold,
                                        AmberWarm
                                    )
                                )
                            } else {
                                Brush.linearGradient(
                                    colors = listOf(
                                        Color(0xFF000000), // Solid high-contrast black for Light Mode
                                        Color(0xFF1F1F1F),
                                        Color(0xFF333333)
                                    )
                                )
                            }
                        ),
                        modifier = Modifier
                            .graphicsLayer {
                                alpha = animProgress.value
                                scaleX = 0.88f + (0.12f * animProgress.value)
                                scaleY = 0.88f + (0.12f * animProgress.value)
                            }
                            .testTag("top_header_title")
                    )
                }

                Text(
                    text = "Hi, $displayName",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = if (isDarkMode) TextSubtitleColor else Color(0xFF111111),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    ),
                    modifier = Modifier.testTag("user_greeting_text")
                )
            }

            // Top-Right: Theme Toggle Button, Notification Bell & Google Account Avatar
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Sleek Frosted Glass Theme Toggle Button (Sun/Moon)
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(if (isDarkMode) Color(0x33FFFFFF) else Color(0xDDFFFFFF))
                        .border(1.dp, if (isDarkMode) Color(0x55FFFFFF) else Color(0xFFFFFFFF), CircleShape)
                        .zoomOnPress { onThemeToggle() }
                        .testTag("btn_theme_toggle"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isDarkMode) Icons.Outlined.LightMode else Icons.Outlined.DarkMode,
                        contentDescription = if (isDarkMode) "Switch to Light Mode" else "Switch to Dark Mode",
                        tint = if (isDarkMode) WarmGold else Color(0xFF111111),
                        modifier = Modifier.size(20.dp)
                    )
                }
                // High-contrast notification bell
                Box(
                    modifier = Modifier,
                    contentAlignment = Alignment.TopEnd
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(WhiteAccentBadge)
                            .border(1.dp, Color.White, CircleShape)
                            .zoomOnPress { onNotificationClick() }
                            .testTag("notification_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Notifications,
                            contentDescription = "Notifications",
                            tint = DarkIconTint,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    if (unreadCount > 0) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFFF5252))
                                .border(1.5.dp, WhiteAccentBadge, CircleShape)
                        )
                    }
                }

                // Google Profile Avatar
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Color(0x332D2A22))
                        .border(1.5.dp, WarmGold.copy(alpha = 0.8f), CircleShape)
                        .zoomOnPress { onAvatarClick() }
                        .testTag("user_profile_avatar"),
                    contentAlignment = Alignment.Center
                ) {
                    if (!profileImageUrl.isNullOrBlank()) {
                        AsyncImage(
                            model = profileImageUrl,
                            contentDescription = "Google Profile Picture",
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Text(
                            text = initials,
                            color = WarmGold,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.SansSerif
                        )
                    }

                    // Active green status indicator
                    Box(
                        modifier = Modifier
                            .size(9.dp)
                            .align(Alignment.BottomEnd)
                            .clip(CircleShape)
                            .background(SyncGreen)
                            .border(1.dp, Color(0xFF1D1C16), CircleShape)
                    )
                }
            }
        }
    }
}
