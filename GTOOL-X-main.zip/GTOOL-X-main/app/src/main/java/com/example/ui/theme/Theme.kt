package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = AmberWarm,
    onPrimary = DeepCharcoal,
    primaryContainer = EarthBronze,
    onPrimaryContainer = WarmGold,
    secondary = WarmGold,
    onSecondary = DeepCharcoal,
    secondaryContainer = Color(0x33FF9E58),
    onSecondaryContainer = TextPrimary,
    tertiary = SyncGreen,
    onTertiary = DeepCharcoal,
    background = DeepCharcoal,
    onBackground = TextPrimary,
    surface = DeepCharcoalSurface,
    onSurface = TextPrimary,
    surfaceVariant = DeepCharcoalElevated,
    onSurfaceVariant = TextSecondary,
    outline = GlassStroke
)

private val LightColorScheme = lightColorScheme(
    primary = Color(0xFF2563EB),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDBEAFE),
    onPrimaryContainer = Color(0xFF1E40AF),
    secondary = Color(0xFF7C3AED),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFEDE9FE),
    onSecondaryContainer = Color(0xFF5B21B6),
    tertiary = SyncGreen,
    onTertiary = Color.White,
    background = Color(0xFFF8FAFC),
    onBackground = Color(0xFF0F172A),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = Color(0xFF334155),
    outline = Color(0xFFCBD5E1)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
