package com.example.util

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.*
import java.util.regex.Pattern

object ReminderManager {

    data class ParsedReminder(val description: String, val timestamp: Long)

    fun parseReminder(query: String): ParsedReminder? {
        val q = query.lowercase(Locale.getDefault())
        if (!q.contains("remind") && !q.contains("reminder") && !q.contains("yaad dilwa")) return null

        var description = query.replace(Regex("(?i)(remind me to|set reminder|remind me|yaad dilwa dena|yaad dilwa)"), "").trim()
        
        val calendar = Calendar.getInstance()
        var foundTime = false

        // Simple keyword parsing
        if (q.contains("tomorrow") || q.contains("kal")) {
            calendar.add(Calendar.DAY_OF_YEAR, 1)
            foundTime = true
            description = description.replace(Regex("(?i)(tomorrow|kal)"), "").trim()
        } else if (q.contains("next week")) {
            calendar.add(Calendar.DAY_OF_YEAR, 7)
            foundTime = true
            description = description.replace(Regex("(?i)(next week)"), "").trim()
        }

        // Time parsing (e.g. 10 am, 5pm)
        val timePattern = Pattern.compile("(\\d{1,2})\\s*(am|pm|baje)", Pattern.CASE_INSENSITIVE)
        val matcher = timePattern.matcher(q)
        if (matcher.find()) {
            var hour = matcher.group(1)?.toInt() ?: 10
            val amPm = matcher.group(2)
            if (amPm?.lowercase() == "pm" && hour < 12) hour += 12
            if (amPm?.lowercase() == "am" && hour == 12) hour = 0
            calendar.set(Calendar.HOUR_OF_DAY, hour)
            calendar.set(Calendar.MINUTE, 0)
            calendar.set(Calendar.SECOND, 0)
            foundTime = true
            description = description.replace(matcher.group(0) ?: "", "").trim()
        } else if (!foundTime) {
            // Default to 1 hour from now if no time specified
            calendar.add(Calendar.HOUR_OF_DAY, 1)
        }

        // Clean up description: remove "to", "for", etc. at start
        description = description.replace(Regex("^(to|for|ki|ka|ke)\\s+"), "")
        
        return ParsedReminder(
            description = if (description.isBlank()) "Task Reminder" else description,
            timestamp = calendar.timeInMillis
        )
    }

    fun scheduleReminder(context: Context, id: Long, description: String, timestamp: Long) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra("reminder_id", id)
            putExtra("description", description)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            id.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timestamp, pendingIntent)
        } else {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, timestamp, pendingIntent)
        }
    }
}
