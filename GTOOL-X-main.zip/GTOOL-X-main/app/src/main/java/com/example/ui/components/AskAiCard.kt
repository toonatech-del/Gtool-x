package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColor
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.getValue
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AmberGlow
import com.example.ui.theme.AmberWarm
import com.example.ui.theme.GlassStroke
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarmGold

import com.example.ui.theme.LocalIsDarkMode

@Composable
fun AskAiCard(
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    onMicClick: () -> Unit,
    onPromptSuggestionClick: (String) -> Unit = {},
    onSearchSubmit: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val isDarkMode = LocalIsDarkMode.current

    // 6-second continuous infinite edge glow animation
    val infiniteTransition = rememberInfiniteTransition(label = "ask_card_glow_transition")
    val glowColor1 by infiniteTransition.animateColor(
        initialValue = Color(0x66FFFFFF),
        targetValue = AmberWarm,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow_color1"
    )

    val glowColor2 by infiniteTransition.animateColor(
        initialValue = Color(0xFFC084FC), // Soft violet
        targetValue = Color(0x88FFFFFF),
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow_color2"
    )

    val animatedBorderBrush = Brush.sweepGradient(
        colors = listOf(
            glowColor1,
            Color(0xFFC084FC),
            glowColor2,
            AmberWarm,
            glowColor1
        )
    )

    val askHeaderColor = if (isDarkMode) TextPrimary else Color(0xFF000000)
    val inputBgColor = if (isDarkMode) Color(0x22000000) else Color(0xEEFFFFFF)
    val inputBorderBrush = if (isDarkMode) {
        Brush.linearGradient(listOf(Color(0x33FFFFFF), Color(0x10FFFFFF)))
    } else {
        Brush.linearGradient(listOf(Color(0x88000000), Color(0x44000000)))
    }
    val placeholderColor = if (isDarkMode) TextMuted else Color(0xFF4A4A4A)
    val inputTextColor = if (isDarkMode) TextPrimary else Color(0xFF111111)
    val iconTint = if (isDarkMode) (if (searchQuery.isNotEmpty()) Color.White else TextSecondary) else Color(0xFF111111)

    GlassCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag("ask_gsdcall_ai_card"),
        shape = RoundedCornerShape(28.dp),
        borderStrokeWidth = 1.5.dp,
        customBorderBrush = animatedBorderBrush,
        ambientGlowColor = AmberWarm
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Card Header: Prominent, heavy bold display text 'ASK' (font-size: 26px, font-weight: 800)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ASK",
                    style = MaterialTheme.typography.displayMedium.copy(
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 26.sp,
                        letterSpacing = 0.5.sp,
                        fontFamily = FontFamily.SansSerif,
                        color = askHeaderColor
                    )
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Frosted Input Field Box with Search glass icon and Microphone icon
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(inputBgColor)
                    .border(
                        1.dp,
                        inputBorderBrush,
                        RoundedCornerShape(20.dp)
                    )
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Search Glass Icon
                    Icon(
                        imageVector = Icons.Outlined.Search,
                        contentDescription = "Search",
                        tint = iconTint,
                        modifier = Modifier
                            .size(22.dp)
                            .testTag("search_glass_icon")
                    )

                    Spacer(modifier = Modifier.width(10.dp))

                    // Text Field
                    Box(modifier = Modifier.weight(1f)) {
                        if (searchQuery.isEmpty()) {
                            Text(
                                text = "Search notes, bills, or memories...",
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    color = placeholderColor,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            )
                        }

                        BasicTextField(
                            value = searchQuery,
                            onValueChange = onSearchQueryChange,
                            textStyle = MaterialTheme.typography.bodyLarge.copy(
                                color = inputTextColor,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                fontFamily = FontFamily.SansSerif
                            ),
                            cursorBrush = SolidColor(if (isDarkMode) Color.White else Color.Black),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            keyboardActions = KeyboardActions(onSearch = {
                                if (searchQuery.isNotBlank()) onSearchSubmit(searchQuery)
                            }),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("search_input_field")
                        )
                    }

                    // Clear button if text is present
                    AnimatedVisibility(
                        visible = searchQuery.isNotEmpty(),
                        enter = fadeIn(),
                        exit = fadeOut()
                    ) {
                        IconButton(
                            onClick = { onSearchQueryChange("") },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Clear search",
                                tint = TextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // White Circular Search/Mic Trigger Button
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color.White)
                            .border(1.dp, Color.White, CircleShape)
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = ripple(color = Color.Black.copy(alpha = 0.2f)),
                                onClick = onMicClick
                            )
                            .testTag("microphone_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Mic,
                            contentDescription = "Voice Input",
                            tint = Color(0xFF1D1C16),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}
