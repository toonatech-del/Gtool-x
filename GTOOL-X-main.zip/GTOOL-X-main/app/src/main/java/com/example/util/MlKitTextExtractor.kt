package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Log
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.InputStream
import kotlin.coroutines.resume

object MlKitTextExtractor {

    private const val TAG = "MlKitTextExtractor"

    // Real on-device Google ML Kit Text Recognition client using default options
    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    /**
     * Extracts full text line-by-line from a Bitmap on-device with zero internet dependency.
     */
    suspend fun extractTextFromBitmap(bitmap: Bitmap): String = suspendCancellableCoroutine { continuation ->
        try {
            val inputImage = InputImage.fromBitmap(bitmap, 0)
            recognizer.process(inputImage)
                .addOnSuccessListener { visionText ->
                    val lines = mutableListOf<String>()
                    for (block in visionText.textBlocks) {
                        for (line in block.lines) {
                            val lineText = line.text.trim()
                            if (lineText.isNotBlank()) {
                                lines.add(lineText)
                            }
                        }
                    }
                    val fullText = if (lines.isNotEmpty()) {
                        lines.joinToString("\n")
                    } else {
                        visionText.text.trim()
                    }
                    continuation.resume(fullText)
                }
                .addOnFailureListener { e ->
                    Log.e(TAG, "ML Kit text recognition failed on bitmap", e)
                    continuation.resume("")
                }
        } catch (e: Exception) {
            Log.e(TAG, "Exception initializing ML Kit extraction on bitmap", e)
            continuation.resume("")
        }
    }

    /**
     * Extracts full text line-by-line from an Image Uri on-device with zero internet dependency.
     */
    suspend fun extractTextFromUri(context: Context, uri: Uri): String = suspendCancellableCoroutine { continuation ->
        try {
            val inputImage = InputImage.fromFilePath(context, uri)
            recognizer.process(inputImage)
                .addOnSuccessListener { visionText ->
                    val lines = mutableListOf<String>()
                    for (block in visionText.textBlocks) {
                        for (line in block.lines) {
                            val lineText = line.text.trim()
                            if (lineText.isNotBlank()) {
                                lines.add(lineText)
                            }
                        }
                    }
                    val fullText = if (lines.isNotEmpty()) {
                        lines.joinToString("\n")
                    } else {
                        visionText.text.trim()
                    }
                    continuation.resume(fullText)
                }
                .addOnFailureListener { e ->
                    Log.e(TAG, "ML Kit text recognition failed on uri: $uri", e)
                    // Fallback to bitmap decode if needed
                    val fallbackBitmap = decodeSampledBitmapFromUri(context, uri)
                    if (fallbackBitmap != null) {
                        val fallbackImage = InputImage.fromBitmap(fallbackBitmap, 0)
                        recognizer.process(fallbackImage)
                            .addOnSuccessListener { fallbackVisionText ->
                                continuation.resume(fallbackVisionText.text.trim())
                            }
                            .addOnFailureListener {
                                continuation.resume("")
                            }
                    } else {
                        continuation.resume("")
                    }
                }
        } catch (e: Exception) {
            Log.e(TAG, "Exception initializing ML Kit extraction on uri", e)
            continuation.resume("")
        }
    }

    private fun decodeSampledBitmapFromUri(context: Context, uri: Uri): Bitmap? {
        var inputStream: InputStream? = null
        return try {
            inputStream = context.contentResolver.openInputStream(uri)
            val options = BitmapFactory.Options().apply {
                inSampleSize = 2
            }
            BitmapFactory.decodeStream(inputStream, null, options)
        } catch (e: Exception) {
            null
        } finally {
            inputStream?.close()
        }
    }
}
