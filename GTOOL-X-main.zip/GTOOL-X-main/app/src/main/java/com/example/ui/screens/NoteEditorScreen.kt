package com.example.ui.screens

import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.CameraAlt
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.ui.components.AmbientLightingBackground
import com.example.ui.components.GlassCard
import com.example.ui.theme.AmberGlow
import com.example.ui.theme.AmberWarm
import com.example.ui.theme.GlassStroke
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarmGold
import kotlinx.coroutines.launch

/**
 * 100% Clean, empty, user-input-ready Notepad / Note Editor screen for gsdcall ai.
 * Features:
 * - Empty title field with placeholder: 'Note Title...'
 * - Blank expansive editable textarea with placeholder: 'Write your note here...'
 * - Dynamic tag management with '+ Add Tag' option
 * - Bottom action controls: Take Photo, Upload Image, AI Semantic Search toggle (default ON), and Save Note
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteEditorScreen(
    initialTitle: String = "",
    initialContent: String = "",
    initialTags: List<String> = emptyList(),
    initialAttachmentUri: String? = null,
    onBackClick: () -> Unit,
    onSaveSuccess: (title: String, bullets: List<String>) -> Unit = { _, _ -> },
    onSaveFullNote: (title: String, content: String, tags: List<String>, hasAttachment: Boolean, includeInSemanticSearch: Boolean, attachmentUri: String?) -> Unit = { _, _, _, _, _, _ -> },
    onOpenScanner: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var title by remember(initialTitle) { mutableStateOf(initialTitle) }
    var noteContent by remember(initialContent) { mutableStateOf(initialContent) }

    // Dynamic tag list initialized from passed-in tags or empty
    val tags = remember(initialTags) {
        mutableStateListOf<String>().apply {
            addAll(initialTags)
        }
    }

    // Attachment state
    var hasAttachment by remember(initialAttachmentUri) { mutableStateOf(initialAttachmentUri != null) }
    var attachedImageUri by remember(initialAttachmentUri) { mutableStateOf(initialAttachmentUri) }
    var attachedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var attachedDocName by remember(initialAttachmentUri) {
        mutableStateOf(if (initialAttachmentUri != null) "Attached_Image.jpg" else "")
    }
    var showPhotoPreviewModal by remember { mutableStateOf(false) }
    var showAddTagDialog by remember { mutableStateOf(false) }

    // Toggle switch: 'Include in AI Semantic Search' (default ON)
    var includeInSemanticSearch by remember { mutableStateOf(true) }

    androidx.activity.compose.BackHandler {
        onBackClick()
    }

    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    // Activity result launcher for gallery upload
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            attachedImageUri = uri.toString()
            attachedBitmap = null
            hasAttachment = true
            attachedDocName = "Image_${System.currentTimeMillis() % 10000}.jpg"
            coroutineScope.launch {
                snackbarHostState.showSnackbar("Photo attached from gallery 🖼️")
            }
        }
    }

    // Activity result launcher for camera capture
    val takePhotoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap ->
        if (bitmap != null) {
            attachedBitmap = bitmap
            attachedImageUri = null
            hasAttachment = true
            attachedDocName = "Camera_${System.currentTimeMillis() % 10000}.jpg"
            coroutineScope.launch {
                snackbarHostState.showSnackbar("Photo captured and attached 📸")
            }
        }
    }

    fun performSaveNote() {
        val finalTitle = when {
            title.isNotBlank() -> title.trim()
            noteContent.isNotBlank() -> {
                val firstLine = noteContent.lines().firstOrNull { it.isNotBlank() }?.trim() ?: "Untitled Note"
                if (firstLine.length > 40) firstLine.take(40) + "..." else firstLine
            }
            else -> "Untitled Note"
        }
        val bulletsList = noteContent.lines().filter { it.isNotBlank() }
        onSaveSuccess(finalTitle, bulletsList)
        onSaveFullNote(
            finalTitle,
            noteContent,
            tags.toList(),
            hasAttachment,
            includeInSemanticSearch,
            attachedImageUri
        )
    }

    AmbientLightingBackground {
        Scaffold(
            containerColor = Color.Transparent,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            modifier = modifier
                .fillMaxSize()
                .testTag("note_editor_screen"),
            topBar = {
                NoteEditorTopBar(
                    onBackClick = onBackClick,
                    onSaveClick = {
                        performSaveNote()
                    }
                )
            },
            bottomBar = {
                NoteEditorBottomActionDeck(
                    onTakePhoto = {
                        takePhotoLauncher.launch(null)
                    },
                    onUploadImage = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    tags = tags,
                    onRemoveTag = { tag ->
                        tags.remove(tag)
                    },
                    onAddTagClick = {
                        showAddTagDialog = true
                    },
                    includeInSemanticSearch = includeInSemanticSearch,
                    onToggleSemanticSearch = { includeInSemanticSearch = it },
                    onSaveNote = {
                        performSaveNote()
                    }
                )
            }
        ) { paddingValues ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentPadding = PaddingValues(
                    start = 20.dp,
                    end = 20.dp,
                    top = 12.dp,
                    bottom = 24.dp
                )
            ) {
                // Top Input: Clean title field with placeholder 'Note Title...'
                item(key = "note_title_input_item") {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        BasicTextField(
                            value = title,
                            onValueChange = { title = it },
                            textStyle = TextStyle(
                                color = TextPrimary,
                                fontSize = 26.sp,
                                fontWeight = FontWeight.ExtraBold,
                                fontFamily = FontFamily.SansSerif,
                                lineHeight = 34.sp,
                                letterSpacing = (-0.5).sp
                            ),
                            cursorBrush = SolidColor(AmberWarm),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("note_title_input"),
                            decorationBox = { innerTextField ->
                                if (title.isEmpty()) {
                                    Text(
                                        text = "Note Title...",
                                        style = TextStyle(
                                            color = TextMuted,
                                            fontSize = 26.sp,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.SansSerif,
                                            letterSpacing = (-0.4).sp
                                        )
                                    )
                                }
                                innerTextField()
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                }

                // Expansive Blank Editable Textarea Card
                item(key = "note_body_editor_area") {
                    GlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("note_body_card"),
                        shape = RoundedCornerShape(22.dp),
                        borderStrokeWidth = 1.dp,
                        borderColorList = listOf(
                            Color(0x95FFFFFF),
                            Color(0x28FFFFFF),
                            Color(0x50FFFFFF)
                        ),
                        backgroundGradient = listOf(
                            Color(0x24FFFFFF),
                            Color(0x12FFFFFF),
                            Color(0x0AFFFFFF)
                        ),
                        ambientGlowColor = AmberWarm
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(18.dp)
                        ) {
                            BasicTextField(
                                value = noteContent,
                                onValueChange = { noteContent = it },
                                minLines = 14,
                                textStyle = TextStyle(
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 16.sp,
                                    lineHeight = 26.sp,
                                    fontFamily = FontFamily.SansSerif,
                                    color = TextPrimary
                                ),
                                cursorBrush = SolidColor(AmberWarm),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("note_body_input"),
                                decorationBox = { innerTextField ->
                                    if (noteContent.isEmpty()) {
                                        Text(
                                            text = "Write your note here...",
                                            style = TextStyle(
                                                color = TextMuted,
                                                fontSize = 16.sp,
                                                lineHeight = 26.sp,
                                                fontFamily = FontFamily.SansSerif
                                            )
                                        )
                                    }
                                    innerTextField()
                                }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                }

                // Attached Photo Card: Appears below text when photo is taken or uploaded
                if (hasAttachment) {
                    item(key = "attached_photo_card") {
                        AttachedPhotoCard(
                            docName = attachedDocName.ifBlank { "Attached Photo" },
                            bitmap = attachedBitmap,
                            imageUri = attachedImageUri,
                            onPreviewClick = { showPhotoPreviewModal = true },
                            onRemoveClick = {
                                hasAttachment = false
                                attachedBitmap = null
                                attachedImageUri = null
                                coroutineScope.launch {
                                    snackbarHostState.showSnackbar("Attached photo removed")
                                }
                            }
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
            }
        }
    }

    // Modal preview for attached photo
    if (showPhotoPreviewModal && hasAttachment) {
        AttachedPhotoPreviewModal(
            fileName = attachedDocName.ifBlank { "Attached Photo" },
            bitmap = attachedBitmap,
            imageUri = attachedImageUri,
            onDismiss = { showPhotoPreviewModal = false }
        )
    }

    // Dynamic Add Tag Dialog
    if (showAddTagDialog) {
        AddTagDialog(
            onDismiss = { showAddTagDialog = false },
            onAddTag = { newTag ->
                val formatted = if (newTag.startsWith("#")) newTag.trim() else "#${newTag.trim()}"
                if (formatted.length > 1 && !tags.contains(formatted)) {
                    tags.add(formatted)
                }
                showAddTagDialog = false
            }
        )
    }
}

/**
 * Top Navigation Bar: Left back-arrow icon and right-side glowing frosted pill button 'Save'.
 */
@Composable
private fun NoteEditorTopBar(
    onBackClick: () -> Unit,
    onSaveClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.statusBars)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Left Back-Arrow Icon
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(Color(0x22FFFFFF))
                .border(1.dp, GlassStroke, CircleShape)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = ripple(color = Color.White.copy(alpha = 0.3f)),
                    onClick = onBackClick
                )
                .testTag("note_editor_back_button"),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
                contentDescription = "Back",
                tint = TextPrimary,
                modifier = Modifier.size(20.dp)
            )
        }

        // Center Title Indicator
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(AmberWarm)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Notepad",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 17.sp,
                    fontFamily = FontFamily.SansSerif,
                    letterSpacing = (-0.2).sp,
                    color = TextPrimary
                ),
                modifier = Modifier.testTag("note_editor_header_title")
            )
        }

        // Right-side glowing frosted pill button 'Save'
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(22.dp))
                .background(
                    Brush.horizontalGradient(
                        listOf(AmberWarm, AmberGlow)
                    )
                )
                .border(
                    1.dp,
                    Color.White.copy(alpha = 0.5f),
                    RoundedCornerShape(22.dp)
                )
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = ripple(color = Color.White.copy(alpha = 0.4f)),
                    onClick = onSaveClick
                )
                .padding(horizontal = 18.dp, vertical = 9.dp)
                .testTag("note_editor_top_save_button"),
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Outlined.Check,
                    contentDescription = null,
                    tint = Color(0xFF0F0E11),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Save",
                    style = MaterialTheme.typography.labelLarge.copy(
                        color = Color(0xFF0F0E11),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 14.sp
                    ),
                    modifier = Modifier.testTag("save_button_text")
                )
            }
        }
    }
}

/**
 * Fixed Bottom Action Deck:
 * - 📷 Camera button ('Take Photo')
 * - 📁 Upload button ('Upload Image')
 * - Dynamic tag area showing active tags and '+ Add Tag' option
 * - Toggle switch for 'Include in AI Semantic Search' (default ON)
 * - Prominent full-width glowing pill button 'Save Note'
 */
@Composable
private fun NoteEditorBottomActionDeck(
    onTakePhoto: () -> Unit,
    onUploadImage: () -> Unit,
    tags: List<String>,
    onRemoveTag: (String) -> Unit,
    onAddTagClick: () -> Unit,
    includeInSemanticSearch: Boolean,
    onToggleSemanticSearch: (Boolean) -> Unit,
    onSaveNote: () -> Unit,
    modifier: Modifier = Modifier
) {
    GlassCard(
        modifier = modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars)
            .testTag("note_bottom_action_deck"),
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        borderStrokeWidth = 1.dp,
        borderColorList = listOf(
            Color(0x95FFFFFF),
            Color(0x35FFFFFF),
            Color(0x60FFFFFF)
        ),
        backgroundGradient = listOf(
            Color(0x351E1822),
            Color(0x30151119),
            Color(0x40100C13)
        ),
        ambientGlowColor = AmberWarm
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Row 1: Camera ('Take Photo') and Upload ('Upload Image') buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // 📷 Camera button ('Take Photo')
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0x22FFFFFF))
                        .border(1.dp, GlassStroke, RoundedCornerShape(16.dp))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = ripple(color = AmberWarm.copy(alpha = 0.35f)),
                            onClick = onTakePhoto
                        )
                        .padding(vertical = 12.dp, horizontal = 10.dp)
                        .testTag("take_photo_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.CameraAlt,
                            contentDescription = "Take Photo",
                            tint = AmberWarm,
                            modifier = Modifier.size(17.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Take Photo",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        )
                    }
                }

                // 📁 Upload button ('Upload Image')
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0x22FFFFFF))
                        .border(1.dp, GlassStroke, RoundedCornerShape(16.dp))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = ripple(color = AmberWarm.copy(alpha = 0.35f)),
                            onClick = onUploadImage
                        )
                        .padding(vertical = 12.dp, horizontal = 10.dp)
                        .testTag("upload_image_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.FolderOpen,
                            contentDescription = "Upload Image",
                            tint = Color(0xFF38BDF8),
                            modifier = Modifier.size(17.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Upload Image",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        )
                    }
                }
            }

            // Row 2: Dynamic Tag Area (Empty tag area showing option: '+ Add Tag')
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("note_tags_row"),
                verticalAlignment = Alignment.CenterVertically
            ) {
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    items(tags, key = { it }) { tag ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color(0x35FFA767))
                                .border(1.dp, AmberWarm, RoundedCornerShape(16.dp))
                                .padding(start = 12.dp, end = 8.dp, top = 6.dp, bottom = 6.dp)
                                .testTag("tag_pill_${tag.removePrefix("#")}")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = tag,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = AmberWarm,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Box(
                                    modifier = Modifier
                                        .size(16.dp)
                                        .clip(CircleShape)
                                        .background(Color(0x30FFFFFF))
                                        .clickable { onRemoveTag(tag) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Remove Tag",
                                        tint = TextPrimary,
                                        modifier = Modifier.size(10.dp)
                                    )
                                }
                            }
                        }
                    }

                    item {
                        // Dynamic '+ Add Tag' Button
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color(0x1AFFFFFF))
                                .border(1.dp, GlassStroke, RoundedCornerShape(16.dp))
                                .clickable(
                                    interactionSource = remember { MutableInteractionSource() },
                                    indication = ripple(color = AmberWarm.copy(alpha = 0.35f)),
                                    onClick = onAddTagClick
                                )
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                                .testTag("add_tag_button")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Outlined.Add,
                                    contentDescription = "Add Tag",
                                    tint = AmberWarm,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "+ Add Tag",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = AmberWarm,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                )
                            }
                        }
                    }
                }
            }

            // Row 3: Toggle switch card for 'Include in AI Semantic Search' (default ON)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0x18FFFFFF))
                    .border(1.dp, GlassStroke, RoundedCornerShape(16.dp))
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0x28FF9E58)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.AutoAwesome,
                                contentDescription = null,
                                tint = AmberWarm,
                                modifier = Modifier.size(15.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Text(
                                text = "Include in AI Semantic Search",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = TextPrimary
                                )
                            )
                            Text(
                                text = "Index note for instant semantic search",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = TextSecondary,
                                    fontSize = 10.sp
                                )
                            )
                        }
                    }

                    Switch(
                        checked = includeInSemanticSearch,
                        onCheckedChange = onToggleSemanticSearch,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF161219),
                            checkedTrackColor = AmberWarm,
                            uncheckedThumbColor = TextMuted,
                            uncheckedTrackColor = Color(0x30FFFFFF)
                        ),
                        modifier = Modifier.testTag("semantic_search_toggle")
                    )
                }
            }

            // Row 4: Prominent glowing full-width pill button 'Save Note'
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(AmberWarm, AmberGlow)
                        )
                    )
                    .border(
                        1.dp,
                        Color.White.copy(alpha = 0.5f),
                        RoundedCornerShape(20.dp)
                    )
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = ripple(color = Color.White.copy(alpha = 0.35f)),
                        onClick = onSaveNote
                    )
                    .padding(vertical = 14.dp)
                    .testTag("save_note_button"),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Check,
                        contentDescription = null,
                        tint = Color(0xFF0F0E11),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Save Note",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = Color(0xFF0F0E11),
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 15.sp,
                            letterSpacing = 0.2.sp
                        )
                    )
                }
            }
        }
    }
}

/**
 * Clean Attached Photo Card displaying below the text editor.
 */
@Composable
private fun AttachedPhotoCard(
    docName: String,
    bitmap: Bitmap?,
    imageUri: String?,
    onPreviewClick: () -> Unit,
    onRemoveClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    GlassCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag("note_attached_photo"),
        shape = RoundedCornerShape(18.dp),
        borderStrokeWidth = 1.dp,
        borderColorList = listOf(
            Color(0x80FFFFFF),
            Color(0x22FFFFFF),
            Color(0x40FFFFFF)
        ),
        backgroundGradient = listOf(
            Color(0x24FFFFFF),
            Color(0x12FFFFFF),
            Color(0x0AFFFFFF)
        ),
        ambientGlowColor = AmberWarm
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .weight(1f)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = ripple(color = AmberWarm.copy(alpha = 0.2f)),
                        onClick = onPreviewClick
                    )
            ) {
                // Photo Thumbnail
                Box(
                    modifier = Modifier
                        .size(width = 54.dp, height = 54.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0x20FFFFFF))
                        .border(1.dp, GlassStroke, RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (bitmap != null) {
                        Image(
                            bitmap = bitmap.asImageBitmap(),
                            contentDescription = "Attached thumbnail",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else if (imageUri != null) {
                        AsyncImage(
                            model = imageUri,
                            contentDescription = "Attached thumbnail",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Outlined.Image,
                            contentDescription = null,
                            tint = AmberWarm,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = "Attached Photo",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = TextPrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = docName,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    )
                    Text(
                        text = "Tap to view full preview",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = WarmGold,
                            fontSize = 10.sp
                        )
                    )
                }
            }

            // Remove Button
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(Color(0x1AFFFFFF))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = ripple(color = Color.Red.copy(alpha = 0.3f)),
                        onClick = onRemoveClick
                    )
                    .testTag("remove_attached_photo_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Remove Photo",
                    tint = TextMuted,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

/**
 * Preview modal for attached photo.
 */
@Composable
private fun AttachedPhotoPreviewModal(
    fileName: String,
    bitmap: Bitmap?,
    imageUri: String?,
    onDismiss: () -> Unit
) {
    androidx.activity.compose.BackHandler {
        onDismiss()
    }

    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xFF14121A))
                .border(1.dp, GlassStroke, RoundedCornerShape(24.dp))
                .padding(20.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Photo Attachment",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Text(
                            text = fileName,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 200.dp, max = 360.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF1E1B26))
                        .border(1.dp, GlassStroke, RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (bitmap != null) {
                        Image(
                            bitmap = bitmap.asImageBitmap(),
                            contentDescription = "Full photo preview",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Fit
                        )
                    } else if (imageUri != null) {
                        AsyncImage(
                            model = imageUri,
                            contentDescription = "Full photo preview",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Fit
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Outlined.Image,
                            contentDescription = null,
                            tint = AmberWarm,
                            modifier = Modifier.size(48.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0x22FFFFFF))
                        .border(1.dp, GlassStroke, RoundedCornerShape(14.dp))
                        .clickable(onClick = onDismiss)
                        .padding(horizontal = 20.dp, vertical = 10.dp)
                ) {
                    Text(
                        text = "Close Preview",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}

/**
 * Clean dynamic dialog for adding a new tag.
 */
@Composable
private fun AddTagDialog(
    onDismiss: () -> Unit,
    onAddTag: (String) -> Unit
) {
    var tagInput by remember { mutableStateOf("") }
    val suggestions = listOf("work", "ideas", "study", "personal", "finance", "meeting")

    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .clip(RoundedCornerShape(22.dp))
                .background(Color(0xFF181520))
                .border(1.dp, GlassStroke, RoundedCornerShape(22.dp))
                .padding(20.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Add Tag",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        fontSize = 18.sp
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = tagInput,
                    onValueChange = { tagInput = it },
                    placeholder = {
                        Text("e.g. work, ideas, meeting", color = TextMuted, fontSize = 14.sp)
                    },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = AmberWarm,
                        unfocusedBorderColor = Color(0x40FFFFFF),
                        cursorColor = AmberWarm
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("tag_input_field")
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Suggestions:",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                )

                Spacer(modifier = Modifier.height(6.dp))

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(suggestions) { sugg ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0x20FFFFFF))
                                .border(1.dp, Color(0x30FFFFFF), RoundedCornerShape(12.dp))
                                .clickable {
                                    tagInput = sugg
                                }
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "#$sugg",
                                color = WarmGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = TextSecondary)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (tagInput.isNotBlank()) {
                                onAddTag(tagInput)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AmberWarm,
                            contentColor = Color(0xFF0F0E11)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("confirm_add_tag_button")
                    ) {
                        Text("Add Tag", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
