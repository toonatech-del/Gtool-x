package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.GraphicEq
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.PictureAsPdf
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.ThumbUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ChatMessage
import com.example.model.CitationSource
import com.example.model.ItemType
import com.example.model.MessageSender
import com.example.ui.components.AmbientLightingBackground
import com.example.ui.components.CitationDetailDialog
import com.example.ui.components.GlassCard
import com.example.ui.theme.AmberGlow
import com.example.ui.theme.AmberWarm
import com.example.ui.theme.GlassStroke
import com.example.ui.theme.NoteYellow
import com.example.ui.theme.PdfRed
import com.example.ui.theme.SyncGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarmGold
import kotlinx.coroutines.launch

@Composable
fun AiSearchScreen(
    messages: List<ChatMessage>,
    onSendMessage: (String) -> Unit,
    onBackClick: () -> Unit,
    onVoiceClick: () -> Unit,
    onAddMemoryClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var inputText by remember { mutableStateOf("") }
    var selectedCitation by remember { mutableStateOf<CitationSource?>(null) }
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    AmbientLightingBackground {
        Scaffold(
            containerColor = Color.Transparent,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            modifier = modifier
                .fillMaxSize()
                .testTag("ai_search_screen"),
            topBar = {
                AiSearchTopBar(
                    onBackClick = onBackClick,
                    onAddMemoryClick = onAddMemoryClick
                )
            },
            bottomBar = {
                // Sticky bottom input bar with clean input field and microphone icon
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .imePadding()
                ) {
                    // Sticky Input Bar
                    StickyBottomInputBar(
                        inputText = inputText,
                        onInputTextChange = { inputText = it },
                        onSendClick = {
                            if (inputText.isNotBlank()) {
                                onSendMessage(inputText.trim())
                                inputText = ""
                            }
                        },
                        onVoiceClick = onVoiceClick
                    )
                }
            }
        ) { paddingValues ->
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                if (messages.isEmpty()) {
                    item(key = "empty_chat_state") {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            GlassCard(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("ai_search_empty_state"),
                                shape = RoundedCornerShape(24.dp),
                                ambientGlowColor = AmberWarm
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(28.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(54.dp)
                                            .clip(CircleShape)
                                            .background(Color(0x24FF9E58))
                                            .border(1.dp, AmberWarm.copy(alpha = 0.5f), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.AutoAwesome,
                                            contentDescription = null,
                                            tint = AmberWarm,
                                            modifier = Modifier.size(26.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Text(
                                        text = "Neural Memory Assistant",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = TextPrimary,
                                            fontSize = 17.sp
                                        )
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "Ask anything about your saved memories. Synthesize notes, find key dates, or extract info privately.",
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            color = TextSecondary,
                                            fontSize = 13.sp,
                                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                        )
                                    )
                                }
                            }
                        }
                    }
                }

                items(messages, key = { it.id }) { message ->
                    when (message.sender) {
                        MessageSender.USER -> {
                            UserChatBubble(
                                text = message.text,
                                timestamp = message.timestamp
                            )
                        }
                        MessageSender.AI -> {
                            AiResponseCard(
                                message = message,
                                onCitationClick = { citation ->
                                    selectedCitation = citation
                                },
                                onCopyClick = {
                                    coroutineScope.launch {
                                        snackbarHostState.showSnackbar("Copied answer to clipboard")
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    // Citation Detail Dialog
    if (selectedCitation != null) {
        CitationDetailDialog(
            citation = selectedCitation!!,
            onDismiss = { selectedCitation = null }
        )
    }
}

/**
 * Top Header: Back button, large bold title 'AI Search', and model status indicator
 */
@Composable
private fun AiSearchTopBar(
    onBackClick: () -> Unit,
    onAddMemoryClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.statusBars)
            .padding(horizontal = 20.dp, vertical = 10.dp)
            .testTag("ai_search_top_bar")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Back Button with frosted circular styling
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Color(0x22FFFFFF))
                    .border(1.dp, GlassStroke, CircleShape)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = ripple(color = Color.White.copy(alpha = 0.3f)),
                        onClick = onBackClick
                    )
                    .testTag("back_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
                    contentDescription = "Back to Workspace",
                    tint = TextPrimary,
                    modifier = Modifier.size(20.dp)
                )
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // AI Status Pill
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(Color(0x24FF9E58))
                        .border(
                            1.dp,
                            Brush.linearGradient(
                                listOf(AmberWarm.copy(alpha = 0.6f), AmberGlow.copy(alpha = 0.2f))
                            ),
                            RoundedCornerShape(20.dp)
                        )
                        .padding(horizontal = 12.dp, vertical = 5.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(SyncGreen)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Neural Search Active",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = WarmGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                    }
                }

                // Add Memory Button
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color(0x28FF9E58))
                        .border(
                            1.dp,
                            Brush.linearGradient(
                                listOf(Color(0x80FFB87E), Color(0x30FFA767))
                            ),
                            CircleShape
                        )
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = ripple(color = AmberWarm.copy(alpha = 0.3f)),
                            onClick = onAddMemoryClick
                        )
                        .testTag("ai_search_add_memory_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Add,
                        contentDescription = "Add Memory",
                        tint = AmberWarm,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Large bold headline font: 'AI Search'
        Text(
            text = "AI Search",
            style = MaterialTheme.typography.displayLarge.copy(
                fontWeight = FontWeight.ExtraBold,
                fontSize = 32.sp,
                letterSpacing = (-0.6).sp,
                fontFamily = FontFamily.SansSerif,
                color = TextPrimary
            ),
            modifier = Modifier.testTag("ai_search_title")
        )

        Spacer(modifier = Modifier.height(2.dp))

        Text(
            text = "Conversational search across all your indexed notes & documents",
            style = MaterialTheme.typography.bodyMedium.copy(
                color = TextSecondary,
                fontSize = 13.sp
            )
        )
    }
}

/**
 * User Chat Bubble with text: "Find everything related to my bike."
 */
@Composable
private fun UserChatBubble(
    text: String,
    timestamp: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("user_chat_bubble_container"),
        horizontalAlignment = Alignment.End
    ) {
        Box(
            modifier = Modifier
                .clip(
                    RoundedCornerShape(
                        topStart = 20.dp,
                        topEnd = 20.dp,
                        bottomStart = 20.dp,
                        bottomEnd = 4.dp
                    )
                )
                .background(
                    Brush.linearGradient(
                        listOf(
                            Color(0x55FF9E58),
                            Color(0x35E8833A),
                            Color(0x4038251A)
                        )
                    )
                )
                .border(
                    1.dp,
                    Brush.linearGradient(
                        listOf(
                            Color(0x80FFB87E),
                            Color(0x30FFA767),
                            Color(0x60FFB87E)
                        )
                    ),
                    RoundedCornerShape(
                        topStart = 20.dp,
                        topEnd = 20.dp,
                        bottomStart = 20.dp,
                        bottomEnd = 4.dp
                    )
                )
                .padding(horizontal = 18.dp, vertical = 14.dp)
                .testTag("user_chat_bubble")
        ) {
            Text(
                text = text,
                style = MaterialTheme.typography.titleMedium.copy(
                    color = TextPrimary,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                    lineHeight = 22.sp
                )
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = timestamp,
            style = MaterialTheme.typography.labelSmall.copy(
                color = TextMuted,
                fontSize = 10.sp
            ),
            modifier = Modifier.padding(end = 4.dp)
        )
    }
}

/**
 * Prominent frosted glass response card from 'gsdcall ai'
 * stating: "Bike service was done on 14 August at Hero Care. Total bill was ₹1,850 and next service is due on 14 November."
 * Directly attached below this answer are two frosted citation cards showing the source names:
 * 'Bike_Service_Receipt.pdf' and 'Maintenance_Log_Note' with distinct PDF and note mini-icons.
 */
@Composable
private fun AiResponseCard(
    message: ChatMessage,
    onCitationClick: (CitationSource) -> Unit,
    onCopyClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("ai_response_card_container"),
        horizontalAlignment = Alignment.Start
    ) {
        GlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("gsdcall_ai_response_card"),
            shape = RoundedCornerShape(26.dp),
            borderStrokeWidth = 1.dp,
            borderColorList = listOf(
                Color(0x66FFFFFF),
                Color(0x1EFFFFFF),
                Color(0x40FFFFFF)
            ),
            backgroundGradient = listOf(
                Color(0x28FFFFFF),
                Color(0x16FFFFFF),
                Color(0x0EFFFFFF)
            ),
            ambientGlowColor = AmberWarm
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                // Header: Branding 'gsdcall ai' with logo & sparkle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // AI Brand Sparkle Avatar
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    Brush.radialGradient(
                                        listOf(AmberWarm, AmberGlow)
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.AutoAwesome,
                                contentDescription = null,
                                tint = Color(0xFF0F0E11),
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "gsdcall ai",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = TextPrimary
                                    )
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color(0x24FF9E58))
                                        .padding(horizontal = 5.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "SYNTHESIS",
                                        color = WarmGold,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Text(
                                text = "Indexed Memory Retrieval",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = TextMuted,
                                    fontSize = 10.sp
                                )
                            )
                        }
                    }

                    // Copy action button
                    IconButton(
                        onClick = onCopyClick,
                        modifier = Modifier.size(30.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.ContentCopy,
                            contentDescription = "Copy text",
                            tint = TextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // The prominent AI Answer Text
                Text(
                    text = message.text,
                    style = MaterialTheme.typography.bodyLarge.copy(
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Normal,
                        lineHeight = 23.sp,
                        fontFamily = FontFamily.SansSerif
                    ),
                    modifier = Modifier.testTag("ai_answer_text")
                )

                // Directly attached below this answer are two frosted citation cards
                if (message.citations.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(18.dp))

                    // Sources separator label
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "SOURCES & CITATIONS",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = TextMuted,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.8.sp
                            )
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(0.5.dp)
                                .background(Color(0x22FFFFFF))
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Two frosted citation cards directly attached below
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.testTag("citation_cards_column")
                    ) {
                        message.citations.forEach { citation ->
                            FrostedCitationCard(
                                citation = citation,
                                onClick = { onCitationClick(citation) }
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = message.timestamp,
            style = MaterialTheme.typography.labelSmall.copy(
                color = TextMuted,
                fontSize = 10.sp
            ),
            modifier = Modifier.padding(start = 6.dp)
        )
    }
}

/**
 * Frosted citation card showing source name with distinct PDF and note mini-icons
 */
@Composable
private fun FrostedCitationCard(
    citation: CitationSource,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val (typeColor, typeIcon) = if (citation.type == ItemType.PDF) {
        Pair(PdfRed, Icons.Outlined.PictureAsPdf)
    } else {
        Pair(NoteYellow, Icons.Outlined.Description)
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(
                Brush.linearGradient(
                    listOf(
                        Color(0x2AFFFFFF),
                        Color(0x14FFFFFF),
                        Color(0x0EFFFFFF)
                    )
                )
            )
            .border(
                1.dp,
                Brush.linearGradient(
                    listOf(
                        Color(0x55FFFFFF),
                        Color(0x18FFFFFF),
                        Color(0x35FFFFFF)
                    )
                ),
                RoundedCornerShape(16.dp)
            )
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(color = typeColor.copy(alpha = 0.25f)),
                onClick = onClick
            )
            .padding(horizontal = 14.dp, vertical = 11.dp)
            .testTag("citation_card_${citation.id}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // Distinct mini-icon box for PDF or Note
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(9.dp))
                        .background(typeColor.copy(alpha = 0.22f))
                        .border(
                            1.dp,
                            typeColor.copy(alpha = 0.45f),
                            RoundedCornerShape(9.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = typeIcon,
                        contentDescription = citation.type.label,
                        tint = typeColor,
                        modifier = Modifier.size(16.dp)
                    )
                }

                Spacer(modifier = Modifier.width(11.dp))

                Column {
                    Text(
                        text = citation.title,
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = TextPrimary
                        ),
                        modifier = Modifier.testTag("citation_title_${citation.id}")
                    )

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = citation.metaInfo,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    )
                }
            }

            // View source pill
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0x16FFFFFF))
                    .border(1.dp, Color(0x28FFFFFF), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "View →",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = WarmGold,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
        }
    }
}

/**
 * Bottom sticky input bar with 'Ask anything about your saved memories...' and send icon
 */
@Composable
private fun StickyBottomInputBar(
    inputText: String,
    onInputTextChange: (String) -> Unit,
    onSendClick: () -> Unit,
    onVoiceClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp)
            .testTag("sticky_bottom_input_container")
    ) {
        GlassCard(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            borderStrokeWidth = 1.dp,
            borderColorList = listOf(
                Color(0x60FFFFFF),
                Color(0x20FFFFFF),
                Color(0x40FFFFFF)
            ),
            backgroundGradient = listOf(
                Color(0x351F1A20),
                Color(0x45161318),
                Color(0x550F0D12)
            ),
            ambientGlowColor = AmberWarm
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Microphone voice trigger icon
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(Color(0x1AFFFFFF))
                        .border(1.dp, GlassStroke, CircleShape)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = ripple(color = AmberWarm.copy(alpha = 0.3f)),
                            onClick = onVoiceClick
                        )
                        .testTag("chat_microphone_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Mic,
                        contentDescription = "Voice Input",
                        tint = AmberWarm,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                // Input Text Field
                Box(modifier = Modifier.weight(1f)) {
                    if (inputText.isEmpty()) {
                        Text(
                            text = "Ask anything about your saved memories...",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = TextMuted,
                                fontSize = 14.sp
                            )
                        )
                    }

                    BasicTextField(
                        value = inputText,
                        onValueChange = onInputTextChange,
                        textStyle = MaterialTheme.typography.bodyLarge.copy(
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontFamily = FontFamily.SansSerif
                        ),
                        cursorBrush = SolidColor(AmberWarm),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = { onSendClick() }),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("chat_input_field")
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Send Icon Button
                val sendEnabled = inputText.isNotBlank()
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(
                            if (sendEnabled) {
                                Brush.linearGradient(listOf(AmberWarm, AmberGlow))
                            } else {
                                Brush.linearGradient(listOf(Color(0x22FFFFFF), Color(0x10FFFFFF)))
                            }
                        )
                        .border(
                            1.dp,
                            if (sendEnabled) Color.White.copy(alpha = 0.5f) else Color(0x22FFFFFF),
                            CircleShape
                        )
                        .clickable(
                            enabled = sendEnabled,
                            interactionSource = remember { MutableInteractionSource() },
                            indication = ripple(color = Color.White.copy(alpha = 0.3f)),
                            onClick = onSendClick
                        )
                        .testTag("send_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Outlined.Send,
                        contentDescription = "Send query",
                        tint = if (sendEnabled) Color(0xFF0F0E11) else TextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}
