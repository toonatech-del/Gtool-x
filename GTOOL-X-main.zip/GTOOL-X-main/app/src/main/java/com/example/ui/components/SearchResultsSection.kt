package com.example.ui.components

import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.ui.res.stringResource
import com.example.R
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SearchOff
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.rememberAsyncImagePainter
import com.example.model.ItemType
import com.example.model.WorkspaceItem
import com.example.ui.theme.AmberGlow
import com.example.ui.theme.AmberWarm
import com.example.ui.theme.ImagePurple
import com.example.ui.theme.NoteYellow
import com.example.ui.theme.PdfRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarmGold

/**
 * Offline Search Results Section
 * Displays search results dynamically in frosted glassmorphism card format
 * with 1px white border stroke, large typography, highlighted matched keywords,
 * file type badges ('Note', 'PDF', 'Image'), and date snippet.
 *
 * If no items match, displays the clean empty card: 'No matching memory found'.
 */
import com.example.ui.theme.LocalIsDarkMode

@Composable
fun SearchResultsSection(
    query: String,
    results: List<WorkspaceItem>,
    onItemClick: (WorkspaceItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val isDarkMode = LocalIsDarkMode.current
    val titleColor = if (isDarkMode) TextPrimary else Color(0xFF000000)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .testTag("search_results_section")
    ) {
        // Section Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "Search Results",
                    style = MaterialTheme.typography.displayMedium.copy(
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 22.sp,
                        letterSpacing = (-0.3).sp,
                        color = titleColor
                    ),
                    modifier = Modifier.testTag("search_results_title")
                )
                Text(
                    text = "Offline FTS4 index match for \"$query\"",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = AmberWarm,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0x20FF9E58))
                    .border(1.dp, AmberWarm.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 10.dp, vertical = 5.dp)
            ) {
                Text(
                    text = "${results.size} matches",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = WarmGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (results.isEmpty()) {
            // Clean empty card: 'No matching memory found'
            NoMatchingMemoryCard(query = query)
        } else {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                results.forEach { item ->
                    SearchResultCard(
                        item = item,
                        query = query,
                        onClick = { onItemClick(item) }
                    )
                }
            }
        }
    }
}

/**
 * Clean empty card: 'No matching memory found'
 */
@Composable
fun NoMatchingMemoryCard(
    query: String,
    modifier: Modifier = Modifier
) {
    GlassCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag("no_matching_memory_card"),
        shape = RoundedCornerShape(24.dp),
        borderStrokeWidth = 1.dp,
        borderColorList = listOf(
            Color(0x60FFFFFF),
            Color(0x20FFFFFF),
            Color(0x40FFFFFF)
        ),
        backgroundGradient = listOf(
            Color(0x24FFFFFF),
            Color(0x14FFFFFF),
            Color(0x0CFFFFFF)
        ),
        ambientGlowColor = AmberWarm
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 36.dp, horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(Color(0x30FF9E58), Color(0x10FF9E58))
                        )
                    )
                    .border(1.dp, Color(0x40FFFFFF), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.SearchOff,
                    contentDescription = null,
                    tint = AmberWarm,
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = stringResource(id = R.string.no_matching_memory_found),
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    letterSpacing = (-0.2).sp,
                    fontFamily = FontFamily.SansSerif,
                    color = TextPrimary
                ),
                modifier = Modifier.testTag("no_matching_memory_title")
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = stringResource(id = R.string.no_matching_results_desc, query),
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = TextSecondary,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                ),
                modifier = Modifier.testTag("no_matching_memory_desc")
            )
        }
    }
}

/**
 * Result Card:
 * Frosted glassmorphism card format with 1px white border stroke, large typography,
 * highlighted matched keyword, exact file type badge ('Note', 'PDF', 'Image'), and date snippet.
 */
@Composable
fun SearchResultCard(
    item: WorkspaceItem,
    query: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isDarkMode = LocalIsDarkMode.current
    val (typeColor, typeBadgeLabel, typeIcon) = when (item.type) {
        ItemType.PDF -> Triple(PdfRed, "PDF", Icons.Rounded.PictureAsPdf)
        ItemType.NOTE -> Triple(NoteYellow, "Note", Icons.Rounded.Description)
        ItemType.IMAGE -> Triple(ImagePurple, "Image", ModernGalleryIconVector)
        ItemType.VOICE -> Triple(AmberWarm, "Audio", Icons.Rounded.GraphicEq)
        ItemType.ALL -> Triple(AmberWarm, "Memory", Icons.Rounded.Description)
    }

    val primaryTextColor = if (isDarkMode) TextPrimary else Color(0xFF111111)
    val secondaryTextColor = if (isDarkMode) TextSecondary else Color(0xFF333333)

    GlassCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag("search_result_card_${item.id}"),
        shape = RoundedCornerShape(22.dp),
        borderStrokeWidth = 1.dp,
        ambientGlowColor = typeColor,
        onClick = onClick
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            // Header Row: Type Badge + Date Snippet + Forward Arrow
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Exact file type badge ('Note', 'PDF', 'Image')
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(typeColor.copy(alpha = 0.22f))
                        .border(1.dp, typeColor.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 9.dp, vertical = 3.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = typeIcon,
                            contentDescription = null,
                            tint = typeColor,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = typeBadgeLabel,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = typeColor,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }

                // Date snippet
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = item.dateModified,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = secondaryTextColor,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                        contentDescription = "Open",
                        tint = secondaryTextColor,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Large typography title with highlighted keyword
            val annotatedTitle = highlightKeyword(
                fullText = item.title,
                keyword = query,
                normalColor = primaryTextColor,
                highlightColor = AmberWarm,
                highlightBg = Color(0x3DFF9E58)
            )

            Text(
                text = annotatedTitle,
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    letterSpacing = (-0.2).sp
                ),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.testTag("search_result_title_${item.id}")
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Snippet of content / extracted text with highlighted keyword
            val snippetText = item.contentSnippet ?: item.summary
            if (snippetText.isNotBlank()) {
                val annotatedSnippet = highlightKeyword(
                    fullText = extractRelevantSnippet(snippetText, query),
                    keyword = query,
                    normalColor = secondaryTextColor,
                    highlightColor = AmberWarm,
                    highlightBg = Color(0x3DFF9E58)
                )

                Text(
                    text = annotatedSnippet,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    ),
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.testTag("search_result_snippet_${item.id}")
                )
            }

            // Real uploaded file preview thumbnail/banner
            val isPdfFile = item.imageUri?.endsWith(".pdf", ignoreCase = true) == true
            if (!item.imageUri.isNullOrBlank() && !isPdfFile) {
                Spacer(modifier = Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x18000000))
                        .border(1.dp, typeColor.copy(alpha = 0.35f), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = rememberAsyncImagePainter(model = item.imageUri),
                        contentDescription = "Preview of ${item.title}",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )

                    // Overlay pill tag
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(8.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xEE0F0E11))
                            .border(1.dp, typeColor.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = if (item.type == ItemType.PDF) "📄 REAL PDF PAGE 1" else "🖼️ REAL UPLOADED IMAGE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = typeColor,
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.sp
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Footer meta: size and FTS4 status
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = item.sizeText,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                )

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0x18FFFFFF))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "FTS4 Indexed",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = WarmGold,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
            }
        }
    }
}

/**
 * Extracts a relevant snippet surrounding the matched keyword if found,
 * otherwise takes the start of the text.
 */
private fun extractRelevantSnippet(fullText: String, keyword: String): String {
    if (keyword.isBlank()) return fullText.take(160)
    val index = fullText.indexOf(keyword, ignoreCase = true)
    if (index == -1) return fullText.take(160)

    val start = maxOf(0, index - 40)
    val end = minOf(fullText.length, index + keyword.length + 80)
    val prefix = if (start > 0) "... " else ""
    val suffix = if (end < fullText.length) "..." else ""
    return prefix + fullText.substring(start, end).replace("\n", " ") + suffix
}

/**
 * Highlights matches of [keyword] inside [fullText] using Compose AnnotatedString
 */
private fun highlightKeyword(
    fullText: String,
    keyword: String,
    normalColor: Color,
    highlightColor: Color,
    highlightBg: Color
) = buildAnnotatedString {
    if (keyword.isBlank()) {
        withStyle(SpanStyle(color = normalColor)) {
            append(fullText)
        }
        return@buildAnnotatedString
    }

    val lowerText = fullText.lowercase()
    val lowerKeyword = keyword.lowercase()
    var currentIndex = 0

    while (currentIndex < fullText.length) {
        val nextMatch = lowerText.indexOf(lowerKeyword, currentIndex)
        if (nextMatch == -1) {
            withStyle(SpanStyle(color = normalColor)) {
                append(fullText.substring(currentIndex))
            }
            break
        }

        if (nextMatch > currentIndex) {
            withStyle(SpanStyle(color = normalColor)) {
                append(fullText.substring(currentIndex, nextMatch))
            }
        }

        val matchEnd = nextMatch + lowerKeyword.length
        withStyle(
            SpanStyle(
                color = highlightColor,
                background = highlightBg,
                fontWeight = FontWeight.Bold
            )
        ) {
            append(fullText.substring(nextMatch, matchEnd))
        }

        currentIndex = matchEnd
    }
}
