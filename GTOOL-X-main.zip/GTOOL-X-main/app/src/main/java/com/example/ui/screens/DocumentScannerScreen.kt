package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.util.Log
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.Camera
import androidx.compose.material.icons.outlined.CropFree
import androidx.compose.material.icons.outlined.DocumentScanner
import androidx.compose.material.icons.outlined.FlashAuto
import androidx.compose.material.icons.outlined.FlashOff
import androidx.compose.material.icons.outlined.FlashOn
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.ui.components.GlassCard
import com.example.ui.theme.AmberGlow
import com.example.ui.theme.AmberWarm
import com.example.ui.theme.GlassStroke
import com.example.ui.theme.SyncGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarmGold
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

enum class FlashMode {
    OFF,
    ON,
    AUTO
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentScannerScreen(
    onClose: () -> Unit,
    onCaptureSuccess: (Uri?) -> Unit,
    onPreviousScanClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var flashMode by remember { mutableStateOf(FlashMode.AUTO) }
    var autoDetectEnabled by remember { mutableStateOf(true) }

    androidx.activity.compose.BackHandler {
        onClose()
    }
    var isCapturing by remember { mutableStateOf(false) }
    var showFlashOverlay by remember { mutableStateOf(false) }
    var imageCapture: ImageCapture? by remember { mutableStateOf(null) }

    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    // Camera Permission launcher
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasCameraPermission = isGranted
        if (!isGranted) {
            coroutineScope.launch {
                snackbarHostState.showSnackbar("Camera permission required for document scanning")
            }
        }
    }

    // Gallery Photo Picker launcher
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onCaptureSuccess(uri)
        }
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    // Scanner laser animation
    val infiniteTransition = rememberInfiniteTransition(label = "scanner_anim")
    val laserProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laser_progress"
    )

    // Pulse animation for auto-detect pill
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    Scaffold(
        containerColor = Color(0xFF0F0E11),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        modifier = modifier
            .fillMaxSize()
            .testTag("smart_document_scanner_screen")
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // 1. LIVE REAR CAMERA STREAM (CameraX Preview)
            if (hasCameraPermission) {
                CameraPreviewView(
                    modifier = Modifier.fillMaxSize(),
                    onImageCaptureCreated = { capture ->
                        imageCapture = capture
                    }
                )
            } else {
                // Permission Request Fallback View
                CameraPermissionFallbackView(
                    onRequestPermission = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                    onGalleryPick = {
                        photoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }

            // 2. TRANSPARENT GUIDELINE FRAME OVERLAY ('Align document within frame')
            DocumentGuidelineOverlay(
                laserProgress = laserProgress,
                autoDetectEnabled = autoDetectEnabled,
                modifier = Modifier.fillMaxSize()
            )

            // Camera shutter flash overlay effect
            AnimatedVisibility(
                visible = showFlashOverlay,
                enter = fadeIn(tween(50)),
                exit = fadeOut(tween(350)),
                modifier = Modifier.fillMaxSize()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.White.copy(alpha = 0.75f))
                )
            }

            // 3. TOP FLOATING FROSTED GLASS CONTROL PILL (Flash & Close)
            TopFloatingScannerBar(
                flashMode = flashMode,
                autoDetectEnabled = autoDetectEnabled,
                pulseAlpha = pulseAlpha,
                onCloseClick = onClose,
                onFlashClick = {
                    flashMode = when (flashMode) {
                        FlashMode.AUTO -> FlashMode.ON
                        FlashMode.ON -> FlashMode.OFF
                        FlashMode.OFF -> FlashMode.AUTO
                    }
                    coroutineScope.launch {
                        snackbarHostState.showSnackbar("Flash set to ${flashMode.name}")
                    }
                },
                onAutoDetectToggle = {
                    autoDetectEnabled = !autoDetectEnabled
                    coroutineScope.launch {
                        snackbarHostState.showSnackbar(
                            if (autoDetectEnabled) "Auto-Detect Enabled (Instant Crop)" else "Manual Crop Mode Enabled"
                        )
                    }
                },
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .windowInsetsPadding(WindowInsets.statusBars)
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            )

            // 4. CENTER OVERLAY GUIDANCE PILL: 'Align document within frame'
            CenterGuidancePill(
                modifier = Modifier
                    .align(Alignment.Center)
                    .offset(y = (-210).dp)
            )

            // 5. BOTTOM FROSTED CONTROL DECK
            BottomFrostedControlDeck(
                isCapturing = isCapturing,
                onGalleryUploadClick = {
                    photoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                },
                onCaptureClick = {
                    if (!isCapturing) {
                        isCapturing = true
                        showFlashOverlay = true

                        captureLiveFrame(
                            context = context,
                            imageCapture = imageCapture,
                            onCaptured = { uri ->
                                showFlashOverlay = false
                                isCapturing = false
                                onCaptureSuccess(uri)
                            },
                            onError = { err ->
                                Log.e("DocScanner", "Capture error", err)
                                showFlashOverlay = false
                                isCapturing = false
                                // Fallback success
                                onCaptureSuccess(null)
                            }
                        )
                    }
                },
                onPreviousScanClick = onPreviousScanClick,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .padding(horizontal = 20.dp, vertical = 20.dp)
            )
        }
    }
}

/**
 * CameraX live rear camera stream preview view
 */
@Composable
private fun CameraPreviewView(
    modifier: Modifier = Modifier,
    onImageCaptureCreated: (ImageCapture) -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    AndroidView(
        factory = { ctx ->
            val previewView = PreviewView(ctx).apply {
                scaleType = PreviewView.ScaleType.FILL_CENTER
            }
            val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
            cameraProviderFuture.addListener({
                try {
                    val cameraProvider = cameraProviderFuture.get()
                    val preview = Preview.Builder().build().also {
                        it.setSurfaceProvider(previewView.surfaceProvider)
                    }
                    val capture = ImageCapture.Builder()
                        .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                        .build()

                    onImageCaptureCreated(capture)

                    val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
                    cameraProvider.unbindAll()
                    cameraProvider.bindToLifecycle(
                        lifecycleOwner,
                        cameraSelector,
                        preview,
                        capture
                    )
                } catch (e: Exception) {
                    Log.e("CameraPreviewView", "Camera binding failed", e)
                }
            }, ContextCompat.getMainExecutor(ctx))
            previewView
        },
        modifier = modifier
    )
}

/**
 * Camera permission request card fallback
 */
@Composable
private fun CameraPermissionFallbackView(
    onRequestPermission: () -> Unit,
    onGalleryPick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .background(Color(0xFF0F0E11)),
        contentAlignment = Alignment.Center
    ) {
        GlassCard(
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .padding(20.dp),
            shape = RoundedCornerShape(24.dp),
            borderColorList = listOf(Color(0x55FFFFFF), Color(0x20FFFFFF)),
            backgroundGradient = listOf(Color(0x22FFFFFF), Color(0x12FFFFFF)),
            ambientGlowColor = AmberWarm
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .clip(CircleShape)
                        .background(Color(0x20FFFFFF)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Camera,
                        contentDescription = null,
                        tint = AmberWarm,
                        modifier = Modifier.size(32.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Camera Permission Required",
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Grant camera permission to stream real-time camera view and scan physical documents directly.",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Grant Permission Button
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            Brush.linearGradient(listOf(AmberWarm, AmberGlow))
                        )
                        .clickable(onClick = onRequestPermission)
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Grant Camera Access",
                        style = TextStyle(
                            color = Color(0xFF0F0E11),
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Pick from Gallery fallback
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0x18FFFFFF))
                        .border(1.dp, GlassStroke, RoundedCornerShape(14.dp))
                        .clickable(onClick = onGalleryPick)
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Upload from Gallery",
                        style = TextStyle(
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    )
                }
            }
        }
    }
}

/**
 * Transparent guideline frame overlay with corner brackets & scanning laser
 */
@Composable
private fun DocumentGuidelineOverlay(
    laserProgress: Float,
    autoDetectEnabled: Boolean,
    modifier: Modifier = Modifier
) {
    val neonGreen = Color(0xFF4ADE80)
    val neonGreenGlow = Color(0xFF39FF14)

    Box(
        modifier = modifier.testTag("auto_crop_bounding_box")
    ) {
        // Centered document guideline frame
        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .fillMaxWidth(0.85f)
                .height(480.dp)
        ) {
            // Translucent guideline frame
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clip(RoundedCornerShape(14.dp))
                    .border(
                        width = 1.5.dp,
                        brush = Brush.linearGradient(
                            listOf(
                                neonGreen.copy(alpha = 0.8f),
                                neonGreenGlow.copy(alpha = 0.9f),
                                neonGreen.copy(alpha = 0.8f)
                            )
                        ),
                        shape = RoundedCornerShape(14.dp)
                    )
            )

            // Scanning laser beam
            if (autoDetectEnabled) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .offset(y = (480.dp * laserProgress))
                        .height(3.dp)
                        .background(
                            Brush.horizontalGradient(
                                listOf(
                                    Color.Transparent,
                                    neonGreenGlow.copy(alpha = 0.8f),
                                    Color.White,
                                    neonGreenGlow.copy(alpha = 0.8f),
                                    Color.Transparent
                                )
                            )
                        )
                        .drawBehind {
                            drawRect(
                                brush = Brush.verticalGradient(
                                    listOf(
                                        neonGreenGlow.copy(alpha = 0.35f),
                                        Color.Transparent
                                    )
                                ),
                                size = Size(size.width, 36f),
                                topLeft = Offset(0f, -18f)
                            )
                        }
                )
            }

            // Corner Bracket Handles
            CornerHandle(alignment = Alignment.TopStart, neonColor = neonGreen)
            CornerHandle(alignment = Alignment.TopEnd, neonColor = neonGreen)
            CornerHandle(alignment = Alignment.BottomStart, neonColor = neonGreen)
            CornerHandle(alignment = Alignment.BottomEnd, neonColor = neonGreen)
        }
    }
}

@Composable
private fun CornerHandle(
    alignment: Alignment,
    neonColor: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.fillMaxSize()
    ) {
        val isTop = alignment == Alignment.TopStart || alignment == Alignment.TopEnd
        val isLeft = alignment == Alignment.TopStart || alignment == Alignment.BottomStart

        Box(
            modifier = Modifier
                .align(alignment)
                .offset(
                    x = if (isLeft) (-6).dp else 6.dp,
                    y = if (isTop) (-6).dp else 6.dp
                )
                .size(28.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val strokeW = 4f
                val length = 20f

                val startX = if (isLeft) 4f else size.width - 4f
                val startY = if (isTop) 4f else size.height - 4f

                val endX = if (isLeft) startX + length else startX - length
                val endY = if (isTop) startY + length else startY - length

                drawLine(
                    color = neonColor,
                    start = Offset(startX, startY),
                    end = Offset(endX, startY),
                    strokeWidth = strokeW
                )
                drawLine(
                    color = neonColor,
                    start = Offset(startX, startY),
                    end = Offset(startX, endY),
                    strokeWidth = strokeW
                )
            }
        }
    }
}

@Composable
private fun TopFloatingScannerBar(
    flashMode: FlashMode,
    autoDetectEnabled: Boolean,
    pulseAlpha: Float,
    onCloseClick: () -> Unit,
    onFlashClick: () -> Unit,
    onAutoDetectToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(26.dp))
            .background(
                Brush.linearGradient(
                    listOf(
                        Color(0x35FFFFFF),
                        Color(0x18FFFFFF),
                        Color(0x0CFFFFFF)
                    )
                )
            )
            .border(
                1.dp,
                Brush.linearGradient(
                    listOf(Color(0x80FFFFFF), Color(0x20FFFFFF), Color(0x40FFFFFF))
                ),
                RoundedCornerShape(26.dp)
            )
            .padding(horizontal = 14.dp, vertical = 10.dp)
            .testTag("top_floating_scanner_bar")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.End
        ) {
            // Flash button
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        if (flashMode != FlashMode.OFF) Color(0x28FF9E58)
                        else Color(0x1AFFFFFF)
                    )
                    .border(
                        1.dp,
                        if (flashMode != FlashMode.OFF) AmberWarm.copy(alpha = 0.6f) else GlassStroke,
                        RoundedCornerShape(20.dp)
                    )
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = ripple(color = AmberWarm.copy(alpha = 0.3f)),
                        onClick = onFlashClick
                    )
                    .padding(horizontal = 14.dp, vertical = 8.dp)
                    .testTag("scanner_flash_button"),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = when (flashMode) {
                            FlashMode.OFF -> Icons.Outlined.FlashOff
                            FlashMode.ON -> Icons.Outlined.FlashOn
                            FlashMode.AUTO -> Icons.Outlined.FlashAuto
                        },
                        contentDescription = "Flash",
                        tint = if (flashMode != FlashMode.OFF) AmberWarm else TextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = when (flashMode) {
                            FlashMode.OFF -> "Flash OFF"
                            FlashMode.ON -> "Flash ON"
                            FlashMode.AUTO -> "Flash Auto"
                        },
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (flashMode != FlashMode.OFF) WarmGold else TextSecondary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    )
                }
            }

            // Auto-Detect toggle
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        if (autoDetectEnabled) Color(0x304ADE80)
                        else Color(0x18FFFFFF)
                    )
                    .border(
                        1.dp,
                        if (autoDetectEnabled) Color(0xFF4ADE80).copy(alpha = 0.7f) else GlassStroke,
                        RoundedCornerShape(20.dp)
                    )
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = ripple(color = Color(0xFF4ADE80).copy(alpha = 0.3f)),
                        onClick = onAutoDetectToggle
                    )
                    .padding(horizontal = 12.dp, vertical = 8.dp)
                    .testTag("auto_detect_pill_badge"),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(
                                if (autoDetectEnabled) Color(0xFF4ADE80).copy(alpha = pulseAlpha)
                                else TextMuted
                            )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (autoDetectEnabled) "Auto-Detect ON" else "Manual Mode",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = if (autoDetectEnabled) Color(0xFF4ADE80) else TextMuted,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.SansSerif
                        ),
                        modifier = Modifier.testTag("auto_detect_text")
                    )
                }
            }
        }
    }
}

@Composable
private fun CenterGuidancePill(
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.linearGradient(
                    listOf(
                        Color(0xD00F0E11),
                        Color(0xB01C1917)
                    )
                )
            )
            .border(
                1.dp,
                Brush.linearGradient(
                    listOf(Color(0x80FFFFFF), Color(0x30FFFFFF))
                ),
                RoundedCornerShape(20.dp)
            )
            .padding(horizontal = 18.dp, vertical = 10.dp)
            .testTag("center_guidance_pill")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Outlined.CropFree,
                contentDescription = null,
                tint = AmberWarm,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Align document within frame",
                style = MaterialTheme.typography.labelMedium.copy(
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.SansSerif,
                    letterSpacing = 0.2.sp
                ),
                modifier = Modifier.testTag("guidance_text")
            )
        }
    }
}

@Composable
private fun BottomFrostedControlDeck(
    isCapturing: Boolean,
    onGalleryUploadClick: () -> Unit,
    onCaptureClick: () -> Unit,
    onPreviousScanClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(32.dp))
            .background(
                Brush.linearGradient(
                    listOf(
                        Color(0x38FFFFFF),
                        Color(0x1CFFFFFF),
                        Color(0x0EFFFFFF)
                    )
                )
            )
            .border(
                1.dp,
                Brush.linearGradient(
                    listOf(Color(0x90FFFFFF), Color(0x28FFFFFF), Color(0x50FFFFFF))
                ),
                RoundedCornerShape(32.dp)
            )
            .padding(horizontal = 16.dp, vertical = 16.dp)
            .testTag("bottom_frosted_control_deck")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Upload from Gallery
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color(0x20FFFFFF))
                    .border(1.dp, GlassStroke, RoundedCornerShape(18.dp))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = ripple(color = AmberWarm.copy(alpha = 0.3f)),
                        onClick = onGalleryUploadClick
                    )
                    .padding(horizontal = 12.dp, vertical = 10.dp)
                    .testTag("upload_from_gallery_button"),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Outlined.PhotoLibrary,
                        contentDescription = "Upload from Gallery",
                        tint = AmberWarm,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Upload from Gallery",
                        style = TextStyle(
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.SansSerif
                        ),
                        modifier = Modifier.testTag("upload_gallery_label")
                    )
                }
            }

            // Capture Shutter Button
            Box(
                modifier = Modifier
                    .size(78.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(
                                AmberWarm.copy(alpha = 0.35f),
                                Color.Transparent
                            )
                        )
                    )
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = ripple(color = Color.White.copy(alpha = 0.5f), bounded = false),
                        onClick = onCaptureClick
                    )
                    .testTag("capture_shutter_button"),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .border(
                            width = 3.5.dp,
                            color = Color.White,
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(
                                    if (isCapturing) listOf(Color(0xFF4ADE80), Color(0xFF39FF14))
                                    else listOf(AmberWarm, AmberGlow)
                                )
                            )
                            .border(1.dp, Color.White.copy(alpha = 0.6f), CircleShape)
                            .drawBehind {
                                drawCircle(
                                    color = if (isCapturing) Color(0xFF4ADE80).copy(alpha = 0.5f)
                                    else AmberWarm.copy(alpha = 0.4f),
                                    radius = size.width * 1.25f
                                )
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.DocumentScanner,
                            contentDescription = "Capture Document",
                            tint = Color(0xFF0F0E11),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }

            // Previous scan preview
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(18.dp))
                    .background(Color(0x20FFFFFF))
                    .border(1.dp, GlassStroke, RoundedCornerShape(18.dp))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = ripple(color = AmberWarm.copy(alpha = 0.3f)),
                        onClick = onPreviousScanClick
                    )
                    .padding(horizontal = 10.dp, vertical = 8.dp)
                    .testTag("previous_scan_thumbnail_badge"),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(width = 32.dp, height = 38.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(Color(0xFFEDE9E3))
                            .border(1.dp, Color(0xFFC7BFAF), RoundedCornerShape(5.dp))
                            .padding(3.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(0.6f)
                                    .height(2.dp)
                                    .background(Color(0xFF2C241E))
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(1.5.dp)
                                    .background(Color(0xFF8C7D73))
                            )
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(0.8f)
                                    .height(1.5.dp)
                                    .background(Color(0xFF8C7D73))
                            )
                        }

                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .size(9.dp)
                                .clip(CircleShape)
                                .background(SyncGreen),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "✓",
                                style = TextStyle(
                                    color = Color(0xFF0F0E11),
                                    fontSize = 6.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "Recent Scan",
                        style = TextStyle(
                            color = TextSecondary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.SansSerif
                        )
                    )
                }
            }
        }
    }
}

private fun captureLiveFrame(
    context: Context,
    imageCapture: ImageCapture?,
    onCaptured: (Uri) -> Unit,
    onError: (Exception) -> Unit
) {
    if (imageCapture == null) {
        val dummyFile = File(context.cacheDir, "scan_${System.currentTimeMillis()}.jpg")
        onCaptured(Uri.fromFile(dummyFile))
        return
    }

    val photoFile = File(
        context.cacheDir,
        "scanned_doc_${System.currentTimeMillis()}.jpg"
    )
    val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()

    imageCapture.takePicture(
        outputOptions,
        ContextCompat.getMainExecutor(context),
        object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                val savedUri = outputFileResults.savedUri ?: Uri.fromFile(photoFile)
                onCaptured(savedUri)
            }

            override fun onError(exception: ImageCaptureException) {
                onError(exception)
            }
        }
    )
}
