package com.example.ui.screens

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Badge
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.GridOn
import androidx.compose.material.icons.outlined.Photo
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AmbientLightingBackground
import com.example.ui.components.GlassCard
import com.example.ui.theme.AmberGlow
import com.example.ui.theme.AmberWarm
import com.example.ui.theme.GlassStroke
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarmGold
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

enum class PassportPreset(
    val label: String,
    val dimensionLabel: String,
    val aspectRatio: Float
) {
    STANDARD_35_45("3.5 x 4.5 cm (Passport/Visa)", "Standard Passport / Visa (EU/Asia/UK)", 3.5f / 4.5f),
    US_2_2("2 x 2 inch (US Visa)", "US Passport / Visa (51 × 51 mm)", 1.0f),
    PAN_35_35("35 x 35 mm (PAN Card)", "ID Card / Official PAN Card Photo", 1.0f)
}

enum class ExportFormat(val label: String, val subtitle: String) {
    SINGLE_JPEG("Single High-Res JPEG", "Standard digital passport photo"),
    PRINT_SHEET("Print Sheet (6-Photo Grid)", "Ready to print 4x6 grid layout")
}

data class BackgroundOption(
    val label: String,
    val color: Color,
    val hexColor: Int
)

@Composable
fun PassportPhotoMakerScreen(
    onBackClick: () -> Unit,
    onSaveSuccess: (title: String, imageUri: String, syncToDrive: Boolean) -> Unit = { _, _, _ -> },
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var sourceBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var selectedPreset by remember { mutableStateOf(PassportPreset.STANDARD_35_45) }
    var selectedExportFormat by remember { mutableStateOf(ExportFormat.SINGLE_JPEG) }

    // Drag to crop gestures
    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var offsetY by remember { mutableFloatStateOf(0f) }

    val backgroundOptions = listOf(
        BackgroundOption("White", Color.White, android.graphics.Color.WHITE),
        BackgroundOption("Off-White", Color(0xFFF5F5F5), android.graphics.Color.parseColor("#F5F5F5")),
        BackgroundOption("Light Blue", Color(0xFFD0E8FF), android.graphics.Color.parseColor("#D0E8FF")),
        BackgroundOption("Light Gray", Color(0xFFE0E0E0), android.graphics.Color.parseColor("#E0E0E0"))
    )

    var selectedBg by remember { mutableStateOf(backgroundOptions[0]) }
    var showHeadGuide by remember { mutableStateOf(true) }
    var isProcessing by remember { mutableStateOf(false) }

    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            imageUri = uri
            scale = 1f
            offsetX = 0f
            offsetY = 0f
        }
    }

    LaunchedEffect(imageUri) {
        if (imageUri != null) {
            withContext(Dispatchers.IO) {
                try {
                    val inputStream = context.contentResolver.openInputStream(imageUri!!)
                    val bytes = inputStream?.readBytes() ?: byteArrayOf()
                    inputStream?.close()
                    val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    sourceBitmap = bmp
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    AmbientLightingBackground {
        Scaffold(
            containerColor = Color.Transparent,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            modifier = modifier
                .fillMaxSize()
                .testTag("passport_photo_maker_screen")
        ) { paddingValues ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .windowInsetsPadding(WindowInsets.statusBars),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(
                    bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 32.dp
                )
            ) {
                // Header
                item(key = "header") {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        IconButton(
                            onClick = onBackClick,
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Color(0x22FFFFFF))
                                .border(1.dp, GlassStroke, CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
                                contentDescription = "Back",
                                tint = TextPrimary
                            )
                        }

                        Text(
                            text = "Passport Photo Maker",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = TextPrimary
                            )
                        )

                        Spacer(modifier = Modifier.width(40.dp))
                    }
                }

                // Drag to crop interactive frame overlay
                item(key = "photo_preview_frame") {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        GlassCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(320.dp)
                                .testTag("passport_photo_dropzone"),
                            shape = RoundedCornerShape(24.dp),
                            ambientGlowColor = WarmGold
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(selectedBg.color.copy(alpha = 0.9f))
                                    .clickable { galleryLauncher.launch("image/*") }
                                    .pointerInput(Unit) {
                                        detectTransformGestures { _, pan, zoom, _ ->
                                            scale = (scale * zoom).coerceIn(0.8f, 3.5f)
                                            offsetX += pan.x
                                            offsetY += pan.y
                                        }
                                    }
                            ) {
                                if (sourceBitmap != null) {
                                    Image(
                                        bitmap = sourceBitmap!!.asImageBitmap(),
                                        contentDescription = "Portrait Photo",
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .graphicsLayer(
                                                scaleX = scale,
                                                scaleY = scale,
                                                translationX = offsetX,
                                                translationY = offsetY
                                            ),
                                        contentScale = ContentScale.Crop
                                    )
                                } else {
                                    Column(
                                        modifier = Modifier.fillMaxSize(),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(56.dp)
                                                .clip(CircleShape)
                                                .background(
                                                    Brush.radialGradient(
                                                        listOf(Color(0x40FFD700), Color(0x10FFD700))
                                                    )
                                                )
                                                .border(1.dp, WarmGold.copy(alpha = 0.6f), CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Outlined.Badge,
                                                contentDescription = "Select Portrait",
                                                tint = WarmGold,
                                                modifier = Modifier.size(28.dp)
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(14.dp))

                                        Text(
                                            text = "Tap to choose portrait photo",
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF1E1C24)
                                            )
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "Face forward • Pinch & drag to align",
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                color = Color(0xFF555555),
                                                fontSize = 12.sp
                                            )
                                        )
                                    }
                                }

                                // Head & Face Alignment Guide Overlay
                                if (showHeadGuide) {
                                    Canvas(modifier = Modifier.fillMaxSize()) {
                                        val w = size.width
                                        val h = size.height

                                        // Draw face oval guide
                                        drawOval(
                                            color = AmberWarm,
                                            topLeft = Offset(w * 0.25f, h * 0.15f),
                                            size = Size(w * 0.5f, h * 0.55f),
                                            style = Stroke(
                                                width = 3.dp.toPx(),
                                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 15f), 0f)
                                            )
                                        )

                                        // Horizontal eye level line
                                        drawLine(
                                            color = AmberWarm.copy(alpha = 0.6f),
                                            start = Offset(w * 0.2f, h * 0.38f),
                                            end = Offset(w * 0.8f, h * 0.38f),
                                            strokeWidth = 2.dp.toPx(),
                                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                                        )
                                    }
                                }

                                // Guideline label pill
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.BottomCenter)
                                        .padding(12.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(Color(0xEE0F0E11))
                                        .border(1.dp, Color(0x44FFFFFF), RoundedCornerShape(14.dp))
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = "Pinch & Drag to align head in frame",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = WarmGold,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    )
                                }
                            }
                        }
                    }
                }

                // Controls: Presets, Background Color, Export Format
                item(key = "passport_controls") {
                    Spacer(modifier = Modifier.height(12.dp))

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Preset Selector
                        GlassCard(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "PASSPORT ASPECT RATIO PRESET",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        letterSpacing = 0.8.sp,
                                        color = TextMuted
                                    )
                                )
                                Spacer(modifier = Modifier.height(10.dp))

                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    PassportPreset.entries.forEach { preset ->
                                        val isSelected = selectedPreset == preset
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clip(RoundedCornerShape(14.dp))
                                                .background(
                                                    if (isSelected) Brush.horizontalGradient(
                                                        listOf(AmberWarm, AmberGlow)
                                                    ) else Brush.linearGradient(
                                                        listOf(Color(0x1AFFFFFF), Color(0x0AFFFFFF))
                                                    )
                                                )
                                                .border(
                                                    1.dp,
                                                    if (isSelected) Color.White.copy(alpha = 0.4f) else GlassStroke,
                                                    RoundedCornerShape(14.dp)
                                                )
                                                .clickable { selectedPreset = preset }
                                                .padding(horizontal = 14.dp, vertical = 12.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column {
                                                    Text(
                                                        text = preset.label,
                                                        color = if (isSelected) Color(0xFF0F0E11) else TextPrimary,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 14.sp
                                                    )
                                                    Text(
                                                        text = preset.dimensionLabel,
                                                        color = if (isSelected) Color(0xFF222222) else TextMuted,
                                                        fontSize = 11.sp
                                                    )
                                                }

                                                if (isSelected) {
                                                    Icon(
                                                        imageVector = Icons.Outlined.Check,
                                                        contentDescription = null,
                                                        tint = Color(0xFF0F0E11),
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Export Format (Single JPEG vs Print Sheet 6-photo grid)
                        GlassCard(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "EXPORT FORMAT",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        letterSpacing = 0.8.sp,
                                        color = TextMuted
                                    )
                                )
                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    ExportFormat.entries.forEach { fmt ->
                                        val isSelected = selectedExportFormat == fmt
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(14.dp))
                                                .background(
                                                    if (isSelected) Brush.horizontalGradient(listOf(AmberWarm, AmberGlow))
                                                    else Brush.linearGradient(listOf(Color(0x1AFFFFFF), Color(0x0AFFFFFF)))
                                                )
                                                .border(
                                                    1.dp,
                                                    if (isSelected) Color.White.copy(alpha = 0.4f) else GlassStroke,
                                                    RoundedCornerShape(14.dp)
                                                )
                                                .clickable { selectedExportFormat = fmt }
                                                .padding(horizontal = 12.dp, vertical = 12.dp)
                                        ) {
                                            Column {
                                                Text(
                                                    text = fmt.label,
                                                    color = if (isSelected) Color(0xFF0F0E11) else TextPrimary,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 12.sp
                                                )
                                                Text(
                                                    text = fmt.subtitle,
                                                    color = if (isSelected) Color(0xFF333333) else TextMuted,
                                                    fontSize = 10.sp
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Background Color Options
                        GlassCard(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "BACKGROUND COLOR",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        letterSpacing = 0.8.sp,
                                        color = TextMuted
                                    )
                                )
                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    backgroundOptions.forEach { option ->
                                        val isSelected = selectedBg == option
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(option.color)
                                                .border(
                                                    if (isSelected) 2.5.dp else 1.dp,
                                                    if (isSelected) AmberWarm else GlassStroke,
                                                    RoundedCornerShape(12.dp)
                                                )
                                                .clickable { selectedBg = option }
                                                .padding(vertical = 12.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = option.label,
                                                color = Color(0xFF1E1C24),
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Action Buttons: 'Save to Gallery' and 'Save to Drive'
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = {
                                    if (sourceBitmap == null) {
                                        coroutineScope.launch {
                                            snackbarHostState.showSnackbar("Please select a portrait photo first!")
                                        }
                                        return@Button
                                    }

                                    isProcessing = true
                                    coroutineScope.launch {
                                        val resultUri = generatePassportPhoto(
                                            context = context,
                                            sourceBitmap = sourceBitmap!!,
                                            preset = selectedPreset,
                                            format = selectedExportFormat,
                                            bgColorInt = selectedBg.hexColor,
                                            userScale = scale,
                                            userOffsetX = offsetX,
                                            userOffsetY = offsetY
                                        )

                                        isProcessing = false
                                        if (resultUri != null) {
                                            onSaveSuccess("Passport_${selectedPreset.label}", resultUri.toString(), false)
                                            snackbarHostState.showSnackbar("Saved locally to gallery! 🖼️")
                                        } else {
                                            snackbarHostState.showSnackbar("Failed to generate passport photo.")
                                        }
                                    }
                                },
                                enabled = !isProcessing,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = WarmGold,
                                    contentColor = Color(0xFF0F0E11)
                                ),
                                shape = RoundedCornerShape(18.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(52.dp)
                                    .testTag("btn_save_to_gallery")
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.Download,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isProcessing) "Formatting..." else "Save to Gallery",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }

                            Button(
                                onClick = {
                                    if (sourceBitmap == null) {
                                        coroutineScope.launch {
                                            snackbarHostState.showSnackbar("Please select a portrait photo first!")
                                        }
                                        return@Button
                                    }

                                    isProcessing = true
                                    coroutineScope.launch {
                                        val resultUri = generatePassportPhoto(
                                            context = context,
                                            sourceBitmap = sourceBitmap!!,
                                            preset = selectedPreset,
                                            format = selectedExportFormat,
                                            bgColorInt = selectedBg.hexColor,
                                            userScale = scale,
                                            userOffsetX = offsetX,
                                            userOffsetY = offsetY
                                        )

                                        isProcessing = false
                                        if (resultUri != null) {
                                            onSaveSuccess("Passport_${selectedPreset.label}", resultUri.toString(), true)
                                            snackbarHostState.showSnackbar("Backed up & synced to Google Drive! ☁️")
                                        } else {
                                            snackbarHostState.showSnackbar("Failed to generate passport photo.")
                                        }
                                    }
                                },
                                enabled = !isProcessing,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF3B82F6),
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(18.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(52.dp)
                                    .testTag("btn_save_to_drive")
                            ) {
                                Text(
                                    text = "☁ Save to Drive",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private suspend fun generatePassportPhoto(
    context: Context,
    sourceBitmap: Bitmap,
    preset: PassportPreset,
    format: ExportFormat,
    bgColorInt: Int,
    userScale: Float,
    userOffsetX: Float,
    userOffsetY: Float
): Uri? = withContext(Dispatchers.IO) {
    try {
        val singleW = 600
        val singleH = (600 / preset.aspectRatio).toInt()

        val singleBitmap = Bitmap.createBitmap(singleW, singleH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(singleBitmap)
        canvas.drawColor(bgColorInt)

        // Scale & center source photo onto passport canvas with user gestures
        val scale: Float
        var dx = 0f
        var dy = 0f

        if (sourceBitmap.width * singleH > singleW * sourceBitmap.height) {
            scale = (singleH.toFloat() / sourceBitmap.height.toFloat()) * userScale
            dx = (singleW - sourceBitmap.width * scale) * 0.5f + userOffsetX
            dy = (singleH - sourceBitmap.height * scale) * 0.5f + userOffsetY
        } else {
            scale = (singleW.toFloat() / sourceBitmap.width.toFloat()) * userScale
            dx = (singleW - sourceBitmap.width * scale) * 0.5f + userOffsetX
            dy = (singleH - sourceBitmap.height * scale) * 0.5f + userOffsetY
        }

        val matrix = android.graphics.Matrix()
        matrix.setScale(scale, scale)
        matrix.postTranslate(dx, dy)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        canvas.drawBitmap(sourceBitmap, matrix, paint)

        val finalOutputBitmap = if (format == ExportFormat.SINGLE_JPEG) {
            singleBitmap
        } else {
            // Render 6-photo print sheet grid (2 cols x 3 rows on 4x6 print sheet)
            val printW = 1200
            val printH = 1800
            val printSheet = Bitmap.createBitmap(printW, printH, Bitmap.Config.ARGB_8888)
            val printCanvas = Canvas(printSheet)
            printCanvas.drawColor(android.graphics.Color.WHITE)

            val photoW = 520
            val photoH = (520 / preset.aspectRatio).toInt().coerceAtMost(520)
            val marginX = 50
            val marginY = 60
            val spacingX = 60
            val spacingY = 40

            val linePaint = Paint().apply {
                color = android.graphics.Color.LTGRAY
                strokeWidth = 2f
            }

            for (row in 0 until 3) {
                for (col in 0 until 2) {
                    val left = marginX + col * (photoW + spacingX)
                    val top = marginY + row * (photoH + spacingY)

                    val scaledPassport = Bitmap.createScaledBitmap(singleBitmap, photoW, photoH, true)
                    printCanvas.drawBitmap(scaledPassport, left.toFloat(), top.toFloat(), paint)

                    // Draw thin cut line rectangle around each photo
                    printCanvas.drawRect(left.toFloat(), top.toFloat(), (left + photoW).toFloat(), (top + photoH).toFloat(), Paint().apply {
                        style = Paint.Style.STROKE
                        color = android.graphics.Color.LTGRAY
                        strokeWidth = 1f
                    })
                }
            }
            printSheet
        }

        val file = File(context.cacheDir, "passport_${System.currentTimeMillis()}.jpg")
        val fos = FileOutputStream(file)
        finalOutputBitmap.compress(Bitmap.CompressFormat.JPEG, 95, fos)
        fos.flush()
        fos.close()

        Uri.fromFile(file)
    } catch (e: Exception) {
        e.printStackTrace()
        null
    }
}
