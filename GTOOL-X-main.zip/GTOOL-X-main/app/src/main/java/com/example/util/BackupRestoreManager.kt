package com.example.util

import android.content.Context
import android.os.Environment
import com.example.data.local.MemoryDao
import com.example.data.local.MemoryEntity
import com.example.data.local.MemoryFtsEntity
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class BackupInfo(
    val exists: Boolean,
    val filePath: String,
    val lastBackupDate: String,
    val fileSizeBytes: Long,
    val itemCount: Int
)

data class BackupResult(
    val success: Boolean,
    val filePath: String,
    val itemCount: Int,
    val errorMessage: String? = null
)

object BackupRestoreManager {

    private const val PREFS_NAME = "gtool_backup_prefs"
    private const val KEY_LAST_BACKUP = "last_backup_timestamp"

    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
    private val listType = Types.newParameterizedType(List::class.java, MemoryEntity::class.java)
    private val adapter = moshi.adapter<List<MemoryEntity>>(listType)

    fun getPublicGToolFolder(context: Context, subFolder: String = ""): File {
        val root = try {
            val docs = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
            val gtool = File(docs, "GTOOL X")
            if (!gtool.exists()) gtool.mkdirs()
            gtool
        } catch (e: Exception) {
            val fallback = File(context.getExternalFilesDir(null), "GTOOL X")
            if (!fallback.exists()) fallback.mkdirs()
            fallback
        }

        return if (subFolder.isNotBlank()) {
            val sub = File(root, subFolder)
            if (!sub.exists()) sub.mkdirs()
            sub
        } else root
    }

    private fun getBackupFile(context: Context): File {
        val backupDir = getPublicGToolFolder(context, "Backups")
        return File(backupDir, "gtool_backup.json")
    }

    fun getBackupInfo(context: Context): BackupInfo {
        val file = getBackupFile(context)
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val lastTimestamp = prefs.getString(KEY_LAST_BACKUP, "Never") ?: "Never"

        var itemCount = 0
        if (file.exists() && file.length() > 0) {
            try {
                val json = file.readText()
                val list = adapter.fromJson(json)
                itemCount = list?.size ?: 0
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        return BackupInfo(
            exists = file.exists() && file.length() > 0,
            filePath = file.absolutePath,
            lastBackupDate = lastTimestamp,
            fileSizeBytes = if (file.exists()) file.length() else 0L,
            itemCount = itemCount
        )
    }

    fun checkForExistingData(context: Context): Boolean {
        val backupFile = getBackupFile(context)
        if (backupFile.exists() && backupFile.length() > 0) return true

        val docsDir = getPublicGToolFolder(context)
        val docsFiles = docsDir.listFiles()
        return docsFiles != null && docsFiles.isNotEmpty()
    }

    suspend fun createLocalBackup(context: Context, memoryDao: MemoryDao): BackupResult = withContext(Dispatchers.IO) {
        try {
            val file = getBackupFile(context)
            val entities = memoryDao.getAllMemoriesList()
            val json = adapter.toJson(entities)
            file.writeText(json)

            val nowStr = SimpleDateFormat("MMM dd, yyyy • HH:mm", Locale.getDefault()).format(Date())
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_LAST_BACKUP, nowStr)
                .apply()

            BackupResult(
                success = true,
                filePath = file.absolutePath,
                itemCount = entities.size
            )
        } catch (e: Exception) {
            e.printStackTrace()
            BackupResult(
                success = false,
                filePath = getBackupFile(context).absolutePath,
                itemCount = 0,
                errorMessage = e.message ?: "Backup failed"
            )
        }
    }

    suspend fun restoreBackup(context: Context, memoryDao: MemoryDao): Int = withContext(Dispatchers.IO) {
        try {
            val file = getBackupFile(context)
            if (!file.exists()) return@withContext 0

            val json = file.readText()
            val list = adapter.fromJson(json) ?: return@withContext 0

            var count = 0
            list.forEach { entity ->
                memoryDao.insertMemory(entity)
                memoryDao.insertFts(
                    MemoryFtsEntity(
                        id = entity.id,
                        title = entity.title,
                        extractedText = entity.extractedText
                    )
                )
                count++
            }
            count
        } catch (e: Exception) {
            e.printStackTrace()
            0
        }
    }
}
