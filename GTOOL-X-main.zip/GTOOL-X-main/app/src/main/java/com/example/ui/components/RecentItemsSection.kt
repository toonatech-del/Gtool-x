package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowForward
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.PictureAsPdf
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ItemType
import com.example.model.WorkspaceItem
import com.example.ui.theme.AmberGlow
import com.example.ui.theme.AmberWarm
import com.example.ui.theme.ImagePurple
import com.example.ui.theme.NoteYellow
import com.example.ui.theme.PdfRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarmGold

import com.example.ui.theme.LocalIsDarkMode

@Composable
fun RecentItemsSection(
    items: List<WorkspaceItem>,
    onItemClick: (WorkspaceItem) -> Unit,
    onTogglePin: (WorkspaceItem) -> Unit,
    onDeleteClick: (WorkspaceItem) -> Unit = {},
    onAddMemoryClick: () -> Unit = {},
    selectedFilter: ItemType = ItemType.ALL,
    modifier: Modifier = Modifier
) {
    val isDarkMode = LocalIsDarkMode.current
    val headerColor = if (isDarkMode) Color(0xFFE6E5DF) else Color(0xFF000000)
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .testTag("recent_items_section")
    ) {
        // Section Header with large clear text
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "Recent items",
                    style = MaterialTheme.typography.displayMedium.copy(
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 24.sp,
                        letterSpacing = (-0.4).sp,
                        color = headerColor
                    ),
                    modifier = Modifier.testTag("recent_items_title")
                )
                Text(
                    text = if (items.isNotEmpty()) "Quick access to your latest files & notes" else "Your saved memories and indexed documents",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = if (isDarkMode) TextSecondary else Color(0xFF333333),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                )
            }

            if (items.isNotEmpty()) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0x18FFFFFF))
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = "${items.size} files",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = WarmGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (items.isEmpty()) {
            val emptyTitle = when (selectedFilter) {
                ItemType.PDF -> "No PDFs saved yet"
                ItemType.IMAGE -> "No images saved yet"
                ItemType.NOTE -> "No notes saved yet"
                else -> "No memories saved yet"
            }
            // Minimalist frosted glass empty-state card
            MinimalistEmptyStateCard(
                title = emptyTitle,
                onAddClick = onAddMemoryClick
            )
        } else {
            // Translucent cards list
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items.forEach { item ->
                    RecentTranslucentCard(
                        item = item,
                        onClick = { onItemClick(item) },
                        onTogglePin = { onTogglePin(item) },
                        onDeleteClick = { onDeleteClick(item) }
                    )
                }
            }
        }
    }
}

/**
 * Minimalist frosted glass empty-state card
 * Features clean minimalist folder/sparkle icon, warm dark charcoal frosted glassmorphism,
 * 1px white border stroke, and large typography styling.
 */
@Composable
fun MinimalistEmptyStateCard(
    onAddClick: () -> Unit,
    title: String = "No memories saved yet",
    modifier: Modifier = Modifier
) {
    GlassCard(
        modifier = modifier
            .fillMaxWidth()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(color = AmberWarm.copy(alpha = 0.2f)),
                onClick = onAddClick
            )
            .testTag("empty_state_card"),
        shape = RoundedCornerShape(24.dp),
        borderStrokeWidth = 1.dp,
        borderColorList = listOf(
            Color(0x55FFFFFF),
            Color(0x18FFFFFF),
            Color(0x35FFFFFF)
        ),
        backgroundGradient = listOf(
            Color(0x22FFFFFF),
            Color(0x12FFFFFF),
            Color(0x0CFFFFFF)
        ),
        ambientGlowColor = AmberWarm
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 36.dp, horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Minimalist folder/sparkle icon with warm amber ring
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(Color(0x35FF9E58), Color(0x12FF9E58))
                        )
                    )
                    .border(
                        1.dp,
                        Brush.linearGradient(
                            listOf(AmberWarm.copy(alpha = 0.8f), Color(0x25FFFFFF))
                        ),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Outlined.FolderOpen,
                        contentDescription = "Empty memory vault",
                        tint = AmberWarm,
                        modifier = Modifier.size(28.dp)
                    )
                    Icon(
                        imageVector = Icons.Outlined.AutoAwesome,
                        contentDescription = null,
                        tint = WarmGold,
                        modifier = Modifier
                            .size(14.dp)
                            .align(Alignment.TopEnd)
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Title
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 19.sp,
                    letterSpacing = (-0.3).sp,
                    fontFamily = FontFamily.SansSerif,
                    color = TextPrimary
                ),
                modifier = Modifier.testTag("empty_state_title")
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Subtitle: 'Tap + Add Memory to save your first note, PDF, or photo.'
            Text(
                text = "Tap + Add Memory to save your first note, PDF, or photo.",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = TextSecondary,
                    fontSize = 13.sp,
                    lineHeight = 19.sp,
                    textAlign = TextAlign.Center
                ),
                modifier = Modifier.testTag("empty_state_subtitle")
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Action Pill Button
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.horizontalGradient(listOf(AmberWarm, AmberGlow))
                    )
                    .border(1.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = ripple(color = Color.White.copy(alpha = 0.35f)),
                        onClick = onAddClick
                    )
                    .padding(horizontal = 20.dp, vertical = 10.dp)
                    .testTag("empty_state_add_button")
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Outlined.Add,
                        contentDescription = null,
                        tint = Color(0xFF0F0E11),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "+ Add Memory",
                        style = MaterialTheme.typography.labelLarge.copy(
                            color = Color(0xFF0F0E11),
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 13.sp
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun RecentTranslucentCard(
    item: WorkspaceItem,
    onClick: () -> Unit,
    onTogglePin: () -> Unit,
    onDeleteClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val isDarkMode = LocalIsDarkMode.current
    val (typeColor, typeIcon) = when (item.type) {
        ItemType.PDF -> Pair(PdfRed, Icons.Outlined.PictureAsPdf)
        ItemType.NOTE -> Pair(NoteYellow, Icons.Outlined.Description)
        ItemType.IMAGE -> Pair(ImagePurple, Icons.Outlined.Image)
        else -> Pair(AmberWarm, Icons.Outlined.Description)
    }

    val cardTitleColor = if (isDarkMode) TextPrimary else Color(0xFF111111)
    val cardSubtitleColor = if (isDarkMode) TextSecondary else Color(0xFF333333)
    val cardMutedColor = if (isDarkMode) TextMuted else Color(0xFF4A4A4A)

    GlassCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag("recent_card_${item.id}"),
        shape = RoundedCornerShape(22.dp),
        borderStrokeWidth = 1.dp,
        ambientGlowColor = typeColor,
        onClick = onClick
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Type Icon Box with smooth ambient glow
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(typeColor.copy(alpha = 0.28f), typeColor.copy(alpha = 0.08f))
                            )
                        )
                        .border(
                            1.dp,
                            typeColor.copy(alpha = 0.45f),
                            RoundedCornerShape(14.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = typeIcon,
                        contentDescription = item.type.label,
                        tint = typeColor,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                // Title & Subtitle
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = item.title,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            letterSpacing = (-0.2).sp,
                            color = cardTitleColor
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.testTag("recent_item_title_${item.id}")
                    )

                    Spacer(modifier = Modifier.height(2.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = item.sizeText,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = cardMutedColor,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        )
                        Text(
                            text = " • ",
                            color = cardMutedColor,
                            fontSize = 12.sp
                        )
                        Text(
                            text = item.dateModified,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = cardSubtitleColor,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    // Pin Button
                    IconButton(
                        onClick = onTogglePin,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (item.isPinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                            contentDescription = if (item.isPinned) "Unpin" else "Pin",
                            tint = if (item.isPinned) AmberWarm else cardMutedColor,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Subtitle / snippet
            Text(
                text = item.subtitle,
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = cardSubtitleColor,
                    fontSize = 13.sp,
                    lineHeight = 18.sp,
                    fontWeight = FontWeight.Medium
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(10.dp))

            // AI Insight Chip & Action footer
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Frosted AI pill
                Box(
                    modifier = Modifier
                        .weight(1f, fill = false)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0x18FFFFFF))
                        .border(1.dp, Color(0x28FFFFFF), RoundedCornerShape(10.dp))
                        .padding(horizontal = 9.dp, vertical = 4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "✦",
                            color = WarmGold,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = item.summary,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = WarmGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Sync Status Badge Pill ('Local Only' or 'Synced to Drive')
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (item.isSyncedToDrive) Color(0x2234D399) else Color(0x22FF9E58))
                            .border(1.dp, if (item.isSyncedToDrive) Color(0x6634D399) else Color(0x44FF9E58), RoundedCornerShape(10.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = if (item.isSyncedToDrive) "☁ Synced to Drive" else "📱 Local Only",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = if (item.isSyncedToDrive) Color(0xFF6EE7B7) else WarmGold,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Chevron icon
                    Icon(
                        imageVector = Icons.AutoMirrored.Outlined.ArrowForward,
                        contentDescription = "Open item",
                        tint = TextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}
