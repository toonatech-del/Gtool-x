package com.example.data.auth

import com.example.BuildConfig

/**
 * Firebase & Google Identity Configuration.
 *
 * All credentials are fully externalized to BuildConfig / .env / Secrets panel:
 * - FIREBASE_API_KEY
 * - FIREBASE_PROJECT_ID
 * - FIREBASE_AUTH_DOMAIN
 * - FIREBASE_APP_ID
 * - FIREBASE_WEB_CLIENT_ID
 *
 * Never hardcode real API keys or sensitive project IDs in source files.
 */
object FirebaseConfig {
    const val DEFAULT_API_KEY = ""
    const val DEFAULT_AUTH_DOMAIN = ""
    const val DEFAULT_PROJECT_ID = ""
    const val DEFAULT_APP_ID = ""
    const val DEFAULT_WEB_CLIENT_ID = ""

    val apiKey: String
        get() = try {
            val key = BuildConfig::class.java.getField("FIREBASE_API_KEY").get(null) as? String
            if (!key.isNullOrBlank() && !key.startsWith("YOUR_")) key.trim() else DEFAULT_API_KEY
        } catch (_: Exception) {
            DEFAULT_API_KEY
        }

    val authDomain: String
        get() = try {
            val domain = BuildConfig::class.java.getField("FIREBASE_AUTH_DOMAIN").get(null) as? String
            if (!domain.isNullOrBlank() && !domain.startsWith("YOUR_")) domain.trim() else DEFAULT_AUTH_DOMAIN
        } catch (_: Exception) {
            DEFAULT_AUTH_DOMAIN
        }

    val projectId: String
        get() = try {
            val proj = BuildConfig::class.java.getField("FIREBASE_PROJECT_ID").get(null) as? String
            if (!proj.isNullOrBlank() && !proj.startsWith("YOUR_")) proj.trim() else DEFAULT_PROJECT_ID
        } catch (_: Exception) {
            DEFAULT_PROJECT_ID
        }

    val appId: String
        get() = try {
            val id = BuildConfig::class.java.getField("FIREBASE_APP_ID").get(null) as? String
            if (!id.isNullOrBlank() && !id.startsWith("YOUR_")) id.trim() else DEFAULT_APP_ID
        } catch (_: Exception) {
            DEFAULT_APP_ID
        }

    val webClientId: String
        get() = try {
            val client = BuildConfig::class.java.getField("FIREBASE_WEB_CLIENT_ID").get(null) as? String
            if (!client.isNullOrBlank() && !client.startsWith("YOUR_")) client.trim() else DEFAULT_WEB_CLIENT_ID
        } catch (_: Exception) {
            DEFAULT_WEB_CLIENT_ID
        }
}
