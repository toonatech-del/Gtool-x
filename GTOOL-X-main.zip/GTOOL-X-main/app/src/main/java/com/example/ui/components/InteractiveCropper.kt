package com.example.ui.components

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput

@Composable
fun InteractiveCropper(
    bitmap: Bitmap,
    aspectRatio: Float?, // null for free crop
    onCropResult: (Bitmap) -> Unit,
    modifier: Modifier = Modifier
) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    Box(
        modifier = modifier
            .pointerInput(Unit) {
                detectTransformGestures { _, pan, zoom, _ ->
                    scale = (scale * zoom).coerceIn(0.5f, 3f)
                    offset += pan
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawImage(
                image = bitmap.asImageBitmap(),
                topLeft = offset,
                alpha = 1f
            )
            
            // Draw crop overlay rectangle
            val canvasSize = Size(size.width, size.height)
            val rectSize = if (aspectRatio != null) {
                val h = size.width / aspectRatio
                Size(size.width, h)
            } else {
                Size(size.width * 0.8f, size.height * 0.8f)
            }
            
            drawRect(
                color = Color.White.copy(alpha = 0.5f),
                topLeft = Offset((size.width - rectSize.width) / 2, (size.height - rectSize.height) / 2),
                size = rectSize,
                style = Stroke(width = 4f)
            )
        }
    }
}
