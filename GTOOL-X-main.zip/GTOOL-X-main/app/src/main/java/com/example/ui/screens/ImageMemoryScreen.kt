package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Bolt
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.CreditCard
import androidx.compose.material.icons.outlined.DateRange
import androidx.compose.material.icons.outlined.DocumentScanner
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Fullscreen
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.PhotoCamera
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage
import com.example.ui.components.AmbientLightingBackground
import com.example.ui.components.GlassCard
import com.example.ui.theme.AmberGlow
import com.example.ui.theme.AmberWarm
import com.example.ui.theme.GlassStroke
import com.example.ui.theme.SyncGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarmGold
import com.example.util.MlKitTextExtractor
import android.net.Uri
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImageMemoryScreen(
    imageUri: String? = null,
    onBackClick: () -> Unit,
    onSaveExtractedMemory: (docName: String, amount: String, dueDate: String, includeInSearch: Boolean) -> Unit = { _, _, _, _ -> },
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    // Editable OCR structured data points
    var docName by remember(imageUri) {
        mutableStateOf("")
    }
    var amountText by remember { mutableStateOf("") }
    var dueDateText by remember { mutableStateOf("") }
    var extractedFullOcrText by remember { mutableStateOf("") }
    var isOcrExtracting by remember { mutableStateOf(false) }

    // Run real on-device Google ML Kit Text Recognition on the image
    LaunchedEffect(imageUri) {
        if (!imageUri.isNullOrBlank()) {
            isOcrExtracting = true
            try {
                val recognizedText = MlKitTextExtractor.extractTextFromUri(context, Uri.parse(imageUri))
                if (recognizedText.isNotBlank()) {
                    extractedFullOcrText = recognizedText
                    // Parse first meaningful line as title if generic
                    val lines = recognizedText.lines().map { it.trim() }.filter { it.isNotBlank() }
                    if (lines.isNotEmpty()) {
                        docName = lines.first().take(40)
                    }
                    // Look for amount patterns (e.g. ₹, $, total, rs)
                    val amountLine = lines.firstOrNull { it.contains("₹") || it.contains("$") || it.contains("total", ignoreCase = true) || it.contains("amount", ignoreCase = true) }
                    if (amountLine != null) {
                        amountText = amountLine
                    }
                    // Look for date patterns
                    val dateLine = lines.firstOrNull { it.contains("date", ignoreCase = true) || it.contains("due", ignoreCase = true) }
                    if (dateLine != null) {
                        dueDateText = dateLine
                    }
                }
            } catch (ignored: Exception) {
            } finally {
                isOcrExtracting = false
            }
        }
    }

    // Toggle for 'Include in AI Semantic Search'
    var includeInSemanticSearch by remember { mutableStateOf(true) }

    androidx.activity.compose.BackHandler {
        onBackClick()
    }

    // Dialog state for editing a field
    var fieldToEdit by remember { mutableStateOf<Pair<String, String>?>(null) }
    var showFullPhotoModal by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    AmbientLightingBackground {
        Scaffold(
            containerColor = Color.Transparent,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            modifier = modifier
                .fillMaxSize()
                .testTag("image_memory_screen"),
            topBar = {
                ImageMemoryTopBar(
                    onBackClick = onBackClick,
                    onSaveClick = {
                        onSaveExtractedMemory(
                            docName,
                            amountText,
                            dueDateText,
                            includeInSemanticSearch
                        )
                    }
                )
            },
            bottomBar = {
                // Bottom Capsule Button: 'Save Memory'
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .clip(RoundedCornerShape(27.dp))
                            .background(
                                Brush.horizontalGradient(
                                    listOf(AmberWarm, AmberGlow)
                                )
                            )
                            .border(
                                1.dp,
                                Color.White.copy(alpha = 0.5f),
                                RoundedCornerShape(27.dp)
                            )
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = ripple(color = Color.White.copy(alpha = 0.4f)),
                                onClick = {
                                    onSaveExtractedMemory(
                                        docName,
                                        amountText,
                                        dueDateText,
                                        includeInSemanticSearch
                                    )
                                    coroutineScope.launch {
                                        snackbarHostState.showSnackbar("Memory saved to Neural Vault ⚡")
                                    }
                                }
                            )
                            .testTag("save_extracted_memory_button")
                            .testTag("save_memory_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Outlined.CheckCircle,
                                contentDescription = null,
                                tint = Color(0xFF0F0E11),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Save Memory",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    color = Color(0xFF0F0E11),
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 16.sp,
                                    letterSpacing = 0.2.sp
                                ),
                                modifier = Modifier.testTag("save_extracted_memory_text")
                            )
                        }
                    }
                }
            }
        ) { paddingValues ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentPadding = PaddingValues(
                    start = 20.dp,
                    end = 20.dp,
                    top = 8.dp,
                    bottom = 24.dp
                )
            ) {
                // Header Title: 'Image Memories' in bold header font
                item(key = "title_section") {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            // OCR Status Pill
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0x28FF9E58))
                                    .border(
                                        1.dp,
                                        Brush.linearGradient(
                                            listOf(AmberWarm.copy(alpha = 0.6f), Color(0x30FFA767))
                                        ),
                                        RoundedCornerShape(12.dp)
                                    )
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(CircleShape)
                                            .background(SyncGreen)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (isOcrExtracting) "Scanning text..." else if (extractedFullOcrText.isNotBlank()) "Text Extracted ✓" else "Google ML Kit OCR",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = WarmGold,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                            }

                            Text(
                                text = "Image Vault",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = TextMuted,
                                    fontSize = 11.sp
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "Image Memories",
                            style = MaterialTheme.typography.displayLarge.copy(
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 32.sp,
                                letterSpacing = (-0.8).sp,
                                fontFamily = FontFamily.SansSerif,
                                color = TextPrimary
                            ),
                            modifier = Modifier.testTag("image_memories_title")
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "Visual document archive with automatic text recognition",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = TextSecondary,
                                fontSize = 13.sp
                            )
                        )
                    }
                }

                // Title input field
                item(key = "title_input_section") {
                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "TITLE",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = WarmGold,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            letterSpacing = 0.8.sp
                        )
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0x20FFFFFF))
                            .border(1.dp, GlassStroke, RoundedCornerShape(16.dp))
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                    ) {
                        if (docName.isEmpty()) {
                            Text(
                                text = "Title (Optional)",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    color = TextMuted,
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 15.sp
                                )
                            )
                        }
                        BasicTextField(
                            value = docName,
                            onValueChange = { docName = it },
                            textStyle = MaterialTheme.typography.titleMedium.copy(
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            ),
                            cursorBrush = SolidColor(AmberWarm),
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("image_memory_title_input")
                        )
                    }
                }

                // Top Section: Photo preview card inside rounded frosted border
                item(key = "utility_bill_photo_card") {
                    Spacer(modifier = Modifier.height(18.dp))

                    Text(
                        text = "DOCUMENT PHOTO",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextMuted,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            letterSpacing = 0.8.sp
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    ElectricityBillPhotoCard(
                        imageUri = imageUri,
                        onInspectClick = { showFullPhotoModal = true }
                    )
                }

                // Bottom Section: AI OCR extraction card in translucent glass with structured data
                item(key = "ai_ocr_extraction_card") {
                    Spacer(modifier = Modifier.height(22.dp))

                    Text(
                        text = "AI OCR EXTRACTION",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = WarmGold,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            letterSpacing = 0.8.sp
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    AiOcrExtractionCard(
                        docName = docName,
                        amount = amountText,
                        dueDate = dueDateText,
                        onEditDocName = { fieldToEdit = Pair("Document Name", docName) },
                        onEditAmount = { fieldToEdit = Pair("Amount", amountText) },
                        onEditDueDate = { fieldToEdit = Pair("Due Date", dueDateText) }
                    )
                }

                // Toggle for 'Include in AI Semantic Search'
                item(key = "semantic_search_toggle") {
                    Spacer(modifier = Modifier.height(16.dp))

                    SemanticSearchToggleCard(
                        checked = includeInSemanticSearch,
                        onCheckedChange = { includeInSemanticSearch = it }
                    )
                }
            }
        }
    }

    // Inline Field Edit Dialog
    if (fieldToEdit != null) {
        val (fieldName, currentValue) = fieldToEdit!!
        EditDataPointDialog(
            label = fieldName,
            initialValue = currentValue,
            onDismiss = { fieldToEdit = null },
            onSave = { updated ->
                when (fieldName) {
                    "Document Name" -> docName = updated
                    "Amount" -> amountText = updated
                    "Due Date" -> dueDateText = updated
                }
                fieldToEdit = null
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("Updated $fieldName to \"$updated\"")
                }
            }
        )
    }

    // Full photo modal
    if (showFullPhotoModal) {
        FullPhotoModal(
            imageUri = imageUri,
            docName = docName,
            onDismiss = { showFullPhotoModal = false }
        )
    }
}

/**
 * Top bar with frosted back button and actions
 */
@Composable
private fun ImageMemoryTopBar(
    onBackClick: () -> Unit,
    onSaveClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.statusBars)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Frosted circular back button
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(Color(0x22FFFFFF))
                .border(1.dp, GlassStroke, CircleShape)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = ripple(color = Color.White.copy(alpha = 0.3f)),
                    onClick = onBackClick
                )
                .testTag("image_memory_back_button"),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
                contentDescription = "Back",
                tint = TextPrimary,
                modifier = Modifier.size(20.dp)
            )
        }

        // Save Pill Button in Top Bar
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(
                    Brush.horizontalGradient(listOf(AmberWarm, AmberGlow))
                )
                .border(1.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = ripple(color = Color.White.copy(alpha = 0.35f)),
                    onClick = onSaveClick
                )
                .padding(horizontal = 18.dp, vertical = 8.dp)
                .testTag("top_bar_save_image_button")
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Outlined.Check,
                    contentDescription = null,
                    tint = Color(0xFF0F0E11),
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Save",
                    style = MaterialTheme.typography.labelLarge.copy(
                        color = Color(0xFF0F0E11),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.sp
                    )
                )
            }
        }
    }
}

/**
 * Top section: Image photo housed inside a rounded frosted border card
 */
@Composable
private fun ElectricityBillPhotoCard(
    imageUri: String? = null,
    onInspectClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    GlassCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag("electricity_bill_photo_card"),
        shape = RoundedCornerShape(24.dp),
        borderStrokeWidth = 1.dp,
        borderColorList = listOf(
            Color(0x90FFFFFF),
            Color(0x25FFFFFF),
            Color(0x45FFFFFF)
        ),
        backgroundGradient = listOf(
            Color(0x25FFFFFF),
            Color(0x12FFFFFF),
            Color(0x08FFFFFF)
        ),
        ambientGlowColor = AmberWarm
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            if (!imageUri.isNullOrBlank()) {
                // Render selected image preview inside a rounded frosted border
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(230.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(Color(0x40000000))
                        .border(
                            1.dp,
                            Brush.linearGradient(
                                listOf(Color(0x80FFB87E), Color(0x30FFA767), Color(0x50FFFFFF))
                            ),
                            RoundedCornerShape(18.dp)
                        )
                ) {
                    AsyncImage(
                        model = imageUri,
                        contentDescription = "Selected Document Photo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(RoundedCornerShape(18.dp))
                    )

                    // Gradient footer with inspect button
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter)
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color.Transparent, Color(0xB3000000))
                                )
                            )
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "High-Res Image • OCR Ready",
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0x33FFFFFF))
                                    .border(1.dp, Color(0x55FFFFFF), RoundedCornerShape(8.dp))
                                    .clickable(onClick = onInspectClick)
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Outlined.Fullscreen,
                                        contentDescription = "Preview",
                                        tint = WarmGold,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "Preview",
                                        color = WarmGold,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                // Clean empty dropzone when no image is selected yet
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(Color(0x1A000000))
                        .border(
                            1.dp,
                            Brush.linearGradient(
                                listOf(Color(0x40FFFFFF), Color(0x15FFFFFF))
                            ),
                            RoundedCornerShape(18.dp)
                        )
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(52.dp)
                                .clip(CircleShape)
                                .background(Color(0x22FF9E58))
                                .border(1.dp, AmberWarm.copy(alpha = 0.5f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.PhotoCamera,
                                contentDescription = "Tap to capture or upload",
                                tint = AmberWarm,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "Tap to capture or upload",
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        )

                        Text(
                            text = "Scan document with camera or pick photo from gallery",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextSecondary,
                                fontSize = 12.sp
                            )
                        )
                    }
                }
            }
        }
    }
}

/**
 * Bottom section: AI OCR extraction card in translucent glass
 */
@Composable
private fun AiOcrExtractionCard(
    docName: String,
    amount: String,
    dueDate: String,
    onEditDocName: () -> Unit,
    onEditAmount: () -> Unit,
    onEditDueDate: () -> Unit,
    modifier: Modifier = Modifier
) {
    GlassCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag("ai_ocr_extraction_card"),
        shape = RoundedCornerShape(24.dp),
        borderStrokeWidth = 1.dp,
        borderColorList = listOf(
            Color(0x90FFFFFF),
            Color(0x25FFFFFF),
            Color(0x45FFFFFF)
        ),
        backgroundGradient = listOf(
            Color(0x28FFFFFF),
            Color(0x14FFFFFF),
            Color(0x0CFFFFFF)
        ),
        ambientGlowColor = AmberWarm
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0x26FF9E58)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.AutoAwesome,
                            contentDescription = null,
                            tint = AmberWarm,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Text(
                        text = "EXTRACTED METADATA",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = WarmGold,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            letterSpacing = 0.8.sp
                        )
                    )
                }

                val hasData = docName.isNotBlank() || amount.isNotBlank() || dueDate.isNotBlank()
                if (hasData) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0x18FFFFFF))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "OCR Fields Available",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = TextSecondary,
                                fontSize = 10.sp
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (docName.isBlank() && amount.isBlank() && dueDate.isBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No text detected yet",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = TextMuted,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }
            } else {
                if (docName.isNotBlank()) {
                    StructuredDataRow(
                        fieldLabel = "DOCUMENT TYPE / TITLE",
                        valueText = docName,
                        icon = Icons.Outlined.ReceiptLong,
                        accentColor = AmberWarm,
                        onEditClick = onEditDocName,
                        tagId = "edit_doc_name"
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }

                if (amount.isNotBlank()) {
                    StructuredDataRow(
                        fieldLabel = "AMOUNT DUE",
                        valueText = if (amount.startsWith("Amount:")) amount else "Amount: $amount",
                        icon = Icons.Outlined.CreditCard,
                        accentColor = WarmGold,
                        onEditClick = onEditAmount,
                        tagId = "edit_amount"
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }

                if (dueDate.isNotBlank()) {
                    StructuredDataRow(
                        fieldLabel = "PAYMENT DUE DATE",
                        valueText = if (dueDate.startsWith("Due Date:")) dueDate else "Due Date: $dueDate",
                        icon = Icons.Outlined.DateRange,
                        accentColor = Color(0xFF38BDF8),
                        onEditClick = onEditDueDate,
                        tagId = "edit_due_date"
                    )
                }
            }
        }
    }
}

/**
 * Row displaying an individual extracted data point with bold typography and a small edit pencil icon
 */
@Composable
private fun StructuredDataRow(
    fieldLabel: String,
    valueText: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    onEditClick: () -> Unit,
    tagId: String
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(
                Brush.linearGradient(
                    listOf(Color(0x22FFFFFF), Color(0x0CFFFFFF))
                )
            )
            .border(
                1.dp,
                Brush.linearGradient(
                    listOf(Color(0x40FFFFFF), Color(0x15FFFFFF))
                ),
                RoundedCornerShape(16.dp)
            )
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                // Leading Icon Container
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(accentColor.copy(alpha = 0.15f))
                        .border(1.dp, accentColor.copy(alpha = 0.3f), RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = fieldLabel,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = TextMuted,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.6.sp
                        )
                    )

                    Spacer(modifier = Modifier.height(2.dp))

                    // Clear bold structured data
                    Text(
                        text = valueText,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 16.sp,
                            color = TextPrimary,
                            fontFamily = FontFamily.SansSerif
                        ),
                        modifier = Modifier.testTag("text_$tagId")
                    )
                }
            }

            // Small edit pencil icon
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(Color(0x1AFFFFFF))
                    .border(1.dp, GlassStroke, CircleShape)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = ripple(color = AmberWarm.copy(alpha = 0.4f)),
                        onClick = onEditClick
                    )
                    .testTag(tagId),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Outlined.Edit,
                    contentDescription = "Edit $fieldLabel",
                    tint = AmberWarm,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

/**
 * Card with active toggle for 'Include in AI Semantic Search'
 */
@Composable
private fun SemanticSearchToggleCard(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.linearGradient(
                    listOf(Color(0x28FFFFFF), Color(0x10FFFFFF))
                )
            )
            .border(
                1.dp,
                Brush.linearGradient(
                    listOf(
                        if (checked) AmberWarm.copy(alpha = 0.5f) else Color(0x30FFFFFF),
                        Color(0x15FFFFFF)
                    )
                ),
                RoundedCornerShape(20.dp)
            )
            .padding(16.dp)
            .testTag("semantic_search_toggle_card")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0x26FF9E58)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Search,
                        contentDescription = null,
                        tint = AmberWarm,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = "Include in AI Semantic Search",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = TextPrimary
                        ),
                        modifier = Modifier.testTag("semantic_search_label")
                    )

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = "Index text for queries like 'Find my electricity bill'",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Active toggle switch
            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color(0xFF0F0E11),
                    checkedTrackColor = AmberWarm,
                    uncheckedThumbColor = Color(0xFF888888),
                    uncheckedTrackColor = Color(0x33FFFFFF)
                ),
                modifier = Modifier.testTag("semantic_search_switch")
            )
        }
    }
}

/**
 * Dialog to edit a data point
 */
@Composable
private fun EditDataPointDialog(
    label: String,
    initialValue: String,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    // Strip prefixes like "Amount: " or "Due Date: " when editing
    val cleanInitial = initialValue
        .removePrefix("Amount: ")
        .removePrefix("Due Date: ")

    var textValue by remember { mutableStateOf(cleanInitial) }

    androidx.activity.compose.BackHandler {
        onDismiss()
    }

    Dialog(onDismissRequest = onDismiss) {
        GlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("edit_data_point_dialog"),
            shape = RoundedCornerShape(24.dp),
            borderStrokeWidth = 1.dp,
            borderColorList = listOf(Color(0x90FFFFFF), Color(0x30FFFFFF)),
            ambientGlowColor = AmberWarm
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(22.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Edit $label",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = TextPrimary
                        )
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = textValue,
                    onValueChange = { textValue = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("edit_field_input"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = AmberWarm,
                        unfocusedBorderColor = Color(0x40FFFFFF),
                        cursorColor = AmberWarm
                    ),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0x20FFFFFF),
                            contentColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Cancel")
                    }

                    Button(
                        onClick = {
                            if (textValue.isNotBlank()) {
                                onSave(textValue.trim())
                            }
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AmberWarm,
                            contentColor = Color(0xFF0F0E11)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Save", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

/**
 * Fullscreen Photo Preview Modal
 */
@Composable
private fun FullPhotoModal(
    imageUri: String? = null,
    docName: String? = null,
    onDismiss: () -> Unit
) {
    androidx.activity.compose.BackHandler {
        onDismiss()
    }

    Dialog(onDismissRequest = onDismiss) {
        GlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("full_photo_modal"),
            shape = RoundedCornerShape(26.dp),
            borderStrokeWidth = 1.dp,
            borderColorList = listOf(Color(0x90FFFFFF), Color(0x30FFFFFF)),
            ambientGlowColor = AmberWarm
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (!docName.isNullOrBlank()) docName else "Document Photo Preview",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary,
                            fontSize = 15.sp
                        )
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0x22000000))
                        .border(1.dp, Color(0x33FFB87E), RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (!imageUri.isNullOrBlank()) {
                        AsyncImage(
                            model = imageUri,
                            contentDescription = "Full photo preview",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Outlined.Image,
                                contentDescription = null,
                                tint = AmberWarm,
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "NO IMAGE SOURCE AVAILABLE",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = WarmGold,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            Brush.linearGradient(listOf(AmberWarm, AmberGlow))
                        )
                        .clickable(onClick = onDismiss)
                        .padding(vertical = 11.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Close",
                        style = MaterialTheme.typography.labelLarge.copy(
                            color = Color(0xFF0F0E11),
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }
    }
}
