package com.example.ui

import android.app.Application
import android.net.Uri
import java.io.File
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.MemoryRepository
import com.example.model.ChatMessage
import com.example.model.CitationSource
import com.example.model.CurrentScreen
import com.example.model.ItemType
import com.example.model.MessageSender
import com.example.model.NotificationItem
import com.example.model.StorageData
import com.example.model.WorkspaceItem
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

import com.example.util.GoogleDriveSyncManager

@OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
class GsdcallWorkspaceViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = MemoryRepository(application.applicationContext)
    private val googleDriveSyncManager = GoogleDriveSyncManager(application.applicationContext)

    private val _currentScreen = MutableStateFlow(CurrentScreen.HOME)
    val currentScreen: StateFlow<CurrentScreen> = _currentScreen

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    private val _selectedFilter = MutableStateFlow(ItemType.ALL)
    val selectedFilter: StateFlow<ItemType> = _selectedFilter

    // Local room database flow of memories
    val recentItems: StateFlow<List<WorkspaceItem>> = repository.allMemories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val importantItems: StateFlow<List<WorkspaceItem>> = repository.importantMemories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /**
     * Real-time offline search with 250ms debounce connected to FTS4 SQLite table.
     * Matches wildcard tokens (e.g. *bike*, *salary*, *recharge*, *1240*).
     */
    val searchResults: StateFlow<List<WorkspaceItem>> = _searchQuery
        .debounce(250)
        .flatMapLatest { query ->
            repository.searchMemories(query)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _storageData = MutableStateFlow(
        StorageData(
            usedGb = 0.0,
            totalGb = 15.0,
            pdfsGb = 0.0,
            imagesGb = 0.0,
            notesGb = 0.0,
            isOfflineReady = true,
            isGoogleDriveSynced = true,
            lastSyncTime = "Just now",
            syncAccountEmail = "user@example.com",
            syncStatusText = "☁ Synced to Google Drive"
        )
    )
    val storageData: StateFlow<StorageData> = _storageData

    private val _notifications = MutableStateFlow(emptyList<NotificationItem>())
    val notifications: StateFlow<List<NotificationItem>> = _notifications

    // Filtered Recent Items when no search query is active
    val filteredRecentItems: StateFlow<List<WorkspaceItem>> = combine(
        recentItems,
        _selectedFilter
    ) { items, filter ->
        items.filter { item ->
            filter == ItemType.ALL || item.type == filter
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Important Items
    val filteredImportantItems: StateFlow<List<WorkspaceItem>> = importantItems

    fun updateNote(title: String, bullets: List<String>) {
        viewModelScope.launch {
            repository.saveNote(
                title = title,
                content = bullets.joinToString("\n• ", prefix = "• "),
                tags = listOf("#note"),
                hasAttachment = false,
                includeInSemanticSearch = true
            )
            updateStorageUsage()
        }
    }

    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
    }

    fun onFilterSelected(type: ItemType) {
        _selectedFilter.value = if (_selectedFilter.value == type && type != ItemType.ALL) {
            ItemType.ALL
        } else {
            type
        }
    }

    fun togglePin(item: WorkspaceItem) {
        viewModelScope.launch {
            repository.togglePin(item)
        }
    }

    private val _chatMessages = MutableStateFlow(emptyList<ChatMessage>())
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages

    fun navigateTo(screen: CurrentScreen) {
        _currentScreen.value = screen
    }

    fun sendChatMessage(query: String) {
        val userMsgId = "msg-${System.currentTimeMillis()}"
        val userMsg = ChatMessage(
            id = userMsgId,
            sender = MessageSender.USER,
            text = query,
            timestamp = "Just now"
        )
        _chatMessages.value = _chatMessages.value + userMsg

        viewModelScope.launch {
            delay(350)
            val allItems = recentItems.value
            val matchingItems = allItems.filter { item ->
                item.title.contains(query, ignoreCase = true) ||
                        item.subtitle.contains(query, ignoreCase = true) ||
                        item.summary.contains(query, ignoreCase = true) ||
                        (item.contentSnippet?.contains(query, ignoreCase = true) == true)
            }

            val citations = matchingItems.map { item ->
                CitationSource(
                    id = item.id,
                    title = item.title,
                    type = item.type,
                    metaInfo = "${item.type.label} • ${item.dateModified}",
                    snippet = item.summary
                )
            }

            val responseText = if (matchingItems.isNotEmpty()) {
                val best = matchingItems.first()
                "Found in on-device FTS4 memory: \"${best.title}\" (${best.type.label}). ${best.summary}"
            } else {
                "No local memories matched \"$query\" in your offline database. Try typing keywords like note titles, document names, or receipt details."
            }

            val aiMsg = ChatMessage(
                id = "ai-${System.currentTimeMillis()}",
                sender = MessageSender.AI,
                text = responseText,
                timestamp = "Just now",
                citations = citations
            )
            _chatMessages.value = _chatMessages.value + aiMsg
        }
    }

    fun syncNow() {
        viewModelScope.launch {
            _storageData.value = _storageData.value.copy(
                syncStatusText = "Syncing with Google Drive..."
            )
            googleDriveSyncManager.performAppDataSync()
            _storageData.value = _storageData.value.copy(
                isOfflineReady = true,
                isGoogleDriveSynced = true,
                lastSyncTime = "Just now",
                syncStatusText = "☁ Synced to Google Drive"
            )
        }
    }

    fun uploadItemToGoogleDrive(item: WorkspaceItem) {
        viewModelScope.launch {
            googleDriveSyncManager.performAppDataSync()
            repository.markItemSyncedToDrive(item.id)
            _storageData.value = _storageData.value.copy(
                isOfflineReady = true,
                isGoogleDriveSynced = true,
                lastSyncTime = "Just now",
                syncStatusText = "☁ Synced to Google Drive"
            )
        }
    }

    fun deleteItemPermanently(item: WorkspaceItem) {
        viewModelScope.launch {
            repository.deleteMemory(item.id)
            if (!item.imageUri.isNullOrBlank()) {
                try {
                    val uri = Uri.parse(item.imageUri)
                    if (uri.scheme == "file") {
                        val file = File(uri.path ?: "")
                        if (file.exists()) file.delete()
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            if (item.isSyncedToDrive) {
                googleDriveSyncManager.deleteFromDriveAppData(item.driveFileId)
            }
            updateStorageUsage()
        }
    }

    fun addMemory(title: String, type: ItemType, isPrivate: Boolean) {
        viewModelScope.launch {
            when (type) {
                ItemType.NOTE -> {
                    repository.saveNote(
                        title = title,
                        content = "New blank note",
                        tags = if (isPrivate) listOf("#private") else listOf("#note"),
                        hasAttachment = false,
                        includeInSemanticSearch = true
                    )
                }
                ItemType.IMAGE -> {
                    repository.saveImageMemory(
                        title = title,
                        imageUri = null,
                        amount = "",
                        dueDate = "",
                        includeInSearch = true
                    )
                }
                ItemType.PDF -> {
                    repository.savePdfMemory(
                        title = title,
                        fileName = "$title.pdf",
                        fileSize = "1.2 MB",
                        summary = "Imported PDF document",
                        keyPoints = emptyList()
                    )
                }
                ItemType.VOICE -> {
                    repository.saveVoiceMemory(
                        title = title,
                        transcription = "Recorded voice note",
                        summary = "Voice note memory",
                        hasReminder = false
                    )
                }
                ItemType.ALL -> {
                    repository.saveNote(
                        title = title,
                        content = "Memory",
                        tags = emptyList(),
                        hasAttachment = false,
                        includeInSemanticSearch = true
                    )
                }
            }
            updateStorageUsage()
        }
    }

    fun saveFullNote(
        title: String,
        content: String,
        tags: List<String>,
        hasAttachment: Boolean,
        includeInSemanticSearch: Boolean,
        attachmentUri: String? = null
    ) {
        viewModelScope.launch {
            repository.saveNote(
                title = title,
                content = content,
                tags = tags,
                hasAttachment = hasAttachment,
                includeInSemanticSearch = includeInSemanticSearch,
                attachmentUri = attachmentUri
            )
            updateStorageUsage()
        }
    }

    fun savePdfDocument(
        title: String,
        fileName: String,
        fileSize: String,
        summary: String,
        keyPoints: List<String>,
        pdfUri: Uri? = null,
        includeInSearch: Boolean = true
    ) {
        viewModelScope.launch {
            repository.savePdfMemory(
                title = title,
                fileName = fileName,
                fileSize = fileSize,
                summary = summary,
                keyPoints = keyPoints,
                pdfUri = pdfUri,
                includeInSearch = includeInSearch
            )
            updateStorageUsage()
        }
    }

    fun saveImageMemory(
        title: String,
        imageUri: String?,
        amount: String = "",
        dueDate: String = "",
        includeInSearch: Boolean = true
    ) {
        viewModelScope.launch {
            repository.saveImageMemory(
                title = title,
                imageUri = imageUri,
                amount = amount,
                dueDate = dueDate,
                includeInSearch = includeInSearch
            )
            updateStorageUsage()
        }
    }

    fun saveVoiceMemory(
        title: String,
        transcription: String,
        summary: String,
        hasReminder: Boolean
    ) {
        viewModelScope.launch {
            repository.saveVoiceMemory(
                title = title,
                transcription = transcription,
                summary = summary,
                hasReminder = hasReminder
            )
            updateStorageUsage()
        }
    }

    private fun updateStorageUsage() {
        val totalItems = recentItems.value.size + 1
        val calcUsed = (totalItems * 0.002 * 1000).toLong() / 1000.0
        _storageData.value = _storageData.value.copy(
            usedGb = calcUsed,
            lastSyncTime = "Just now"
        )
    }

    fun clearCache() {
        _storageData.value = _storageData.value.copy(
            usedGb = 0.0,
            pdfsGb = 0.0,
            imagesGb = 0.0,
            notesGb = 0.0,
            lastSyncTime = "Optimized"
        )
    }
}
