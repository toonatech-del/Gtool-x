package com.example.ui.screens

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.AspectRatio
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.Compress
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.LockOpen
import androidx.compose.material.icons.outlined.Photo
import androidx.compose.material.icons.outlined.PhotoCamera
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AmbientLightingBackground
import com.example.ui.components.GlassCard
import com.example.ui.theme.AmberGlow
import com.example.ui.theme.AmberWarm
import com.example.ui.theme.GlassStroke
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarmGold
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

enum class DimensionUnit(val label: String) {
    PX("px"),
    CM("cm"),
    MM("mm")
}

@Composable
fun PhotoResizerScreen(
    onBackClick: () -> Unit,
    onSaveSuccess: (title: String, imageUri: String, info: String, syncToDrive: Boolean) -> Unit = { _, _, _, _ -> },
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var originalBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var originalWidth by remember { mutableIntStateOf(0) }
    var originalHeight by remember { mutableIntStateOf(0) }
    var originalFileSizeKb by remember { mutableStateOf(0L) }

    var selectedUnit by remember { mutableStateOf(DimensionUnit.PX) }
    var widthInput by remember { mutableStateOf("1080") }
    var heightInput by remember { mutableStateOf("1080") }
    var isAspectRatioLocked by remember { mutableStateOf(true) }
    var targetSizeKbInput by remember { mutableStateOf("200") }
    var qualitySlider by remember { mutableFloatStateOf(85f) }
    var isProcessing by remember { mutableStateOf(false) }

    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            imageUri = uri
        }
    }

    // Load bitmap info whenever imageUri changes
    LaunchedEffect(imageUri) {
        if (imageUri != null) {
            withContext(Dispatchers.IO) {
                try {
                    val inputStream = context.contentResolver.openInputStream(imageUri!!)
                    val bytes = inputStream?.readBytes() ?: byteArrayOf()
                    inputStream?.close()

                    val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    if (bmp != null) {
                        originalBitmap = bmp
                        originalWidth = bmp.width
                        originalHeight = bmp.height
                        originalFileSizeKb = (bytes.size / 1024).toLong()

                        widthInput = bmp.width.toString()
                        heightInput = bmp.height.toString()
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    AmbientLightingBackground {
        Scaffold(
            containerColor = Color.Transparent,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            modifier = modifier
                .fillMaxSize()
                .testTag("photo_resizer_screen")
        ) { paddingValues ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .windowInsetsPadding(WindowInsets.statusBars),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(
                    bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 32.dp
                )
            ) {
                // Header
                item(key = "header") {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        IconButton(
                            onClick = onBackClick,
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Color(0x22FFFFFF))
                                .border(1.dp, GlassStroke, CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
                                contentDescription = "Back",
                                tint = TextPrimary
                            )
                        }

                        Text(
                            text = "Photo Resizer & Compressor",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = TextPrimary
                            )
                        )

                        Spacer(modifier = Modifier.width(40.dp))
                    }
                }

                // Image Selection Dropzone / Preview
                item(key = "image_preview_box") {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 8.dp)
                    ) {
                        GlassCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(260.dp)
                                .clickable { galleryLauncher.launch("image/*") }
                                .testTag("resizer_image_dropzone"),
                            shape = RoundedCornerShape(24.dp),
                            ambientGlowColor = AmberWarm
                        ) {
                            if (originalBitmap != null) {
                                Box(modifier = Modifier.fillMaxSize()) {
                                    Image(
                                        bitmap = originalBitmap!!.asImageBitmap(),
                                        contentDescription = "Selected Photo",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Fit
                                    )

                                    // Badge overlay
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.BottomStart)
                                            .padding(12.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(Color(0xCC0F0E11))
                                            .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(12.dp))
                                            .padding(horizontal = 10.dp, vertical = 6.dp)
                                    ) {
                                        Text(
                                            text = "Original: ${originalWidth}x${originalHeight} px • ${originalFileSizeKb} KB",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = WarmGold,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            )
                                        )
                                    }
                                }
                            } else {
                                Column(
                                    modifier = Modifier.fillMaxSize(),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(56.dp)
                                            .clip(CircleShape)
                                            .background(
                                                Brush.radialGradient(
                                                    listOf(Color(0x40FF9E58), Color(0x10FF9E58))
                                                )
                                            )
                                            .border(1.dp, AmberWarm.copy(alpha = 0.5f), CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.PhotoCamera,
                                            contentDescription = "Pick Photo",
                                            tint = AmberWarm,
                                            modifier = Modifier.size(28.dp)
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(14.dp))

                                    Text(
                                        text = "Tap to select photo from gallery",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = TextPrimary
                                        )
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "Supports JPEG, PNG & WEBP formats",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = TextMuted,
                                            fontSize = 12.sp
                                        )
                                    )
                                }
                            }
                        }
                    }
                }

                // Controls Section
                item(key = "resizer_controls") {
                    Spacer(modifier = Modifier.height(12.dp))

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Dimension Unit Switcher (px / cm / mm)
                        GlassCard(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "DIMENSION UNIT",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        letterSpacing = 0.8.sp,
                                        color = TextMuted
                                    )
                                )
                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    DimensionUnit.entries.forEach { unit ->
                                        val isSelected = selectedUnit == unit
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(
                                                    if (isSelected) Brush.horizontalGradient(
                                                        listOf(AmberWarm, AmberGlow)
                                                    ) else Brush.linearGradient(
                                                        listOf(Color(0x1AFFFFFF), Color(0x0AFFFFFF))
                                                    )
                                                )
                                                .border(
                                                    1.dp,
                                                    if (isSelected) Color.White.copy(alpha = 0.4f) else GlassStroke,
                                                    RoundedCornerShape(12.dp)
                                                )
                                                .clickable { selectedUnit = unit }
                                                .padding(vertical = 10.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = unit.label.uppercase(),
                                                color = if (isSelected) Color(0xFF0F0E11) else TextSecondary,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Target Dimensions (Width & Height) with Aspect Ratio Lock
                        GlassCard(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "TARGET DIMENSIONS (${selectedUnit.label})",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            letterSpacing = 0.8.sp,
                                            color = TextMuted
                                        )
                                    )

                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(12.dp))
                                            .clickable { isAspectRatioLocked = !isAspectRatioLocked }
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (isAspectRatioLocked) Icons.Outlined.Lock else Icons.Outlined.LockOpen,
                                            contentDescription = "Lock Ratio",
                                            tint = if (isAspectRatioLocked) AmberWarm else TextMuted,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = if (isAspectRatioLocked) "Locked" else "Free",
                                            fontSize = 11.sp,
                                            color = if (isAspectRatioLocked) AmberWarm else TextMuted,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    // Width input
                                    OutlinedTextField(
                                        value = widthInput,
                                        onValueChange = { newW ->
                                            widthInput = newW
                                            if (isAspectRatioLocked && originalWidth > 0 && originalHeight > 0) {
                                                val wVal = newW.toFloatOrNull() ?: 0f
                                                if (wVal > 0) {
                                                    val calculatedH = (wVal * originalHeight / originalWidth).toInt()
                                                    heightInput = calculatedH.toString()
                                                }
                                            }
                                        },
                                        label = { Text("Width", color = TextMuted) },
                                        singleLine = true,
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = AmberWarm,
                                            unfocusedBorderColor = GlassStroke,
                                            focusedLabelColor = AmberWarm,
                                            focusedTextColor = TextPrimary,
                                            unfocusedTextColor = TextPrimary
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("input_width")
                                    )

                                    // Height input
                                    OutlinedTextField(
                                        value = heightInput,
                                        onValueChange = { newH ->
                                            heightInput = newH
                                            if (isAspectRatioLocked && originalWidth > 0 && originalHeight > 0) {
                                                val hVal = newH.toFloatOrNull() ?: 0f
                                                if (hVal > 0) {
                                                    val calculatedW = (hVal * originalWidth / originalHeight).toInt()
                                                    widthInput = calculatedW.toString()
                                                }
                                            }
                                        },
                                        label = { Text("Height", color = TextMuted) },
                                        singleLine = true,
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = AmberWarm,
                                            unfocusedBorderColor = GlassStroke,
                                            focusedLabelColor = AmberWarm,
                                            focusedTextColor = TextPrimary,
                                            unfocusedTextColor = TextPrimary
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("input_height")
                                    )
                                }
                            }
                        }

                        // Target File Size Compression (KB) / Quality Slider
                        GlassCard(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = "TARGET FILE SIZE (COMPRESSION)",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        letterSpacing = 0.8.sp,
                                        color = TextMuted
                                    )
                                )
                                Spacer(modifier = Modifier.height(10.dp))

                                // Quick Compression Preset Buttons
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    listOf("50" to "Under 50 KB", "100" to "Under 100 KB", "200" to "Under 200 KB").forEach { (kb, label) ->
                                        val isSelected = targetSizeKbInput == kb
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(
                                                    if (isSelected) Brush.horizontalGradient(listOf(AmberWarm, AmberGlow))
                                                    else Brush.linearGradient(listOf(Color(0x1AFFFFFF), Color(0x0AFFFFFF)))
                                                )
                                                .border(
                                                    1.dp,
                                                    if (isSelected) Color.White.copy(alpha = 0.4f) else GlassStroke,
                                                    RoundedCornerShape(12.dp)
                                                )
                                                .clickable { targetSizeKbInput = kb }
                                                .padding(vertical = 8.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = label,
                                                color = if (isSelected) Color(0xFF0F0E11) else TextSecondary,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    OutlinedTextField(
                                        value = targetSizeKbInput,
                                        onValueChange = { targetSizeKbInput = it },
                                        label = { Text("Target Max KB", color = TextMuted) },
                                        singleLine = true,
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = AmberWarm,
                                            unfocusedBorderColor = GlassStroke,
                                            focusedLabelColor = AmberWarm,
                                            focusedTextColor = TextPrimary,
                                            unfocusedTextColor = TextPrimary
                                        ),
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("input_target_kb")
                                    )

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = "Quality: ${qualitySlider.toInt()}%",
                                            style = MaterialTheme.typography.labelMedium.copy(
                                                color = WarmGold,
                                                fontWeight = FontWeight.Bold
                                            )
                                        )
                                        Slider(
                                            value = qualitySlider,
                                            onValueChange = { qualitySlider = it },
                                            valueRange = 10f..100f,
                                            colors = SliderDefaults.colors(
                                                thumbColor = AmberWarm,
                                                activeTrackColor = AmberWarm,
                                                inactiveTrackColor = GlassStroke
                                            )
                                        )
                                    }
                                }
                            }
                        }

                        // Action Buttons: 'Save to Device' and 'Backup to Drive'
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = {
                                    if (originalBitmap == null) {
                                        coroutineScope.launch {
                                            snackbarHostState.showSnackbar("Please select an image first!")
                                        }
                                        return@Button
                                    }

                                    isProcessing = true
                                    coroutineScope.launch {
                                        val resultUri = processAndSaveResizedImage(
                                            context = context,
                                            sourceBitmap = originalBitmap!!,
                                            unit = selectedUnit,
                                            targetWStr = widthInput,
                                            targetHStr = heightInput,
                                            targetKbStr = targetSizeKbInput,
                                            quality = qualitySlider.toInt()
                                        )

                                        isProcessing = false
                                        if (resultUri != null) {
                                            val infoText = "Resized to ${widthInput}x${heightInput} ${selectedUnit.label} • ${targetSizeKbInput} KB max"
                                            onSaveSuccess("Resized_Photo_${System.currentTimeMillis()}", resultUri.toString(), infoText, false)
                                            snackbarHostState.showSnackbar("Saved locally to device! 📱")
                                        } else {
                                            snackbarHostState.showSnackbar("Failed to process image.")
                                        }
                                    }
                                },
                                enabled = !isProcessing,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = AmberWarm,
                                    contentColor = Color(0xFF0F0E11)
                                ),
                                shape = RoundedCornerShape(18.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(52.dp)
                                    .testTag("btn_save_to_device")
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.Download,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isProcessing) "Saving..." else "Save to Device",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }

                            Button(
                                onClick = {
                                    if (originalBitmap == null) {
                                        coroutineScope.launch {
                                            snackbarHostState.showSnackbar("Please select an image first!")
                                        }
                                        return@Button
                                    }

                                    isProcessing = true
                                    coroutineScope.launch {
                                        val resultUri = processAndSaveResizedImage(
                                            context = context,
                                            sourceBitmap = originalBitmap!!,
                                            unit = selectedUnit,
                                            targetWStr = widthInput,
                                            targetHStr = heightInput,
                                            targetKbStr = targetSizeKbInput,
                                            quality = qualitySlider.toInt()
                                        )

                                        isProcessing = false
                                        if (resultUri != null) {
                                            val infoText = "Resized to ${widthInput}x${heightInput} ${selectedUnit.label} • ${targetSizeKbInput} KB max"
                                            onSaveSuccess("Resized_Photo_${System.currentTimeMillis()}", resultUri.toString(), infoText, true)
                                            snackbarHostState.showSnackbar("Backed up & synced to Google Drive! ☁️")
                                        } else {
                                            snackbarHostState.showSnackbar("Failed to process image.")
                                        }
                                    }
                                },
                                enabled = !isProcessing,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF3B82F6),
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(18.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(52.dp)
                                    .testTag("btn_backup_to_drive")
                            ) {
                                Text(
                                    text = "☁ Backup to Drive",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private suspend fun processAndSaveResizedImage(
    context: Context,
    sourceBitmap: Bitmap,
    unit: DimensionUnit,
    targetWStr: String,
    targetHStr: String,
    targetKbStr: String,
    quality: Int
): Uri? = withContext(Dispatchers.IO) {
    try {
        val targetW = targetWStr.toIntOrNull() ?: sourceBitmap.width
        val targetH = targetHStr.toIntOrNull() ?: sourceBitmap.height

        // Convert dimensions to pixels if given in cm or mm (assume standard 300 DPI)
        val pixelWidth = when (unit) {
            DimensionUnit.PX -> targetW
            DimensionUnit.CM -> (targetW * 118.11f).toInt().coerceAtLeast(10)
            DimensionUnit.MM -> (targetW * 11.811f).toInt().coerceAtLeast(10)
        }
        val pixelHeight = when (unit) {
            DimensionUnit.PX -> targetH
            DimensionUnit.CM -> (targetH * 118.11f).toInt().coerceAtLeast(10)
            DimensionUnit.MM -> (targetH * 11.811f).toInt().coerceAtLeast(10)
        }

        val scaledBmp = Bitmap.createScaledBitmap(sourceBitmap, pixelWidth, pixelHeight, true)

        val targetKb = targetKbStr.toIntOrNull() ?: 300
        var currentQuality = quality

        val stream = ByteArrayOutputStream()
        scaledBmp.compress(Bitmap.CompressFormat.JPEG, currentQuality, stream)

        // Iterative compression to match target KB
        while (stream.toByteArray().size / 1024 > targetKb && currentQuality > 10) {
            stream.reset()
            currentQuality -= 8
            scaledBmp.compress(Bitmap.CompressFormat.JPEG, currentQuality, stream)
        }

        val file = File(context.cacheDir, "resized_${System.currentTimeMillis()}.jpg")
        val fos = FileOutputStream(file)
        fos.write(stream.toByteArray())
        fos.flush()
        fos.close()

        Uri.fromFile(file)
    } catch (e: Exception) {
        e.printStackTrace()
        null
    }
}
