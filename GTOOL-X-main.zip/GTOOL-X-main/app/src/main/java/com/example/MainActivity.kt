package com.example

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material3.FabPosition
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.CurrentScreen
import com.example.model.ItemType
import com.example.model.WorkspaceItem
import com.example.ui.GsdcallWorkspaceViewModel
import com.example.ui.components.AddMemoryModal
import com.example.ui.components.AmbientLightingBackground
import com.example.ui.components.AskAiCard
import com.example.ui.components.DeleteConfirmationDialog
import com.example.ui.components.FilterRow
import com.example.ui.components.GalleryVaultSheet
import com.example.ui.components.HomeFeatureCards
import com.example.ui.components.ImportantItemsGrid
import com.example.ui.components.ItemDetailDialog
import com.example.ui.components.ManageStorageDialog
import com.example.ui.components.NotificationSheet
import com.example.ui.components.RecentItemsSection
import com.example.ui.components.SearchResultsSection
import com.example.ui.components.StorageInfoCard
import com.example.ui.components.TopHeader
import com.example.ui.components.UserProfileDialog
import com.example.ui.components.VoiceAssistantDialog
import com.example.ui.components.zoomOnPress
import com.example.ui.screens.AiSearchScreen
import com.example.ui.screens.DocumentScannerScreen
import com.example.ui.screens.ImageMemoryScreen
import com.example.ui.screens.NoteEditorScreen
import com.example.ui.screens.PassportPhotoMakerScreen
import com.example.ui.screens.PdfPreviewScreen
import com.example.ui.screens.PhotoResizerScreen
import com.example.ui.screens.VoiceMemoryScreen
import com.example.ui.theme.AmberGlow
import com.example.ui.theme.AmberWarm
import com.example.ui.theme.GlassStroke
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.WarmGold
import kotlinx.coroutines.launch
import java.util.Locale

import com.example.ui.theme.LocalIsDarkMode
import androidx.compose.runtime.CompositionLocalProvider

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GsdcallAiApp()
        }
    }
}

@Composable
fun GsdcallAiApp(
    viewModel: GsdcallWorkspaceViewModel = viewModel()
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("gtool_x_theme_prefs", Context.MODE_PRIVATE) }
    var isDarkMode by remember { mutableStateOf(prefs.getBoolean("is_dark_mode", true)) }

    CompositionLocalProvider(LocalIsDarkMode provides isDarkMode) {
        MyApplicationTheme(darkTheme = isDarkMode) {
            GsdcallAiAppContent(viewModel = viewModel, isDarkMode = isDarkMode, onThemeToggle = {
                val newMode = !isDarkMode
                isDarkMode = newMode
                prefs.edit().putBoolean("is_dark_mode", newMode).apply()
            })
        }
    }
}

@Composable
private fun GsdcallAiAppContent(
    viewModel: GsdcallWorkspaceViewModel,
    isDarkMode: Boolean,
    onThemeToggle: () -> Unit
) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val chatMessages by viewModel.chatMessages.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedFilter by viewModel.selectedFilter.collectAsStateWithLifecycle()
    val recentItems by viewModel.filteredRecentItems.collectAsStateWithLifecycle()
    val importantItems by viewModel.filteredImportantItems.collectAsStateWithLifecycle()
    val storageData by viewModel.storageData.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()

    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    var showVoiceDialog by remember { mutableStateOf(false) }
    var showNotificationSheet by remember { mutableStateOf(false) }
    var showProfileDialog by remember { mutableStateOf(false) }
    var showManageStorageDialog by remember { mutableStateOf(false) }
    var showAddMemoryModal by remember { mutableStateOf(false) }
    var showGalleryVaultSheet by remember { mutableStateOf(false) }
    var itemToDeleteForConfirm by remember { mutableStateOf<WorkspaceItem?>(null) }
    var selectedItemForDetail by remember { mutableStateOf<WorkspaceItem?>(null) }

    var selectedPdfUri by remember { mutableStateOf<String?>(null) }
    var selectedPdfName by remember { mutableStateOf("") }
    var selectedPdfSize by remember { mutableStateOf("") }
    var selectedImageUri by remember { mutableStateOf<String?>(null) }
    var selectedNoteTitle by remember { mutableStateOf("") }
    var selectedNoteContent by remember { mutableStateOf("") }
    var selectedNoteTags by remember { mutableStateOf<List<String>>(emptyList()) }
    var selectedNoteAttachmentUri by remember { mutableStateOf<String?>(null) }

    val pdfPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            val (name, size) = queryFileInfo(context, uri)
            selectedPdfName = name
            selectedPdfSize = size
            selectedPdfUri = uri.toString()
            viewModel.navigateTo(CurrentScreen.PDF_PREVIEW)
        }
    }

    // Intercept back button when not on HOME
    BackHandler(enabled = currentScreen != CurrentScreen.HOME) {
        viewModel.navigateTo(CurrentScreen.HOME)
    }

    AnimatedContent(
        targetState = currentScreen,
        transitionSpec = {
            (fadeIn(animationSpec = tween(220)) + scaleIn(initialScale = 0.92f, animationSpec = tween(250)))
                .togetherWith(fadeOut(animationSpec = tween(180)) + scaleOut(targetScale = 0.95f, animationSpec = tween(180)))
        },
        label = "screen_zoom_transition"
    ) { screen ->
        when (screen) {
            CurrentScreen.NOTE_EDITOR -> {
                NoteEditorScreen(
                    initialTitle = selectedNoteTitle,
                    initialContent = selectedNoteContent,
                    initialTags = selectedNoteTags,
                    initialAttachmentUri = selectedNoteAttachmentUri,
                    onBackClick = {
                        viewModel.navigateTo(CurrentScreen.HOME)
                    },
                    onSaveSuccess = { title, bullets ->
                        viewModel.updateNote(title, bullets)
                    },
                    onSaveFullNote = { title, content, tags, hasAttachment, includeInSearch, attachedUri ->
                        viewModel.saveFullNote(
                            title = title,
                            content = content,
                            tags = tags,
                            hasAttachment = hasAttachment,
                            includeInSemanticSearch = includeInSearch,
                            attachmentUri = attachedUri
                        )
                        viewModel.navigateTo(CurrentScreen.HOME)
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar("Saved \"$title\" to Recent items 📝")
                        }
                    },
                    onOpenScanner = {
                        viewModel.navigateTo(CurrentScreen.DOCUMENT_SCANNER)
                    }
                )
            }
            CurrentScreen.DOCUMENT_SCANNER -> {
                DocumentScannerScreen(
                    onClose = {
                        viewModel.navigateTo(CurrentScreen.HOME)
                    },
                    onCaptureSuccess = { capturedUri ->
                        if (capturedUri != null) {
                            selectedImageUri = capturedUri.toString()
                        }
                        viewModel.navigateTo(CurrentScreen.IMAGE_MEMORY)
                    },
                    onPreviousScanClick = {
                        selectedImageUri = null
                        viewModel.navigateTo(CurrentScreen.IMAGE_MEMORY)
                    }
                )
            }
            CurrentScreen.PDF_PREVIEW -> {
                PdfPreviewScreen(
                    fileName = selectedPdfName,
                    fileSize = selectedPdfSize,
                    pdfUri = selectedPdfUri,
                    onBackClick = {
                        viewModel.navigateTo(CurrentScreen.HOME)
                    },
                    onSaveDocument = { title, summary, keyPoints, includeInSearch ->
                        viewModel.savePdfDocument(
                            title = title,
                            fileName = selectedPdfName,
                            fileSize = selectedPdfSize,
                            summary = summary,
                            keyPoints = keyPoints,
                            pdfUri = if (!selectedPdfUri.isNullOrBlank()) Uri.parse(selectedPdfUri) else null,
                            includeInSearch = includeInSearch
                        )
                        viewModel.navigateTo(CurrentScreen.HOME)
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar("Saved \"$title\" to Recent items 📄")
                        }
                    }
                )
            }
            CurrentScreen.IMAGE_MEMORY -> {
                ImageMemoryScreen(
                    imageUri = selectedImageUri,
                    onBackClick = {
                        viewModel.navigateTo(CurrentScreen.HOME)
                    },
                    onSaveExtractedMemory = { docName, amount, dueDate, includeInSearch ->
                        viewModel.saveImageMemory(
                            title = docName,
                            imageUri = selectedImageUri,
                            amount = amount,
                            dueDate = dueDate,
                            includeInSearch = includeInSearch
                        )
                        viewModel.navigateTo(CurrentScreen.HOME)
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar("Saved \"$docName\" to Recent items 🖼️")
                        }
                    }
                )
            }
            CurrentScreen.VOICE_MEMORY -> {
                VoiceMemoryScreen(
                    onBackClick = {
                        viewModel.navigateTo(CurrentScreen.HOME)
                    },
                    onSaveVoiceMemory = { title, transcription, summary, hasReminder ->
                        viewModel.saveVoiceMemory(title, transcription, summary, hasReminder)
                    }
                )
            }
            CurrentScreen.AI_SEARCH -> {
                AiSearchScreen(
                    messages = chatMessages,
                    onSendMessage = { query ->
                        viewModel.sendChatMessage(query)
                    },
                    onBackClick = {
                        viewModel.navigateTo(CurrentScreen.HOME)
                    },
                    onVoiceClick = {
                        viewModel.navigateTo(CurrentScreen.VOICE_MEMORY)
                    },
                    onAddMemoryClick = {
                        showAddMemoryModal = true
                    }
                )
            }
            CurrentScreen.PHOTO_RESIZER -> {
                PhotoResizerScreen(
                    onBackClick = {
                        viewModel.navigateTo(CurrentScreen.HOME)
                    },
                    onSaveSuccess = { title, uri, info, syncToDrive ->
                        viewModel.saveImageMemory(
                            title = title,
                            imageUri = uri,
                            amount = info,
                            dueDate = "",
                            includeInSearch = true
                        )
                        if (syncToDrive) {
                            viewModel.uploadItemToGoogleDrive(
                                WorkspaceItem(
                                    id = uri,
                                    title = title,
                                    type = ItemType.IMAGE,
                                    dateModified = "Just now",
                                    summary = info,
                                    subtitle = "Image • Offline FTS4 Index",
                                    isSyncedToDrive = true
                                )
                            )
                        }
                        viewModel.navigateTo(CurrentScreen.HOME)
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar(
                                if (syncToDrive) "Resized photo backed up & synced to Google Drive! ☁️"
                                else "Resized photo saved to Recent items 🖼️"
                            )
                        }
                    }
                )
            }
            CurrentScreen.PASSPORT_PHOTO_MAKER -> {
                PassportPhotoMakerScreen(
                    onBackClick = {
                        viewModel.navigateTo(CurrentScreen.HOME)
                    },
                    onSaveSuccess = { title, uri, syncToDrive ->
                        viewModel.saveImageMemory(
                            title = title,
                            imageUri = uri,
                            amount = "Passport Photo",
                            dueDate = "",
                            includeInSearch = true
                        )
                        if (syncToDrive) {
                            viewModel.uploadItemToGoogleDrive(
                                WorkspaceItem(
                                    id = uri,
                                    title = title,
                                    type = ItemType.IMAGE,
                                    dateModified = "Just now",
                                    summary = "Passport Photo",
                                    subtitle = "Image • Offline FTS4 Index",
                                    isSyncedToDrive = true
                                )
                            )
                        }
                        viewModel.navigateTo(CurrentScreen.HOME)
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar(
                                if (syncToDrive) "Passport photo backed up & synced to Google Drive! ☁️"
                                else "Passport photo saved to Recent items 🛂"
                            )
                        }
                    }
                )
            }
            CurrentScreen.HOME -> {
                AmbientLightingBackground {
                    Scaffold(
                        containerColor = Color.Transparent,
                        snackbarHost = { SnackbarHost(snackbarHostState) },
                        floatingActionButtonPosition = FabPosition.Center,
                        floatingActionButton = {
                            // Enlarged 64dp x 64dp Circular Gallery Vault Button aligned at bottom center
                            Box(
                                modifier = Modifier
                                    .padding(bottom = 12.dp)
                                    .size(64.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.radialGradient(
                                            listOf(Color(0xF52A2532), Color(0xFA1A1722))
                                        )
                                    )
                                    .border(
                                        1.5.dp,
                                        Brush.linearGradient(
                                            listOf(AmberWarm, WarmGold, GlassStroke, Color(0x44FFFFFF))
                                        ),
                                        CircleShape
                                    )
                                    .zoomOnPress { showGalleryVaultSheet = true }
                                    .testTag("fab_gallery_vault"),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.GridView,
                                    contentDescription = "Gallery Vault",
                                    tint = WarmGold,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                        },
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("gsdcall_ai_main_screen")
                    ) { paddingValues ->
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(paddingValues)
                                .windowInsetsPadding(WindowInsets.statusBars),
                            contentPadding = PaddingValues(
                                bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 80.dp
                            )
                        ) {
                            // 1. Top Header: Branding 'GTOOL X', avatar, notification bell, theme toggle
                            item(key = "top_header") {
                                TopHeader(
                                    unreadCount = notifications.count { it.isUnread },
                                    accountName = "User",
                                    userEmail = "user@example.com",
                                    onAvatarClick = { showProfileDialog = true },
                                    onNotificationClick = { showNotificationSheet = true },
                                    onThemeToggle = onThemeToggle,
                                    onAddClick = { showAddMemoryModal = true }
                                )
                            }

                            // 2. Prominent large frosted glass card titled 'ASK'
                            item(key = "ask_ai_card") {
                                Spacer(modifier = Modifier.height(6.dp))
                                Box(modifier = Modifier.padding(horizontal = 20.dp)) {
                                    AskAiCard(
                                        searchQuery = searchQuery,
                                        onSearchQueryChange = { viewModel.onSearchQueryChange(it) },
                                        onMicClick = { viewModel.navigateTo(CurrentScreen.VOICE_MEMORY) },
                                        onPromptSuggestionClick = { prompt ->
                                            viewModel.sendChatMessage(prompt)
                                            viewModel.navigateTo(CurrentScreen.AI_SEARCH)
                                        },
                                        onSearchSubmit = { prompt ->
                                            viewModel.sendChatMessage(prompt)
                                            viewModel.navigateTo(CurrentScreen.AI_SEARCH)
                                        }
                                    )
                                }
                            }

                            // 3. Core Module Feature Cards Grid (PDF, Notepad, Scan & Doc, Image, Photo Resizer, Passport Photo)
                            item(key = "home_feature_cards") {
                                Spacer(modifier = Modifier.height(14.dp))
                                HomeFeatureCards(
                                    onFeatureClick = { screen ->
                                        when (screen) {
                                            CurrentScreen.PDF_PREVIEW -> {
                                                pdfPickerLauncher.launch(arrayOf("application/pdf"))
                                            }
                                            CurrentScreen.NOTE_EDITOR -> {
                                                selectedNoteTitle = ""
                                                selectedNoteContent = ""
                                                selectedNoteTags = emptyList()
                                                selectedNoteAttachmentUri = null
                                                viewModel.navigateTo(CurrentScreen.NOTE_EDITOR)
                                            }
                                            CurrentScreen.DOCUMENT_SCANNER -> {
                                                viewModel.navigateTo(CurrentScreen.DOCUMENT_SCANNER)
                                            }
                                            CurrentScreen.IMAGE_MEMORY -> {
                                                selectedImageUri = null
                                                viewModel.navigateTo(CurrentScreen.IMAGE_MEMORY)
                                            }
                                            CurrentScreen.PHOTO_RESIZER -> {
                                                viewModel.navigateTo(CurrentScreen.PHOTO_RESIZER)
                                            }
                                            CurrentScreen.PASSPORT_PHOTO_MAKER -> {
                                                viewModel.navigateTo(CurrentScreen.PASSPORT_PHOTO_MAKER)
                                            }
                                            else -> {
                                                viewModel.navigateTo(screen)
                                            }
                                        }
                                    }
                                )
                            }

                            // 3. If user is actively searching, show real-time FTS4 SearchResultsSection
                            if (searchQuery.isNotBlank()) {
                                item(key = "fts_search_results") {
                                    Spacer(modifier = Modifier.height(18.dp))
                                    SearchResultsSection(
                                        query = searchQuery,
                                        results = searchResults,
                                        onItemClick = { item ->
                                            if (item.type == ItemType.PDF || item.title.endsWith(".pdf", ignoreCase = true)) {
                                                selectedPdfName = if (item.title.endsWith(".pdf", ignoreCase = true)) item.title else "${item.title}.pdf"
                                                selectedPdfSize = item.sizeText
                                                selectedPdfUri = item.imageUri
                                                viewModel.navigateTo(CurrentScreen.PDF_PREVIEW)
                                            } else if (item.type == ItemType.NOTE) {
                                                selectedNoteTitle = item.title
                                                selectedNoteContent = item.contentSnippet ?: item.summary
                                                selectedNoteTags = if (!item.tag.isNullOrBlank()) {
                                                    val cleanTag = item.tag
                                                    listOf(if (cleanTag.startsWith("#")) cleanTag else "#$cleanTag")
                                                } else {
                                                    emptyList()
                                                }
                                                selectedNoteAttachmentUri = item.imageUri
                                                viewModel.navigateTo(CurrentScreen.NOTE_EDITOR)
                                            } else if (item.type == ItemType.IMAGE || item.title.contains("Electricity", ignoreCase = true)) {
                                                selectedImageUri = item.imageUri
                                                viewModel.navigateTo(CurrentScreen.IMAGE_MEMORY)
                                            } else if (item.type == ItemType.VOICE || item.title.contains("Voice", ignoreCase = true) || item.title.contains("Rahul", ignoreCase = true)) {
                                                viewModel.navigateTo(CurrentScreen.VOICE_MEMORY)
                                            } else {
                                                selectedItemForDetail = item
                                            }
                                        }
                                    )
                                }
                            } else {
                                // Secondary Category Bar ('All', 'Notes', 'PDFs', 'Images')
                                item(key = "filter_row") {
                                    Spacer(modifier = Modifier.height(18.dp))
                                    FilterRow(
                                        selectedType = selectedFilter,
                                        onFilterSelected = { viewModel.onFilterSelected(it) }
                                    )
                                }

                                // Filtered list / empty state under category tabs
                                item(key = "recent_items") {
                                    Spacer(modifier = Modifier.height(14.dp))
                                    RecentItemsSection(
                                        items = recentItems,
                                        selectedFilter = selectedFilter,
                                        onAddMemoryClick = { showAddMemoryModal = true },
                                        onDeleteClick = { item -> itemToDeleteForConfirm = item },
                                        onItemClick = { item ->
                                            if (item.type == ItemType.PDF || item.title.endsWith(".pdf", ignoreCase = true)) {
                                                selectedPdfName = if (item.title.endsWith(".pdf", ignoreCase = true)) item.title else "${item.title}.pdf"
                                                selectedPdfSize = item.sizeText
                                                selectedPdfUri = item.imageUri
                                                viewModel.navigateTo(CurrentScreen.PDF_PREVIEW)
                                            } else if (item.type == ItemType.NOTE) {
                                                selectedNoteTitle = item.title
                                                selectedNoteContent = item.contentSnippet ?: item.summary
                                                selectedNoteTags = if (!item.tag.isNullOrBlank()) {
                                                    val cleanTag = item.tag
                                                    listOf(if (cleanTag.startsWith("#")) cleanTag else "#$cleanTag")
                                                } else {
                                                    emptyList()
                                                }
                                                selectedNoteAttachmentUri = item.imageUri
                                                viewModel.navigateTo(CurrentScreen.NOTE_EDITOR)
                                            } else if (item.type == ItemType.IMAGE || item.title.contains("Electricity", ignoreCase = true)) {
                                                selectedImageUri = item.imageUri
                                                viewModel.navigateTo(CurrentScreen.IMAGE_MEMORY)
                                            } else if (item.type == ItemType.VOICE || item.title.contains("Voice", ignoreCase = true) || item.title.contains("Rahul", ignoreCase = true)) {
                                                viewModel.navigateTo(CurrentScreen.VOICE_MEMORY)
                                            } else {
                                                selectedItemForDetail = item
                                            }
                                        },
                                        onTogglePin = { item ->
                                            viewModel.togglePin(item)
                                            coroutineScope.launch {
                                                snackbarHostState.showSnackbar(
                                                    if (item.isPinned) "Unpinned ${item.title}" else "Pinned ${item.title} to Important"
                                                )
                                            }
                                        }
                                    )
                                }
                            }

                            // 5. Bottom section: 'Important items' pinned grid
                            if (importantItems.isNotEmpty()) {
                                item(key = "important_items") {
                                    Spacer(modifier = Modifier.height(24.dp))
                                    ImportantItemsGrid(
                                        items = importantItems,
                                        onItemClick = { item -> selectedItemForDetail = item },
                                        onTogglePin = { item ->
                                            viewModel.togglePin(item)
                                            coroutineScope.launch {
                                                snackbarHostState.showSnackbar("Unpinned ${item.title}")
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Voice Dialog
    if (showVoiceDialog) {
        VoiceAssistantDialog(
            onDismiss = { showVoiceDialog = false },
            onVoiceResult = { result ->
                showVoiceDialog = false
                viewModel.sendChatMessage(result)
                viewModel.navigateTo(CurrentScreen.AI_SEARCH)
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("Query: \"$result\"")
                }
            }
        )
    }

    // Item Detail Dialog
    if (selectedItemForDetail != null) {
        ItemDetailDialog(
            item = selectedItemForDetail!!,
            onDismiss = { selectedItemForDetail = null },
            onTogglePin = { item ->
                viewModel.togglePin(item)
                selectedItemForDetail = item.copy(isPinned = !item.isPinned)
            },
            onAskAiAboutItem = { item ->
                selectedItemForDetail = null
                viewModel.sendChatMessage("Explain ${item.title}")
                viewModel.navigateTo(CurrentScreen.AI_SEARCH)
            },
            onDeleteItem = { item ->
                viewModel.deleteItemPermanently(item)
                selectedItemForDetail = null
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("Item deleted successfully 🗑️")
                }
            },
            onUploadToDrive = { item ->
                viewModel.uploadItemToGoogleDrive(item)
                selectedItemForDetail = item.copy(isSyncedToDrive = true)
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("Uploaded \"${item.title}\" to Google Drive AppData ☁️")
                }
            },
            onOpenEditor = {
                selectedItemForDetail = null
                viewModel.navigateTo(CurrentScreen.NOTE_EDITOR)
            },
            onOpenImageMemory = {
                selectedItemForDetail = null
                viewModel.navigateTo(CurrentScreen.IMAGE_MEMORY)
            },
            onOpenVoiceMemory = {
                selectedItemForDetail = null
                viewModel.navigateTo(CurrentScreen.VOICE_MEMORY)
            },
            onOpenScanner = {
                selectedItemForDetail = null
                viewModel.navigateTo(CurrentScreen.DOCUMENT_SCANNER)
            }
        )
    }

    // Delete Confirmation Dialog for Card Delete Clicks
    if (itemToDeleteForConfirm != null) {
        DeleteConfirmationDialog(
            item = itemToDeleteForConfirm!!,
            onConfirmDelete = {
                viewModel.deleteItemPermanently(itemToDeleteForConfirm!!)
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("Item deleted successfully 🗑️")
                }
                itemToDeleteForConfirm = null
            },
            onDismiss = { itemToDeleteForConfirm = null }
        )
    }

    // Gallery Vault Sheet
    if (showGalleryVaultSheet) {
        GalleryVaultSheet(
            items = recentItems,
            onItemClick = { item ->
                showGalleryVaultSheet = false
                selectedItemForDetail = item
            },
            onDeleteItem = { item ->
                viewModel.deleteItemPermanently(item)
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("Item deleted successfully 🗑️")
                }
            },
            onDismiss = { showGalleryVaultSheet = false }
        )
    }

    // Notification Sheet
    if (showNotificationSheet) {
        NotificationSheet(
            notifications = notifications,
            onDismiss = { showNotificationSheet = false }
        )
    }

    // Profile Dialog
    if (showProfileDialog) {
        UserProfileDialog(
            accountName = "User",
            userEmail = "user@example.com",
            onSignOut = {
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("Signed out of Google Drive account")
                }
            },
            onDismiss = { showProfileDialog = false }
        )
    }

    // Manage Storage Dialog
    if (showManageStorageDialog) {
        ManageStorageDialog(
            storageData = storageData,
            onDismiss = { showManageStorageDialog = false },
            onSyncNow = {
                viewModel.syncNow()
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("Synced all offline files successfully ☁")
                }
            },
            onClearCache = {
                viewModel.clearCache()
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("Cache cleaned: 400 MB freed")
                }
            }
        )
    }

    // Add Memory Modal
    if (showAddMemoryModal) {
        AddMemoryModal(
            onDismiss = { showAddMemoryModal = false },
            onMemoryCreated = { title, type, isPrivate ->
                viewModel.addMemory(title, type, isPrivate)
                coroutineScope.launch {
                    snackbarHostState.showSnackbar(
                        if (isPrivate) "🔒 Added \"$title\" with biometric encryption" else "Added \"$title\" to vault"
                    )
                }
            },
            onPdfPicked = { uri ->
                showAddMemoryModal = false
                val (name, size) = queryFileInfo(context, uri)
                selectedPdfName = name
                selectedPdfSize = size
                selectedPdfUri = uri.toString()
                viewModel.navigateTo(CurrentScreen.PDF_PREVIEW)
            },
            onImagePicked = { uri ->
                showAddMemoryModal = false
                selectedImageUri = uri.toString()
                viewModel.navigateTo(CurrentScreen.IMAGE_MEMORY)
            },
            onOpenScanner = {
                showAddMemoryModal = false
                viewModel.navigateTo(CurrentScreen.DOCUMENT_SCANNER)
            },
            onOpenNoteEditor = {
                showAddMemoryModal = false
                selectedNoteTitle = ""
                selectedNoteContent = ""
                selectedNoteTags = emptyList()
                selectedNoteAttachmentUri = null
                viewModel.navigateTo(CurrentScreen.NOTE_EDITOR)
            }
        )
    }
}

private fun queryFileInfo(context: Context, uri: Uri): Pair<String, String> {
    var name = "Document.pdf"
    var size = "1.8 MB"
    try {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (cursor.moveToFirst()) {
                if (nameIndex != -1) {
                    val displayName = cursor.getString(nameIndex)
                    if (!displayName.isNullOrBlank()) {
                        name = displayName
                    }
                }
                if (sizeIndex != -1) {
                    val bytes = cursor.getLong(sizeIndex)
                    if (bytes > 0) {
                        size = if (bytes < 1024 * 1024) {
                            "${bytes / 1024} KB"
                        } else {
                            String.format(Locale.US, "%.1f MB", bytes.toDouble() / (1024 * 1024))
                        }
                    }
                }
            }
        }
    } catch (_: Exception) {}
    return Pair(name, size)
}
