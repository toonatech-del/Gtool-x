@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package com.example

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.fragment.app.FragmentActivity
import android.view.WindowManager
import com.example.util.BiometricAuthManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.material.icons.rounded.Lock
import com.example.ui.theme.TextSecondary
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material3.FabPosition
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.CitationSource
import com.example.model.CurrentScreen
import com.example.model.ItemType
import com.example.model.WorkspaceItem
import com.example.ui.GsdcallWorkspaceViewModel
import com.example.ui.components.AddMemoryModal
import com.example.ui.components.AmbientLightingBackground
import com.example.ui.components.AskAiCard
import com.example.ui.components.DarkFrostedSnackbarHost
import com.example.ui.components.DeleteConfirmationDialog
import com.example.ui.components.FilterRow
import com.example.ui.components.GalleryVaultSheet
import com.example.ui.components.HomeFeatureCards
import com.example.ui.components.ImportantItemsGrid
import com.example.ui.components.ItemDetailDialog
import com.example.ui.components.ManageStorageDialog
import com.example.ui.components.ModernGalleryIcon
import com.example.ui.components.NotificationSheet
import com.example.ui.components.RecentItemsSection
import com.example.ui.components.SearchResultsSection
import com.example.ui.components.TopHeader
import com.example.ui.components.UserProfileDialog
import com.example.ui.components.VoiceAssistantDialog
import com.example.ui.components.iosBounce
import com.example.ui.components.zoomOnPress
import com.example.ui.screens.AiSearchScreen
import com.example.ui.screens.DocumentScannerScreen
import com.example.ui.screens.ImageMemoryScreen
import com.example.ui.screens.NoteEditorScreen
import com.example.ui.screens.PdfPreviewScreen
import com.example.ui.screens.PhotoResizerScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.PrivacyPolicyScreen
import com.example.ui.screens.SmartInvoiceMakerScreen
import com.example.ui.screens.TermsConditionsScreen
import com.example.ui.screens.TermsOnboardingScreen
import com.example.ui.screens.VoiceMemoryScreen
import com.example.ui.theme.AmberWarm
import com.example.ui.theme.GlassStroke
import com.example.ui.theme.LocalIsDarkMode
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.WarmGold
import kotlinx.coroutines.launch
import java.util.Locale

class MainActivity : FragmentActivity() {
    private val viewModel: GsdcallWorkspaceViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GsdcallAiApp(viewModel = viewModel)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GsdcallAiApp(
    viewModel: GsdcallWorkspaceViewModel = viewModel()
) {
    CompositionLocalProvider(LocalIsDarkMode provides true) {
        MyApplicationTheme(darkTheme = true) {
            GsdcallAiAppContent(
                viewModel = viewModel
            )
        }
    }
}

@Composable
private fun GsdcallAiAppContent(
    viewModel: GsdcallWorkspaceViewModel
) {
    val hasAcceptedTerms by viewModel.hasAcceptedTerms.collectAsStateWithLifecycle()
    val userSession by viewModel.currentUser.collectAsStateWithLifecycle()
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val chatMessages by viewModel.chatMessages.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedFilter by viewModel.selectedFilter.collectAsStateWithLifecycle()
    val recentItems by viewModel.filteredRecentItems.collectAsStateWithLifecycle()
    val importantItems by viewModel.filteredImportantItems.collectAsStateWithLifecycle()
    val storageData by viewModel.storageData.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()
    val isBiometricEnabled by viewModel.isBiometricEnabled.collectAsStateWithLifecycle()
    val isAppUnlocked by viewModel.isAppUnlocked.collectAsStateWithLifecycle()
    val backupInfo by viewModel.backupInfo.collectAsStateWithLifecycle()
    val showRestorePrompt by viewModel.showRestorePrompt.collectAsStateWithLifecycle()

    if (!hasAcceptedTerms) {
        TermsOnboardingScreen(onAgree = { viewModel.acceptTerms() })
    } else {
        // ... (existing content that relies on the variables)
    }

    val context = LocalContext.current
    val activity = context as? FragmentActivity
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    // Enforce FLAG_SECURE on window when Biometric Lock is active
    androidx.compose.runtime.LaunchedEffect(isBiometricEnabled, isAppUnlocked) {
        activity?.window?.let { win ->
            if (isBiometricEnabled) {
                win.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
            } else {
                win.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
            }
        }
    }

    var showVoiceDialog by remember { mutableStateOf(false) }
    var showNotificationSheet by remember { mutableStateOf(false) }
    var showProfileDialog by remember { mutableStateOf(false) }
    var showManageStorageDialog by remember { mutableStateOf(false) }
    var showAddMemoryModal by remember { mutableStateOf(false) }
    var showGalleryVaultSheet by remember { mutableStateOf(false) }
    var itemToDeleteForConfirm by remember { mutableStateOf<WorkspaceItem?>(null) }
    var selectedItemForDetail by remember { mutableStateOf<WorkspaceItem?>(null) }

    var selectedPdfUri by remember { mutableStateOf<String?>(null) }
    var selectedPdfName by remember { mutableStateOf("") }
    var selectedPdfSize by remember { mutableStateOf("") }
    var selectedImageUri by remember { mutableStateOf<String?>(null) }
    var selectedNoteTitle by remember { mutableStateOf("") }
    var selectedNoteContent by remember { mutableStateOf("") }
    var selectedNoteTags by remember { mutableStateOf<List<String>>(emptyList()) }
    var selectedNoteAttachmentUri by remember { mutableStateOf<String?>(null) }
    var selectedInvoiceId by remember { mutableStateOf<String?>(null) }

    val pdfPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            val (name, size) = queryFileInfo(context, uri)
            selectedPdfName = name
            selectedPdfSize = size
            selectedPdfUri = uri.toString()
            viewModel.navigateTo(CurrentScreen.PDF_PREVIEW)
        }
    }

    // Helper to open any item in its full viewer
    fun openItemInFullViewer(item: WorkspaceItem) {
        if (item.id.startsWith("invoice-") || item.tag == "Invoice") {
            selectedInvoiceId = item.id.removePrefix("invoice-")
            viewModel.navigateTo(CurrentScreen.SMART_INVOICE_MAKER)
        } else if (item.type == ItemType.PDF || item.title.endsWith(".pdf", ignoreCase = true)) {
            selectedPdfName = if (item.title.endsWith(".pdf", ignoreCase = true)) item.title else "${item.title}.pdf"
            selectedPdfSize = item.sizeText
            selectedPdfUri = item.driveFileId ?: item.imageUri
            viewModel.navigateTo(CurrentScreen.PDF_PREVIEW)
        } else if (item.type == ItemType.NOTE) {
            selectedNoteTitle = item.title
            selectedNoteContent = item.contentSnippet ?: item.summary
            selectedNoteTags = if (!item.tag.isNullOrBlank()) {
                val cleanTag = item.tag
                listOf(if (cleanTag.startsWith("#")) cleanTag else "#$cleanTag")
            } else {
                emptyList()
            }
            selectedNoteAttachmentUri = item.imageUri
            viewModel.navigateTo(CurrentScreen.NOTE_EDITOR)
        } else if (item.type == ItemType.IMAGE || item.title.contains("bill", ignoreCase = true) || item.title.contains("receipt", ignoreCase = true)) {
            selectedImageUri = item.imageUri
            viewModel.navigateTo(CurrentScreen.IMAGE_MEMORY)
        } else if (item.type == ItemType.VOICE) {
            viewModel.navigateTo(CurrentScreen.VOICE_MEMORY)
        } else {
            selectedItemForDetail = item
        }
    }

    // Helper for citation click from AI search
    fun openCitationInFullViewer(citation: CitationSource) {
        if (citation.id.startsWith("invoice-")) {
            selectedInvoiceId = citation.id.removePrefix("invoice-")
            viewModel.navigateTo(CurrentScreen.SMART_INVOICE_MAKER)
            return
        }
        val matchingItem = recentItems.firstOrNull { it.id == citation.id || it.title.equals(citation.title, ignoreCase = true) }
        if (matchingItem != null) {
            openItemInFullViewer(matchingItem)
        } else {
            when (citation.type) {
                ItemType.PDF -> {
                    selectedPdfName = citation.title
                    selectedPdfSize = "1.8 MB"
                    selectedPdfUri = citation.previewThumbnailUri ?: citation.imageUri
                    viewModel.navigateTo(CurrentScreen.PDF_PREVIEW)
                }
                ItemType.NOTE -> {
                    selectedNoteTitle = citation.title
                    selectedNoteContent = citation.snippet
                    selectedNoteTags = listOf("#note")
                    selectedNoteAttachmentUri = citation.imageUri
                    viewModel.navigateTo(CurrentScreen.NOTE_EDITOR)
                }
                ItemType.IMAGE -> {
                    selectedImageUri = citation.imageUri
                    viewModel.navigateTo(CurrentScreen.IMAGE_MEMORY)
                }
                ItemType.VOICE -> {
                    viewModel.navigateTo(CurrentScreen.VOICE_MEMORY)
                }
                ItemType.ALL -> {
                    viewModel.navigateTo(CurrentScreen.HOME)
                }
            }
        }
    }

    val styledSnackbarHost: @Composable () -> Unit = {
        DarkFrostedSnackbarHost(hostState = snackbarHostState)
    }

    // Intercept back button when not on HOME
    BackHandler(enabled = currentScreen != CurrentScreen.HOME) {
        viewModel.navigateBack()
    }

    AnimatedContent(
        targetState = currentScreen,
        transitionSpec = {
            if (targetState == CurrentScreen.HOME) {
                // iOS Pop Back: Screen slides down/right with spring bounce, previous screen zooms in
                (slideInHorizontally(
                    initialOffsetX = { -it / 3 },
                    animationSpec = spring(dampingRatio = 0.85f, stiffness = 420f)
                ) + fadeIn(animationSpec = spring(stiffness = 500f)) + scaleIn(
                    initialScale = 0.95f,
                    animationSpec = spring(dampingRatio = 0.85f, stiffness = 420f)
                )).togetherWith(
                    slideOutHorizontally(
                        targetOffsetX = { it },
                        animationSpec = spring(dampingRatio = 0.85f, stiffness = 420f)
                    ) + fadeOut(animationSpec = spring(stiffness = 500f)) + scaleOut(
                        targetScale = 1.05f,
                        animationSpec = spring(dampingRatio = 0.85f, stiffness = 420f)
                    )
                )
            } else {
                // iOS Push Forward: New screen slides in from right with elastic spring, current screen scales down
                (slideInHorizontally(
                    initialOffsetX = { it },
                    animationSpec = spring(dampingRatio = 0.85f, stiffness = 420f)
                ) + fadeIn(animationSpec = spring(stiffness = 500f)) + scaleIn(
                    initialScale = 0.95f,
                    animationSpec = spring(dampingRatio = 0.85f, stiffness = 420f)
                )).togetherWith(
                    slideOutHorizontally(
                        targetOffsetX = { -it / 3 },
                        animationSpec = spring(dampingRatio = 0.85f, stiffness = 420f)
                    ) + fadeOut(animationSpec = spring(stiffness = 500f)) + scaleOut(
                        targetScale = 0.92f,
                        animationSpec = spring(dampingRatio = 0.85f, stiffness = 420f)
                    )
                )
            }
        },
        label = "ios_spring_screen_transition"
    ) { screen ->
        when (screen) {
            CurrentScreen.NOTE_EDITOR -> {
                NoteEditorScreen(
                    initialTitle = selectedNoteTitle,
                    initialContent = selectedNoteContent,
                    initialTags = selectedNoteTags,
                    initialAttachmentUri = selectedNoteAttachmentUri,
                    onBackClick = {
                        viewModel.navigateTo(CurrentScreen.HOME)
                    },
                    onSaveSuccess = { title, bullets ->
                        viewModel.updateNote(title, bullets)
                    },
                    onSaveFullNote = { title, content, tags, hasAttachment, includeInSearch, attachedUri ->
                        viewModel.saveFullNote(
                            title = title,
                            content = content,
                            tags = tags,
                            hasAttachment = hasAttachment,
                            includeInSemanticSearch = includeInSearch,
                            attachmentUri = attachedUri
                        )
                        viewModel.navigateTo(CurrentScreen.HOME)
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar("Saved \"$title\" to Recent items 📝")
                        }
                    },
                    onOpenScanner = {
                        viewModel.navigateTo(CurrentScreen.DOCUMENT_SCANNER)
                    }
                )
            }
            CurrentScreen.DOCUMENT_SCANNER -> {
                DocumentScannerScreen(
                    onClose = {
                        viewModel.navigateTo(CurrentScreen.HOME)
                    },
                    onCaptureSuccess = { capturedUri ->
                        if (capturedUri != null) {
                            selectedImageUri = capturedUri.toString()
                        }
                        viewModel.navigateTo(CurrentScreen.IMAGE_MEMORY)
                    },
                    onPreviousScanClick = {
                        selectedImageUri = null
                        viewModel.navigateTo(CurrentScreen.IMAGE_MEMORY)
                    }
                )
            }
            CurrentScreen.PDF_PREVIEW -> {
                PdfPreviewScreen(
                    fileName = selectedPdfName,
                    fileSize = selectedPdfSize,
                    pdfUri = selectedPdfUri,
                    onBackClick = {
                        viewModel.navigateTo(CurrentScreen.HOME)
                    },
                    onSaveDocument = { title, summary, keyPoints, includeInSearch, fullTranscript ->
                        viewModel.savePdfDocument(
                            title = title,
                            fileName = selectedPdfName,
                            fileSize = selectedPdfSize,
                            summary = summary,
                            keyPoints = keyPoints,
                            pdfUri = if (!selectedPdfUri.isNullOrBlank()) Uri.parse(selectedPdfUri) else null,
                            includeInSearch = includeInSearch,
                            fullTranscript = fullTranscript
                        )
                        viewModel.navigateTo(CurrentScreen.HOME)
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar("Saved \"$title\" to Recent items 📄")
                        }
                    }
                )
            }
            CurrentScreen.IMAGE_MEMORY -> {
                ImageMemoryScreen(
                    imageUri = selectedImageUri,
                    onBackClick = {
                        viewModel.navigateTo(CurrentScreen.HOME)
                    },
                    onSaveExtractedMemory = { docName, amount, dueDate, includeInSearch, savedUri, fullOcrText ->
                        val finalUri = savedUri ?: selectedImageUri
                        viewModel.saveImageMemory(
                            title = docName,
                            imageUri = finalUri,
                            amount = amount,
                            dueDate = dueDate,
                            includeInSearch = includeInSearch,
                            fullOcrText = fullOcrText
                        )
                        viewModel.navigateTo(CurrentScreen.HOME)
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar("Saved \"$docName\" to Recent items 🖼️")
                        }
                    }
                )
            }
            CurrentScreen.VOICE_MEMORY -> {
                VoiceMemoryScreen(
                    onBackClick = {
                        viewModel.navigateTo(CurrentScreen.HOME)
                    },
                    onSaveVoiceMemory = { title, transcription, summary, hasReminder ->
                        viewModel.saveVoiceMemory(title, transcription, summary, hasReminder)
                        viewModel.navigateTo(CurrentScreen.HOME)
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar("Saved voice note \"$title\" 🎙️")
                        }
                    }
                )
            }
            CurrentScreen.AI_SEARCH -> {
                AiSearchScreen(
                    messages = chatMessages,
                    onSendMessage = { query ->
                        viewModel.sendChatMessage(query)
                    },
                    onBackClick = {
                        viewModel.navigateBack()
                    },
                    onVoiceClick = {
                        viewModel.navigateTo(CurrentScreen.VOICE_MEMORY)
                    },
                    onAddMemoryClick = {
                        showAddMemoryModal = true
                    },
                    onOpenCitation = { citation ->
                        openCitationInFullViewer(citation)
                    }
                )
            }
            CurrentScreen.PHOTO_RESIZER -> {
                PhotoResizerScreen(
                    onBackClick = {
                        viewModel.navigateTo(CurrentScreen.HOME)
                    },
                    onSaveSuccess = { title, uri, info, _ ->
                        viewModel.saveImageMemory(
                            title = title,
                            imageUri = uri,
                            amount = info,
                            dueDate = "",
                            includeInSearch = true
                        )
                        viewModel.navigateTo(CurrentScreen.HOME)
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar("Resized photo saved to Recent items 🖼️")
                        }
                    }
                )
            }
            CurrentScreen.SMART_INVOICE_MAKER -> {
                SmartInvoiceMakerScreen(
                    onBackClick = {
                        viewModel.navigateBack()
                    },
                    initialInvoiceId = selectedInvoiceId
                )
            }

            CurrentScreen.TERMS_ONBOARDING -> {
                TermsOnboardingScreen(onAgree = { viewModel.acceptTerms() })
            }
            CurrentScreen.SETTINGS_TERMS -> {
                SettingsScreen(
                    viewModel = viewModel,
                    onNavigateBack = { viewModel.navigateTo(CurrentScreen.HOME) },
                    onNavigateToTerms = { viewModel.navigateTo(CurrentScreen.TERMS_CONDITIONS) },
                    onNavigateToPrivacy = { viewModel.navigateTo(CurrentScreen.PRIVACY_POLICY) }
                )
            }
            CurrentScreen.TERMS_CONDITIONS -> {
                TermsConditionsScreen(onNavigateBack = { viewModel.navigateTo(CurrentScreen.SETTINGS_TERMS) })
            }
            CurrentScreen.PRIVACY_POLICY -> {
                PrivacyPolicyScreen(onNavigateBack = { viewModel.navigateTo(CurrentScreen.SETTINGS_TERMS) })
            }
            CurrentScreen.HOME -> {
                AmbientLightingBackground {
                    Scaffold(
                        containerColor = Color.Transparent,
                        snackbarHost = styledSnackbarHost,
                        floatingActionButtonPosition = FabPosition.Center,
                        floatingActionButton = {
                            Box(
                                modifier = Modifier
                                    .padding(bottom = 12.dp)
                                    .size(70.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.radialGradient(
                                            listOf(Color(0x3500F5D4), Color(0x107928CA), Color.Transparent)
                                        )
                                    )
                                    .border(
                                        1.5.dp,
                                        Brush.sweepGradient(
                                            listOf(
                                                Color(0xFF00F5D4),
                                                Color(0xFF7928CA),
                                                Color(0xFFFF0080),
                                                Color(0xFFFFB800),
                                                Color(0xFF00F5D4)
                                            )
                                        ),
                                        CircleShape
                                    )
                                    .iosBounce { showGalleryVaultSheet = true }
                                    .testTag("fab_gallery_vault"),
                                contentAlignment = Alignment.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(54.dp)
                                        .clip(CircleShape)
                                        .background(
                                            Brush.verticalGradient(
                                                listOf(Color(0xD0181824), Color(0xB0101018))
                                            )
                                        )
                                        .border(
                                            1.2.dp,
                                            Brush.linearGradient(
                                                listOf(Color(0x88FFFFFF), Color(0x3300F5D4))
                                            ),
                                            CircleShape
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    ModernGalleryIcon(
                                        size = 30.dp,
                                        isAnimated = true
                                    )
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("gsdcall_ai_main_screen")
                    ) { paddingValues ->
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(paddingValues)
                                .windowInsetsPadding(WindowInsets.statusBars),
                            contentPadding = PaddingValues(
                                bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 80.dp
                            )
                        ) {
                            // 1. Top Header: Branding 'GTOOL X', avatar, notification bell
                            item(key = "top_header") {
                                TopHeader(
                                    unreadCount = notifications.count { it.isUnread },
                                    accountName = userSession.name,
                                    userEmail = userSession.email,
                                    profileImageUrl = userSession.avatarUrl,
                                    onAvatarClick = { showProfileDialog = true },
                                    onNotificationClick = { showNotificationSheet = true },
                                    onSettingsClick = { viewModel.navigateTo(CurrentScreen.SETTINGS_TERMS) }
                                )
                            }

                            // 2. Prominent large frosted glass card titled 'ASK'
                            item(key = "ask_ai_card") {
                                Spacer(modifier = Modifier.height(6.dp))
                                Box(modifier = Modifier.padding(horizontal = 20.dp)) {
                                    AskAiCard(
                                        searchQuery = searchQuery,
                                        onSearchQueryChange = { viewModel.onSearchQueryChange(it) },
                                        onMicClick = { viewModel.navigateTo(CurrentScreen.VOICE_MEMORY) },
                                        onPromptSuggestionClick = { prompt ->
                                            viewModel.sendChatMessage(prompt)
                                            viewModel.navigateTo(CurrentScreen.AI_SEARCH)
                                        },
                                        onSearchSubmit = { prompt ->
                                            viewModel.sendChatMessage(prompt)
                                            viewModel.navigateTo(CurrentScreen.AI_SEARCH)
                                        }
                                    )
                                }
                            }

                            // 3. Core Module Feature Cards Grid
                            item(key = "home_feature_cards") {
                                Spacer(modifier = Modifier.height(14.dp))
                                HomeFeatureCards(
                                    onFeatureClick = { screen ->
                                        when (screen) {
                                            CurrentScreen.PDF_PREVIEW -> {
                                                pdfPickerLauncher.launch(arrayOf("application/pdf"))
                                            }
                                            CurrentScreen.NOTE_EDITOR -> {
                                                selectedNoteTitle = ""
                                                selectedNoteContent = ""
                                                selectedNoteTags = emptyList()
                                                selectedNoteAttachmentUri = null
                                                viewModel.navigateTo(CurrentScreen.NOTE_EDITOR)
                                            }
                                            CurrentScreen.DOCUMENT_SCANNER -> {
                                                viewModel.navigateTo(CurrentScreen.DOCUMENT_SCANNER)
                                            }
                                            CurrentScreen.IMAGE_MEMORY -> {
                                                selectedImageUri = null
                                                viewModel.navigateTo(CurrentScreen.IMAGE_MEMORY)
                                            }
                                            CurrentScreen.PHOTO_RESIZER -> {
                                                viewModel.navigateTo(CurrentScreen.PHOTO_RESIZER)
                                            }
                                            else -> {
                                                selectedInvoiceId = null
                                                viewModel.navigateTo(screen)
                                            }
                                        }
                                    }
                                )
                            }

                            // 4. Search Results or Filter Row
                            if (searchQuery.isNotBlank()) {
                                item(key = "fts_search_results") {
                                    Spacer(modifier = Modifier.height(18.dp))
                                    SearchResultsSection(
                                        query = searchQuery,
                                        results = searchResults,
                                        onItemClick = { item ->
                                            openItemInFullViewer(item)
                                        }
                                    )
                                }
                            } else {
                                item(key = "filter_row") {
                                    Spacer(modifier = Modifier.height(18.dp))
                                    FilterRow(
                                        selectedType = selectedFilter,
                                        onFilterSelected = { viewModel.onFilterSelected(it) }
                                    )
                                }

                                item(key = "recent_items") {
                                    Spacer(modifier = Modifier.height(14.dp))
                                    RecentItemsSection(
                                        items = recentItems,
                                        selectedFilter = selectedFilter,
                                        onAddMemoryClick = { showAddMemoryModal = true },
                                        onDeleteClick = { item -> itemToDeleteForConfirm = item },
                                        onItemClick = { item ->
                                            openItemInFullViewer(item)
                                        },
                                        onTogglePin = { item ->
                                            viewModel.togglePin(item)
                                            coroutineScope.launch {
                                                snackbarHostState.showSnackbar(
                                                    if (item.isPinned) "Unpinned ${item.title}" else "Pinned ${item.title} to Important"
                                                )
                                            }
                                        }
                                    )
                                }
                            }

                            // 5. Important Items pinned grid
                            if (importantItems.isNotEmpty()) {
                                item(key = "important_items") {
                                    Spacer(modifier = Modifier.height(24.dp))
                                    ImportantItemsGrid(
                                        items = importantItems,
                                        onItemClick = { item -> openItemInFullViewer(item) },
                                        onTogglePin = { item ->
                                            viewModel.togglePin(item)
                                            coroutineScope.launch {
                                                snackbarHostState.showSnackbar("Unpinned ${item.title}")
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Voice Dialog
    if (showVoiceDialog) {
        VoiceAssistantDialog(
            onDismiss = { showVoiceDialog = false },
            onVoiceResult = { result ->
                showVoiceDialog = false
                viewModel.sendChatMessage(result)
                viewModel.navigateTo(CurrentScreen.AI_SEARCH)
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("Query: \"$result\"")
                }
            }
        )
    }

    // Item Detail Dialog
    if (selectedItemForDetail != null) {
        ItemDetailDialog(
            item = selectedItemForDetail!!,
            onDismiss = { selectedItemForDetail = null },
            onTogglePin = { item ->
                viewModel.togglePin(item)
                selectedItemForDetail = item.copy(isPinned = !item.isPinned)
            },
            onAskAiAboutItem = { item ->
                selectedItemForDetail = null
                viewModel.sendChatMessage("Explain ${item.title}")
                viewModel.navigateTo(CurrentScreen.AI_SEARCH)
            },
            onDeleteItem = { item ->
                viewModel.deleteItemPermanently(item)
                selectedItemForDetail = null
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("Item deleted successfully 🗑️")
                }
            },
            onOpenEditor = {
                val item = selectedItemForDetail!!
                selectedItemForDetail = null
                openItemInFullViewer(item)
            },
            onOpenImageMemory = {
                val item = selectedItemForDetail!!
                selectedItemForDetail = null
                openItemInFullViewer(item)
            },
            onOpenVoiceMemory = {
                selectedItemForDetail = null
                viewModel.navigateTo(CurrentScreen.VOICE_MEMORY)
            },
            onOpenScanner = {
                selectedItemForDetail = null
                viewModel.navigateTo(CurrentScreen.DOCUMENT_SCANNER)
            }
        )
    }

    // Delete Confirmation Dialog
    if (itemToDeleteForConfirm != null) {
        DeleteConfirmationDialog(
            item = itemToDeleteForConfirm!!,
            onConfirmDelete = {
                viewModel.deleteItemPermanently(itemToDeleteForConfirm!!)
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("Item deleted successfully 🗑️")
                }
                itemToDeleteForConfirm = null
            },
            onDismiss = { itemToDeleteForConfirm = null }
        )
    }

    // Gallery Vault Sheet
    if (showGalleryVaultSheet) {
        GalleryVaultSheet(
            items = recentItems,
            onItemClick = { item ->
                showGalleryVaultSheet = false
                openItemInFullViewer(item)
            },
            onDeleteItem = { item ->
                viewModel.deleteItemPermanently(item)
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("Item deleted successfully 🗑️")
                }
            },
            onDismiss = { showGalleryVaultSheet = false },
            onUploadPdf = { uri ->
                val (name, size) = queryFileInfo(context, uri)
                selectedPdfName = name
                selectedPdfSize = size
                selectedPdfUri = uri.toString()
                viewModel.navigateTo(CurrentScreen.PDF_PREVIEW)
                showGalleryVaultSheet = false
            },
            onUploadImage = { uri ->
                viewModel.saveImageMemory("Uploaded Photo", uri.toString())
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("Image saved to Vault 📸")
                }
            }
        )
    }

    // Notification Sheet
    if (showNotificationSheet) {
        NotificationSheet(
            notifications = notifications,
            onDismiss = { showNotificationSheet = false }
        )
    }

    // Profile Dialog (Redesigned with Support, Privacy Policy & Logout)
    if (showProfileDialog) {
        UserProfileDialog(
            accountName = userSession.name,
            userEmail = userSession.email,
            profileImageUrl = userSession.avatarUrl,
            isLoggedIn = userSession.isLoggedIn,
            isBiometricEnabled = isBiometricEnabled,
            onToggleBiometric = { enabled ->
                viewModel.setBiometricEnabled(enabled)
                coroutineScope.launch {
                    snackbarHostState.showSnackbar(
                        if (enabled) "Biometric Lock Enabled 🔒" else "Biometric Lock Disabled"
                    )
                }
            },
            backupInfo = backupInfo,
            onCreateBackup = {
                viewModel.createLocalBackup { success, msg ->
                    coroutineScope.launch {
                        snackbarHostState.showSnackbar(msg)
                    }
                }
            },
            onRestoreBackup = {
                viewModel.restoreAllData { count ->
                    coroutineScope.launch {
                        snackbarHostState.showSnackbar("Restored $count memories from backup! 📂")
                    }
                }
            },
            onGoogleSignIn = {
                coroutineScope.launch {
                    val (success, errorMsg) = viewModel.signInWithGoogle(context)
                    if (success) {
                        snackbarHostState.showSnackbar("Connected Google Account! 🚀")
                    } else if (!errorMsg.isNullOrBlank() && !errorMsg.contains("cancelled", ignoreCase = true)) {
                        snackbarHostState.showSnackbar(errorMsg)
                    }
                }
            },
            onSignOut = {
                viewModel.signOut(context)
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("Logged out successfully 👋")
                }
            },
            onDismiss = { showProfileDialog = false }
        )
    }

    // Manage Storage Dialog
    if (showManageStorageDialog) {
        ManageStorageDialog(
            storageData = storageData,
            onDismiss = { showManageStorageDialog = false },
            onSyncNow = {
                viewModel.syncNow()
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("Vault encrypted and verified 🔒")
                }
            },
            onClearCache = {
                viewModel.clearCache()
                coroutineScope.launch {
                    snackbarHostState.showSnackbar("Cache cleaned: 400 MB freed")
                }
            }
        )
    }

    // Add Memory Modal
    if (showAddMemoryModal) {
        AddMemoryModal(
            onDismiss = { showAddMemoryModal = false },
            onMemoryCreated = { title, type, isPrivate ->
                viewModel.addMemory(title, type, isPrivate)
                coroutineScope.launch {
                    snackbarHostState.showSnackbar(
                        if (isPrivate) "🔒 Added \"$title\" with biometric encryption" else "Added \"$title\" to vault"
                    )
                }
            },
            onPdfPicked = { uri ->
                showAddMemoryModal = false
                val (name, size) = queryFileInfo(context, uri)
                selectedPdfName = name
                selectedPdfSize = size
                selectedPdfUri = uri.toString()
                viewModel.navigateTo(CurrentScreen.PDF_PREVIEW)
            },
            onImagePicked = { uri ->
                showAddMemoryModal = false
                selectedImageUri = uri.toString()
                viewModel.navigateTo(CurrentScreen.IMAGE_MEMORY)
            },
            onOpenScanner = {
                showAddMemoryModal = false
                viewModel.navigateTo(CurrentScreen.DOCUMENT_SCANNER)
            },
            onOpenNoteEditor = {
                showAddMemoryModal = false
                selectedNoteTitle = ""
                selectedNoteContent = ""
                selectedNoteTags = emptyList()
                selectedNoteAttachmentUri = null
                viewModel.navigateTo(CurrentScreen.NOTE_EDITOR)
            }
        )
    }

    // Auto-Restore Previous GTOOL X Backup Banner/Dialog on startup
    if (showRestorePrompt) {
        androidx.compose.material3.BasicAlertDialog(
            onDismissRequest = { viewModel.dismissRestorePrompt() },
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .testTag("restore_prompt_dialog")
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(26.dp))
                    .background(Color(0xF5171922))
                    .border(1.5.dp, WarmGold.copy(alpha = 0.6f), RoundedCornerShape(26.dp))
                    .padding(22.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Found Previous GTOOL X Data 📂",
                        style = MaterialTheme.typography.titleLarge.copy(
                            color = WarmGold,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Existing local backups and scanned documents were detected in Documents/GTOOL X/\n\nWould you like to restore all memories, OCR metadata, and FTS indexes now?",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = TextSecondary,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        androidx.compose.material3.OutlinedButton(
                            onClick = { viewModel.dismissRestorePrompt() },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Text("Skip", color = TextSecondary)
                        }
                        androidx.compose.material3.Button(
                            onClick = {
                                viewModel.restoreAllData { count ->
                                    coroutineScope.launch {
                                        snackbarHostState.showSnackbar("Restored $count memories from local vault! 🎉")
                                    }
                                }
                            },
                            modifier = Modifier.weight(1.2f),
                            colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                                containerColor = AmberWarm,
                                contentColor = Color(0xFF0F0E11)
                            ),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Text("Restore All", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // Biometric App Lock Full-Screen Guard Overlay
    if (isBiometricEnabled && !isAppUnlocked) {
        androidx.compose.runtime.LaunchedEffect(isBiometricEnabled, isAppUnlocked) {
            activity?.let { act ->
                BiometricAuthManager.authenticate(
                    activity = act,
                    title = "Unlock GTOOL X",
                    subtitle = "Use Fingerprint, Face, or Device PIN",
                    onSuccess = { viewModel.unlockApp() },
                    onError = { msg ->
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar(msg)
                        }
                    }
                )
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0D0C10))
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(Color(0x35FF9E58))
                        .border(1.5.dp, AmberWarm, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = androidx.compose.material.icons.Icons.Rounded.Lock,
                        contentDescription = "Vault Locked",
                        tint = WarmGold,
                        modifier = Modifier.size(38.dp)
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "Unlock GTOOL X",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Use Fingerprint, Face, or Device PIN to access your vault",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = TextSecondary,
                        fontSize = 13.sp
                    )
                )

                Spacer(modifier = Modifier.height(28.dp))

                androidx.compose.material3.Button(
                    onClick = {
                        activity?.let { act ->
                            BiometricAuthManager.authenticate(
                                activity = act,
                                title = "Unlock GTOOL X",
                                subtitle = "Use Fingerprint, Face, or Device PIN",
                                onSuccess = { viewModel.unlockApp() },
                                onError = { msg ->
                                    coroutineScope.launch {
                                        snackbarHostState.showSnackbar(msg)
                                    }
                                }
                            )
                        }
                    },
                    colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                        containerColor = WarmGold,
                        contentColor = Color(0xFF0F0E11)
                    ),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .height(52.dp)
                        .testTag("btn_unlock_vault")
                ) {
                    Text(
                        text = "Unlock Vault 🔒",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
            }
        }
    }
}

private fun queryFileInfo(context: Context, uri: Uri): Pair<String, String> {
    var name = "Document.pdf"
    var size = "1.8 MB"
    try {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (cursor.moveToFirst()) {
                if (nameIndex != -1) {
                    val displayName = cursor.getString(nameIndex)
                    if (!displayName.isNullOrBlank()) {
                        name = displayName
                    }
                }
                if (sizeIndex != -1) {
                    val bytes = cursor.getLong(sizeIndex)
                    if (bytes > 0) {
                        size = if (bytes < 1024 * 1024) {
                            "${bytes / 1024} KB"
                        } else {
                            String.format(Locale.US, "%.1f MB", bytes.toDouble() / (1024 * 1024))
                        }
                    }
                }
            }
        }
    } catch (_: Exception) {}
    return Pair(name, size)
}
