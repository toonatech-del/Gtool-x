package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.PictureAsPdf
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AmbientLightingBackground
import com.example.ui.components.GlassCard
import com.example.ui.theme.AmberGlow
import com.example.ui.theme.AmberWarm
import com.example.ui.theme.GlassStroke
import com.example.ui.theme.PdfRed
import com.example.ui.theme.SyncGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarmGold
import com.example.util.PdfTextExtractor
import android.net.Uri
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfPreviewScreen(
    fileName: String,
    fileSize: String,
    pdfUri: String? = null,
    onBackClick: () -> Unit,
    onSaveDocument: (title: String, summary: String, keyPoints: List<String>, includeInSearch: Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    var documentTitle by remember(fileName) {
        val initial = if (fileName.isNotBlank()) fileName.removeSuffix(".pdf") else "Imported Document"
        mutableStateOf(initial)
    }

    var summaryText by remember {
        mutableStateOf("")
    }

    val keyPoints = remember {
        mutableStateListOf<String>()
    }

    // Run real on-device PDF text extraction via PdfRenderer + ML Kit
    LaunchedEffect(pdfUri, fileName, fileSize) {
        if (!pdfUri.isNullOrBlank()) {
            try {
                val extracted = PdfTextExtractor.extractTextFromPdfUri(context, Uri.parse(pdfUri))
                if (extracted.isNotBlank() && !extracted.contains("indexed locally on-device")) {
                    summaryText = extracted.take(300).replace("\n", " ") + (if (extracted.length > 300) "..." else "")
                    val lines = extracted.lines().map { it.trim() }.filter { it.isNotBlank() && !it.startsWith("---") }
                    if (lines.isNotEmpty()) {
                        keyPoints.clear()
                        lines.take(3).forEach { line ->
                            keyPoints.add(line.take(80))
                        }
                    }
                } else {
                    if (summaryText.isBlank()) {
                        summaryText = "PDF document ($fileName) saved for search and offline retrieval."
                    }
                }
            } catch (ignored: Exception) {
                if (summaryText.isBlank()) {
                    summaryText = "PDF document ($fileName) saved for search and offline retrieval."
                }
            }
        } else {
            if (summaryText.isBlank()) {
                summaryText = "PDF document ($fileName) saved for search and offline retrieval."
            }
        }
    }

    var newPointText by remember { mutableStateOf("") }
    var isAddingPoint by remember { mutableStateOf(false) }
    var includeInSemanticSearch by remember { mutableStateOf(true) }

    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    AmbientLightingBackground {
        Scaffold(
            containerColor = Color.Transparent,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            modifier = modifier
                .fillMaxSize()
                .testTag("pdf_preview_screen"),
            topBar = {
                PdfPreviewTopBar(
                    onBackClick = onBackClick,
                    onSaveClick = {
                        val finalTitle = if (documentTitle.isNotBlank()) documentTitle.trim() else fileName
                        onSaveDocument(
                            finalTitle,
                            summaryText,
                            keyPoints.toList(),
                            includeInSemanticSearch
                        )
                    }
                )
            },
            bottomBar = {
                // Prominent frosted 'Save Document' button
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 20.dp, vertical = 14.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .clip(RoundedCornerShape(27.dp))
                            .background(
                                Brush.horizontalGradient(
                                    listOf(AmberWarm, AmberGlow)
                                )
                            )
                            .border(
                                1.dp,
                                Color.White.copy(alpha = 0.5f),
                                RoundedCornerShape(27.dp)
                            )
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = ripple(color = Color.White.copy(alpha = 0.4f)),
                                onClick = {
                                    val finalTitle = if (documentTitle.isNotBlank()) documentTitle.trim() else fileName
                                    onSaveDocument(
                                        finalTitle,
                                        summaryText,
                                        keyPoints.toList(),
                                        includeInSemanticSearch
                                    )
                                }
                            )
                            .testTag("save_pdf_document_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Outlined.CheckCircle,
                                contentDescription = null,
                                tint = Color(0xFF0F0E11),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Save Document",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    color = Color(0xFF0F0E11),
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 16.sp,
                                    letterSpacing = 0.2.sp
                                ),
                                modifier = Modifier.testTag("save_pdf_document_text")
                            )
                        }
                    }
                }
            }
        ) { paddingValues ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentPadding = PaddingValues(
                    start = 20.dp,
                    end = 20.dp,
                    top = 8.dp,
                    bottom = 24.dp
                ),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Header badge & title
                item(key = "pdf_header_badge") {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0x28FF9E58))
                                    .border(
                                        1.dp,
                                        Brush.linearGradient(
                                            listOf(AmberWarm.copy(alpha = 0.6f), Color(0x30FFA767))
                                        ),
                                        RoundedCornerShape(12.dp)
                                    )
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(CircleShape)
                                            .background(SyncGreen)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "PDF Document",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = WarmGold,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                            }

                            Text(
                                text = fileSize,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = TextMuted,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "PDF Preview",
                            style = MaterialTheme.typography.displayLarge.copy(
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 32.sp,
                                letterSpacing = (-0.8).sp,
                                fontFamily = FontFamily.SansSerif,
                                color = TextPrimary
                            ),
                            modifier = Modifier.testTag("pdf_preview_title")
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "Local PDF document selected from device storage",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = TextSecondary,
                                fontSize = 13.sp
                            )
                        )
                    }
                }

                // File Information Frosted Card
                item(key = "file_info_card") {
                    GlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("pdf_file_info_card"),
                        shape = RoundedCornerShape(24.dp),
                        borderStrokeWidth = 1.dp,
                        borderColorList = listOf(
                            Color(0x60FFFFFF),
                            Color(0x20FFFFFF),
                            Color(0x40FFFFFF)
                        ),
                        ambientGlowColor = PdfRed
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(Color(0x33EF4444))
                                        .border(1.dp, Color(0x66EF4444), RoundedCornerShape(14.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.PictureAsPdf,
                                        contentDescription = "PDF File",
                                        tint = PdfRed,
                                        modifier = Modifier.size(26.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(14.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "FILE NAME",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = TextMuted,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            letterSpacing = 0.5.sp
                                        )
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = fileName,
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            color = TextPrimary,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp
                                        ),
                                        modifier = Modifier.testTag("pdf_file_name_display")
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Text(
                                text = "DISPLAY TITLE",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = WarmGold,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.6.sp
                                )
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(Color(0x20FFFFFF))
                                    .border(1.dp, GlassStroke, RoundedCornerShape(14.dp))
                                    .padding(horizontal = 14.dp, vertical = 12.dp)
                            ) {
                                BasicTextField(
                                    value = documentTitle,
                                    onValueChange = { documentTitle = it },
                                    textStyle = MaterialTheme.typography.bodyLarge.copy(
                                        color = TextPrimary,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.SemiBold
                                    ),
                                    cursorBrush = SolidColor(AmberWarm),
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("pdf_title_input")
                                )
                            }
                        }
                    }
                }

                // Frosted glass card for 'Document Summary / Important Points'
                item(key = "document_summary_card") {
                    Text(
                        text = "DOCUMENT SUMMARY / IMPORTANT POINTS",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = WarmGold,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            letterSpacing = 0.8.sp
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    GlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("pdf_summary_card"),
                        shape = RoundedCornerShape(24.dp),
                        borderStrokeWidth = 1.dp,
                        borderColorList = listOf(
                            Color(0x60FFFFFF),
                            Color(0x20FFFFFF),
                            Color(0x40FFFFFF)
                        ),
                        ambientGlowColor = AmberWarm
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Outlined.AutoAwesome,
                                        contentDescription = null,
                                        tint = AmberWarm,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Executive Summary",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp,
                                            color = TextPrimary
                                        )
                                    )
                                }

                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Color(0x20FFFFFF))
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        text = "Editable",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = TextSecondary,
                                            fontSize = 10.sp
                                        )
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Editable Summary Box
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(Color(0x18FFFFFF))
                                    .border(1.dp, GlassStroke, RoundedCornerShape(14.dp))
                                    .padding(horizontal = 14.dp, vertical = 12.dp)
                            ) {
                                BasicTextField(
                                    value = summaryText,
                                    onValueChange = { summaryText = it },
                                    textStyle = MaterialTheme.typography.bodyMedium.copy(
                                        color = TextPrimary,
                                        fontSize = 13.sp,
                                        lineHeight = 20.sp
                                    ),
                                    cursorBrush = SolidColor(AmberWarm),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("pdf_summary_input")
                                )
                            }

                            Spacer(modifier = Modifier.height(18.dp))

                            Text(
                                text = "Key Extracted Points",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = TextPrimary
                                )
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // Bullet Points
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                keyPoints.forEachIndexed { index, point ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(Color(0x12FFFFFF))
                                            .border(0.5.dp, Color(0x20FFFFFF), RoundedCornerShape(12.dp))
                                            .padding(horizontal = 12.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.Top
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .padding(top = 4.dp)
                                                .size(6.dp)
                                                .clip(CircleShape)
                                                .background(AmberWarm)
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Text(
                                            text = point,
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                color = TextPrimary,
                                                fontSize = 12.sp,
                                                lineHeight = 18.sp
                                            ),
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Add point button or input
                            if (isAddingPoint) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(Color(0x20FFFFFF))
                                            .border(1.dp, GlassStroke, RoundedCornerShape(12.dp))
                                            .padding(horizontal = 12.dp, vertical = 10.dp)
                                    ) {
                                        BasicTextField(
                                            value = newPointText,
                                            onValueChange = { newPointText = it },
                                            textStyle = MaterialTheme.typography.bodySmall.copy(
                                                color = TextPrimary,
                                                fontSize = 12.sp
                                            ),
                                            cursorBrush = SolidColor(AmberWarm),
                                            singleLine = true,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(8.dp))

                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(
                                                Brush.horizontalGradient(listOf(AmberWarm, AmberGlow))
                                            )
                                            .clickable {
                                                if (newPointText.isNotBlank()) {
                                                    keyPoints.add(newPointText.trim())
                                                    newPointText = ""
                                                    isAddingPoint = false
                                                }
                                            }
                                            .padding(horizontal = 12.dp, vertical = 10.dp)
                                    ) {
                                        Text(
                                            text = "Add",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = Color(0xFF0F0E11),
                                                fontWeight = FontWeight.Bold
                                            )
                                        )
                                    }
                                }
                            } else {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(Color(0x18FFFFFF))
                                        .clickable { isAddingPoint = true }
                                        .padding(horizontal = 12.dp, vertical = 8.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Outlined.Add,
                                            contentDescription = null,
                                            tint = AmberWarm,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "+ Add Point",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = WarmGold,
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 11.sp
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // 'Include in AI Semantic Search' toggle
                item(key = "semantic_search_toggle") {
                    GlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("pdf_semantic_search_toggle_card"),
                        shape = RoundedCornerShape(20.dp),
                        borderStrokeWidth = 1.dp,
                        borderColorList = listOf(
                            Color(0x60FFFFFF),
                            Color(0x20FFFFFF),
                            Color(0x40FFFFFF)
                        ),
                        ambientGlowColor = AmberWarm
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 18.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Include in AI Semantic Search",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = TextPrimary
                                    )
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Enable natural language Q&A and vector lookup across this PDF",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = TextSecondary,
                                        fontSize = 11.sp
                                    )
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Switch(
                                checked = includeInSemanticSearch,
                                onCheckedChange = { includeInSemanticSearch = it },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color(0xFF161318),
                                    checkedTrackColor = AmberWarm,
                                    checkedBorderColor = AmberGlow,
                                    uncheckedThumbColor = TextMuted,
                                    uncheckedTrackColor = Color(0x2AFFFFFF),
                                    uncheckedBorderColor = Color(0x33FFFFFF)
                                ),
                                modifier = Modifier.testTag("pdf_semantic_search_switch")
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PdfPreviewTopBar(
    onBackClick: () -> Unit,
    onSaveClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.statusBars)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Back Button
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(Color(0x24FFFFFF))
                .border(1.dp, GlassStroke, CircleShape)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = ripple(color = Color.White.copy(alpha = 0.3f)),
                    onClick = onBackClick
                )
                .testTag("pdf_preview_back_button"),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
                contentDescription = "Back",
                tint = TextPrimary,
                modifier = Modifier.size(20.dp)
            )
        }

        // Save Pill Button in Top Bar
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(
                    Brush.horizontalGradient(listOf(AmberWarm, AmberGlow))
                )
                .border(1.dp, Color.White.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = ripple(color = Color.White.copy(alpha = 0.35f)),
                    onClick = onSaveClick
                )
                .padding(horizontal = 18.dp, vertical = 8.dp)
                .testTag("top_bar_save_pdf_button")
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Outlined.Check,
                    contentDescription = null,
                    tint = Color(0xFF0F0E11),
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Save",
                    style = MaterialTheme.typography.labelLarge.copy(
                        color = Color(0xFF0F0E11),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.sp
                    )
                )
            }
        }
    }
}
