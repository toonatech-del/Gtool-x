package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AspectRatio
import androidx.compose.material.icons.outlined.Badge
import androidx.compose.material.icons.outlined.DocumentScanner
import androidx.compose.material.icons.outlined.EditNote
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.PictureAsPdf
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CurrentScreen
import com.example.ui.theme.AmberWarm
import com.example.ui.theme.ImagePurple
import com.example.ui.theme.LocalIsDarkMode
import com.example.ui.theme.NoteYellow
import com.example.ui.theme.PdfRed
import com.example.ui.theme.SectionHeaderColor
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.WarmGold

data class FeatureModule(
    val title: String,
    val icon: ImageVector,
    val iconTint: Color,
    val targetScreen: CurrentScreen,
    val testTag: String
)

@Composable
fun HomeFeatureCards(
    onFeatureClick: (CurrentScreen) -> Unit,
    modifier: Modifier = Modifier
) {
    val isDarkMode = LocalIsDarkMode.current
    val sectionHeaderColor = if (isDarkMode) SectionHeaderColor else Color(0xFF000000)
    val modules = listOf(
        FeatureModule(
            title = "PDF",
            icon = Icons.Outlined.PictureAsPdf,
            iconTint = PdfRed,
            targetScreen = CurrentScreen.PDF_PREVIEW,
            testTag = "feature_card_pdf"
        ),
        FeatureModule(
            title = "Notepad",
            icon = Icons.Outlined.EditNote,
            iconTint = NoteYellow,
            targetScreen = CurrentScreen.NOTE_EDITOR,
            testTag = "feature_card_notepad"
        ),
        FeatureModule(
            title = "Scan & Document",
            icon = Icons.Outlined.DocumentScanner,
            iconTint = AmberWarm,
            targetScreen = CurrentScreen.DOCUMENT_SCANNER,
            testTag = "feature_card_scan_doc"
        ),
        FeatureModule(
            title = "Image",
            icon = Icons.Outlined.Image,
            iconTint = ImagePurple,
            targetScreen = CurrentScreen.IMAGE_MEMORY,
            testTag = "feature_card_image"
        ),
        FeatureModule(
            title = "Photo Resizer",
            icon = Icons.Outlined.AspectRatio,
            iconTint = Color(0xFF64B5F6),
            targetScreen = CurrentScreen.PHOTO_RESIZER,
            testTag = "feature_card_photo_resizer"
        ),
        FeatureModule(
            title = "Passport Photo Maker",
            icon = Icons.Outlined.Badge,
            iconTint = WarmGold,
            targetScreen = CurrentScreen.PASSPORT_PHOTO_MAKER,
            testTag = "feature_card_passport_photo"
        )
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp)
            .testTag("home_feature_cards_container")
    ) {
        // Section Header: Crisp semi-bold sub-headings (font-size: 18px, font-weight: 600)
        Text(
            text = "Tools & Modules",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.SemiBold,
                fontSize = 18.sp,
                color = sectionHeaderColor
            ),
            modifier = Modifier.padding(bottom = 12.dp)
        )

        // 2-column grid layout for rounded dock format (border-radius: 24px)
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            modules.chunked(2).forEach { rowModules ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    rowModules.forEach { module ->
                        Box(modifier = Modifier.weight(1f)) {
                            FeatureCardItem(
                                module = module,
                                onClick = { onFeatureClick(module.targetScreen) }
                            )
                        }
                    }
                    if (rowModules.size < 2) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
private fun FeatureCardItem(
    module: FeatureModule,
    onClick: () -> Unit
) {
    val isDarkMode = LocalIsDarkMode.current
    val titleColor = if (isDarkMode) TextPrimary else Color(0xFF111111)

    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .zoomOnPress(
                pressedScale = 0.95f,
                rippleColor = module.iconTint.copy(alpha = 0.3f),
                onClick = onClick
            )
            .testTag(module.testTag),
        shape = RoundedCornerShape(24.dp),
        ambientGlowColor = module.iconTint
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // High-contrast circular icon chip
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(
                        if (isDarkMode) {
                            Brush.radialGradient(
                                listOf(
                                    module.iconTint.copy(alpha = 0.3f),
                                    Color(0x332D2A22)
                                )
                            )
                        } else {
                            Brush.radialGradient(
                                listOf(
                                    module.iconTint.copy(alpha = 0.25f),
                                    Color(0x44FFFFFF)
                                )
                            )
                        }
                    )
                    .border(
                        1.dp,
                        if (isDarkMode) Color.White.copy(alpha = 0.2f) else Color(0x66000000),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = module.icon,
                    contentDescription = module.title,
                    tint = module.iconTint,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Text(
                text = module.title,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    letterSpacing = (-0.2).sp,
                    color = titleColor
                ),
                maxLines = 2
            )
        }
    }
}
