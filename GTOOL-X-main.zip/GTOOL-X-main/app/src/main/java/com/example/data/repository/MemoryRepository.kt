package com.example.data.repository

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.data.local.AppDatabase
import com.example.data.local.MemoryEntity
import com.example.model.ItemType
import com.example.model.WorkspaceItem
import com.example.util.MlKitTextExtractor
import com.example.util.PdfTextExtractor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MemoryRepository(private val context: Context) {

    private val db = AppDatabase.getInstance(context)
    private val memoryDao = db.memoryDao()

    companion object {
        private const val TAG = "MemoryRepository"
    }

    /**
     * Flow of all memories stored in SQLite
     */
    val allMemories: Flow<List<WorkspaceItem>> = memoryDao.getAllMemories()
        .map { entities -> entities.map { it.toWorkspaceItem() } }
        .flowOn(Dispatchers.IO)

    /**
     * Flow of pinned/important memories
     */
    val importantMemories: Flow<List<WorkspaceItem>> = memoryDao.getImportantMemories()
        .map { entities -> entities.map { it.toWorkspaceItem() } }
        .flowOn(Dispatchers.IO)

    /**
     * Real-time offline search with FTS4 MATCH query:
     * SELECT memories.* FROM memories JOIN memories_fts ON memories.rowid = memories_fts.rowid WHERE memories_fts MATCH :matchQuery
     *
     * Supports wildcard tokens (e.g. *query* or query*)
     */
    fun searchMemories(rawQuery: String): Flow<List<WorkspaceItem>> {
        val cleanQuery = rawQuery.trim()
        if (cleanQuery.isEmpty()) {
            return allMemories
        }

        // Prepare FTS4 wildcard query tokens: split on whitespace and append *
        // E.g. "bike salary 1240" -> "*bike* *salary* *1240*" or "bike* salary* 1240*"
        val ftsTokens = cleanQuery
            .split("\\s+".toRegex())
            .filter { it.isNotBlank() }
            .map { token ->
                // Clean alphanumeric and punctuation for safe FTS query
                val sanitized = token.replace("\"", "").replace("'", "").replace("*", "")
                if (sanitized.isNotEmpty()) "\"$sanitized*\"" else ""
            }
            .filter { it.isNotBlank() }

        val ftsQuery = if (ftsTokens.isNotEmpty()) {
            ftsTokens.joinToString(" ")
        } else {
            "\"$cleanQuery*\""
        }

        return memoryDao.searchMemoriesFts(ftsQuery)
            .flatMapLatest { entities ->
                if (entities.isEmpty()) {
                    memoryDao.searchMemoriesLike(cleanQuery).map { fallbackEntities ->
                        fallbackEntities.map { it.toWorkspaceItem() }
                    }
                } else {
                    flowOf(entities.map { it.toWorkspaceItem() })
                }
            }
            .flowOn(Dispatchers.IO)
    }

    /**
     * Saves a Note directly into SQLite memories & FTS4 index.
     */
    suspend fun saveNote(
        id: String = "note-${System.currentTimeMillis()}",
        title: String,
        content: String,
        tags: List<String>,
        hasAttachment: Boolean,
        includeInSemanticSearch: Boolean,
        attachmentUri: String? = null
    ): WorkspaceItem = withContext(Dispatchers.IO) {
        val cleanTitle = when {
            title.isNotBlank() -> title.trim()
            content.isNotBlank() -> {
                val firstLine = content.lines().firstOrNull { it.isNotBlank() }?.trim() ?: "Untitled Note"
                if (firstLine.length > 40) firstLine.take(40) + "..." else firstLine
            }
            else -> "Untitled Note"
        }

        // If note has an attached image, extract text via ML Kit on-device
        val extractedImageText = if (attachmentUri != null) {
            try {
                MlKitTextExtractor.extractTextFromUri(context, Uri.parse(attachmentUri))
            } catch (e: Exception) {
                ""
            }
        } else {
            ""
        }

        val fullExtractedText = buildString {
            append(cleanTitle)
            append("\n\n")
            append(content)
            if (tags.isNotEmpty()) {
                append("\nTags: ")
                append(tags.joinToString(" "))
            }
            if (extractedImageText.isNotBlank()) {
                append("\n[Attached Photo OCR Extracted Text]:\n")
                append(extractedImageText)
            }
        }

        val words = content.split("\\s+".toRegex()).filter { it.isNotBlank() }.size
        val primaryTag = tags.firstOrNull()?.removePrefix("#")?.replaceFirstChar { it.uppercase() } ?: "Note"
        val firstSummaryLine = content.lines().firstOrNull { it.isNotBlank() }?.take(90) ?: "Notepad memory"

        val entity = MemoryEntity(
            id = id,
            type = "note",
            title = cleanTitle,
            extractedText = fullExtractedText,
            imageUri = attachmentUri,
            createdAt = System.currentTimeMillis(),
            sizeText = "$words words${if (hasAttachment) " • 1 Photo" else ""}",
            summary = firstSummaryLine,
            subtitle = "Notepad • ${if (includeInSemanticSearch) "FTS4 Indexed" else "Local Storage"}${if (hasAttachment) " • 📷 Photo attached" else ""}",
            tag = primaryTag,
            isPinned = false
        )

        memoryDao.insertMemory(entity)
        entity.toWorkspaceItem()
    }

    /**
     * Saves an Image into SQLite memories & FTS4 index.
     * Uses on-device Google ML Kit Text Recognition to extract text line-by-line.
     */
    suspend fun saveImageMemory(
        id: String = "img-${System.currentTimeMillis()}",
        title: String,
        imageUri: String?,
        amount: String = "",
        dueDate: String = "",
        includeInSearch: Boolean = true
    ): WorkspaceItem = withContext(Dispatchers.IO) {
        // Run real ML Kit Text Recognition on-device
        val ocrExtractedText = if (imageUri != null) {
            try {
                MlKitTextExtractor.extractTextFromUri(context, Uri.parse(imageUri))
            } catch (e: Exception) {
                Log.e(TAG, "Failed OCR extraction for image: $imageUri", e)
                ""
            }
        } else {
            ""
        }

        val fullSearchableText = buildString {
            append(title)
            if (amount.isNotBlank()) append("\nAmount: $amount")
            if (dueDate.isNotBlank()) append("\nDue Date: $dueDate")
            if (ocrExtractedText.isNotBlank()) {
                append("\n\nExtracted OCR Text:\n")
                append(ocrExtractedText)
            }
        }

        val summaryText = when {
            ocrExtractedText.isNotBlank() -> ocrExtractedText.lines().firstOrNull { it.isNotBlank() }?.take(80) ?: "OCR text recognized on-device"
            amount.isNotBlank() -> "Amount: $amount • Due: $dueDate"
            else -> "Scanned image indexed offline"
        }

        val entity = MemoryEntity(
            id = id,
            type = "image",
            title = title.ifBlank { "Scanned Document" },
            extractedText = fullSearchableText,
            imageUri = imageUri,
            createdAt = System.currentTimeMillis(),
            sizeText = if (amount.isNotBlank()) "$amount • Image" else "3.2 MB • Image",
            summary = summaryText,
            subtitle = "Receipt / Document • ML Kit OCR Indexed",
            tag = "Receipt",
            isPinned = false
        )

        memoryDao.insertMemory(entity)
        entity.toWorkspaceItem()
    }

    /**
     * Saves a PDF into SQLite memories & FTS4 index.
     * Extracts text locally from pages on-device.
     */
    suspend fun savePdfMemory(
        id: String = "pdf-${System.currentTimeMillis()}",
        title: String,
        fileName: String,
        fileSize: String,
        summary: String,
        keyPoints: List<String>,
        pdfUri: Uri? = null,
        includeInSearch: Boolean = true
    ): WorkspaceItem = withContext(Dispatchers.IO) {
        val extractedPdfText = if (pdfUri != null) {
            try {
                PdfTextExtractor.extractTextFromPdfUri(context, pdfUri)
            } catch (e: Exception) {
                Log.e(TAG, "Error extracting text from PDF", e)
                ""
            }
        } else {
            ""
        }

        val fullText = buildString {
            append(title)
            append("\n")
            append(summary)
            append("\n")
            append(keyPoints.joinToString("\n"))
            if (extractedPdfText.isNotBlank()) {
                append("\n\nExtracted Pages Text:\n")
                append(extractedPdfText)
            }
        }

        val entity = MemoryEntity(
            id = id,
            type = "pdf",
            title = title.ifBlank { fileName },
            extractedText = fullText,
            imageUri = null,
            createdAt = System.currentTimeMillis(),
            sizeText = fileSize.ifBlank { "1.8 MB" },
            summary = summary.ifBlank { "PDF parsed locally on device" },
            subtitle = "PDF Document • Offline FTS4 Index",
            tag = "Document",
            isPinned = false
        )

        memoryDao.insertMemory(entity)
        entity.toWorkspaceItem()
    }

    /**
     * Saves a voice note memory
     */
    suspend fun saveVoiceMemory(
        id: String = "voice-${System.currentTimeMillis()}",
        title: String,
        transcription: String,
        summary: String,
        hasReminder: Boolean
    ): WorkspaceItem = withContext(Dispatchers.IO) {
        val fullText = "$title\n$summary\n$transcription"
        val entity = MemoryEntity(
            id = id,
            type = "voice",
            title = title,
            extractedText = fullText,
            imageUri = null,
            createdAt = System.currentTimeMillis(),
            sizeText = "1m 45s (Audio)",
            summary = summary,
            subtitle = "Voice Note • ${if (hasReminder) "Reminder set" else "Transcribed"}",
            tag = "Voice",
            isPinned = false
        )

        memoryDao.insertMemory(entity)
        entity.toWorkspaceItem()
    }

    suspend fun togglePin(item: WorkspaceItem) = withContext(Dispatchers.IO) {
        val existing = memoryDao.getMemoryById(item.id)
        if (existing != null) {
            memoryDao.updateMemory(existing.copy(isPinned = !existing.isPinned))
        }
    }

    suspend fun deleteMemory(id: String) = withContext(Dispatchers.IO) {
        memoryDao.deleteMemoryById(id)
    }

    suspend fun markItemSyncedToDrive(id: String, driveFileId: String? = null) = withContext(Dispatchers.IO) {
        val fileId = driveFileId ?: "drive-${System.currentTimeMillis()}"
        memoryDao.updateSyncStatus(id, true, fileId)
    }

    suspend fun getMemoryById(id: String): MemoryEntity? = withContext(Dispatchers.IO) {
        memoryDao.getMemoryById(id)
    }

    /**
     * Extension to convert MemoryEntity to WorkspaceItem model for UI
     */
    private fun MemoryEntity.toWorkspaceItem(): WorkspaceItem {
        val itemType = when (type.lowercase(Locale.ROOT)) {
            "note" -> ItemType.NOTE
            "pdf" -> ItemType.PDF
            "image" -> ItemType.IMAGE
            "voice" -> ItemType.VOICE
            else -> ItemType.NOTE
        }

        val dateFormatted = try {
            val sdf = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault())
            sdf.format(Date(createdAt))
        } catch (e: Exception) {
            "Just now"
        }

        return WorkspaceItem(
            id = id,
            title = title,
            type = itemType,
            dateModified = dateFormatted,
            sizeText = sizeText.ifBlank { if (itemType == ItemType.NOTE) "Note" else "1.2 MB" },
            summary = summary.ifBlank { extractedText.take(90) },
            subtitle = subtitle.ifBlank { "${itemType.label} • Offline FTS4 Index" },
            isPinned = isPinned,
            tag = tag ?: itemType.label,
            contentSnippet = extractedText,
            imageUri = imageUri,
            isSyncedToDrive = isSyncedToDrive,
            driveFileId = driveFileId
        )
    }
}
