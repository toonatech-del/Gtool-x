package com.example.data.repository

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.util.Log
import com.example.data.local.AppDatabase
import com.example.data.local.MemoryEntity
import com.example.data.local.MemoryFtsEntity
import com.example.model.ItemType
import com.example.model.WorkspaceItem
import com.example.util.MlKitTextExtractor
import com.example.util.PdfPageRenderer
import com.example.util.PdfTextExtractor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import org.json.JSONObject

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MemoryRepository(private val context: Context) {

    private val db = AppDatabase.getInstance(context)
    private val memoryDao = db.memoryDao()
    private val universalSearchRepo = UniversalSearchRepository(context)

    fun getDao() = memoryDao


    companion object {
        private const val TAG = "MemoryRepository"
    }

    /**
     * Flow of all memories stored in SQLite
     */
    val allMemories: Flow<List<WorkspaceItem>> = memoryDao.getAllMemories()
        .map { entities -> entities.map { it.toWorkspaceItem() } }
        .flowOn(Dispatchers.IO)

    /**
     * Flow of pinned/important memories
     */
    val importantMemories: Flow<List<WorkspaceItem>> = memoryDao.getImportantMemories()
        .map { entities -> entities.map { it.toWorkspaceItem() } }
        .flowOn(Dispatchers.IO)

    private fun extractAndAppendEntities(title: String, rawText: String): String {
        val phoneRegex = Regex("""(\+?\d{1,4}?[-.\s]?\(?\d{1,3}?\)?[-.\s]?\d{1,4}[-.\s]?\d{1,9})""")
        val emailRegex = Regex("""\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}\b""")
        val dateRegex = Regex("""\b\d{2,4}[-./]\d{2}[-./]\d{2,4}\b""")

        val combinedText = "$title\n$rawText"
        val entities = mutableListOf<String>()

        // Find phone numbers
        val phones = phoneRegex.findAll(combinedText).map { it.value.trim() }.filter { it.length >= 7 && it.any { c -> c.isDigit() } }.toList()
        if (phones.isNotEmpty()) {
            entities.addAll(phones)
            entities.add("phone")
            entities.add("mobile")
            entities.add("contact")
        }

        // Find emails
        val emails = emailRegex.findAll(combinedText).map { it.value.trim() }.toList()
        if (emails.isNotEmpty()) {
            entities.addAll(emails)
            entities.add("email")
            entities.add("contact")
        }

        // Find dates
        val dates = dateRegex.findAll(combinedText).map { it.value.trim() }.toList()
        if (dates.isNotEmpty()) {
            entities.addAll(dates)
            entities.add("date")
        }

        val distinctEntities = entities.distinct()
        return if (distinctEntities.isNotEmpty()) {
            rawText + "\n\nSearchable Metadata / Entities:\n" + distinctEntities.joinToString(" ")
        } else {
            rawText
        }
    }

    /**
     * Real-time offline search with FTS4 MATCH query:
     * SELECT memories.* FROM memories JOIN memories_fts ON memories.rowid = memories_fts.rowid WHERE memories_fts MATCH :matchQuery
     *
     * Supports wildcard tokens (e.g. *query* or query*)
     */
    fun searchMemories(rawQuery: String): Flow<List<WorkspaceItem>> {
        val cleanQuery = rawQuery.trim()
        if (cleanQuery.isEmpty()) {
            return allMemories
        }

        // Normalize query: If user searches "phone number" or "mobile number" or contact, or searches contact digits
        val isPhoneQuery = cleanQuery.contains("phone", ignoreCase = true) ||
                cleanQuery.contains("mobile", ignoreCase = true) ||
                cleanQuery.contains("contact", ignoreCase = true) ||
                (cleanQuery.length >= 4 && cleanQuery.all { it.isDigit() || it == '+' || it == '-' })

        val normalizedQuery = if (isPhoneQuery) {
            "phone OR mobile OR contact OR \"$cleanQuery\""
        } else {
            cleanQuery
        }

        // Prepare FTS4 wildcard query tokens: split on whitespace and append *
        val ftsQuery = if (isPhoneQuery) {
            "\"phone*\" OR \"mobile*\" OR \"contact*\" OR \"$cleanQuery*\""
        } else {
            val tokens = normalizedQuery
                .split("\\s+".toRegex())
                .filter { it.isNotBlank() }
                .map { token ->
                    val sanitized = token.replace("\"", "").replace("'", "").replace("*", "")
                    if (sanitized.isNotEmpty()) "\"$sanitized*\"" else ""
                }
                .filter { it.isNotBlank() }
            if (tokens.isNotEmpty()) {
                tokens.joinToString(" AND ")
            } else {
                "\"$normalizedQuery*\""
            }
        }

        val likeQueryTerm = if (isPhoneQuery && !cleanQuery.any { it.isDigit() }) "phone" else cleanQuery

        return memoryDao.searchMemoriesFts(ftsQuery)
            .flatMapLatest { entities ->
                memoryDao.searchMemoriesLike(likeQueryTerm).map { fallbackEntities ->
                    // Combine and deduplicate to make sure out-of-sync rowids are gracefully resolved
                    val combined = (entities + fallbackEntities).distinctBy { it.id }
                    combined.map { it.toWorkspaceItem() }
                }
            }
            .flowOn(Dispatchers.IO)
    }

    /**
     * Saves a Note directly into SQLite memories & FTS4 index.
     */
    suspend fun saveNote(
        id: String = "note-${System.currentTimeMillis()}",
        title: String,
        content: String,
        tags: List<String>,
        hasAttachment: Boolean,
        includeInSemanticSearch: Boolean,
        attachmentUri: String? = null
    ): WorkspaceItem = withContext(Dispatchers.IO) {
        val cleanTitle = when {
            title.isNotBlank() -> title.trim()
            content.isNotBlank() -> {
                val firstLine = content.lines().firstOrNull { it.isNotBlank() }?.trim() ?: "Untitled Note"
                if (firstLine.length > 40) firstLine.take(40) + "..." else firstLine
            }
            else -> "Untitled Note"
        }

        // If note has an attached image, extract text via ML Kit on-device
        val extractedImageText = if (attachmentUri != null) {
            try {
                MlKitTextExtractor.extractTextFromUri(context, Uri.parse(attachmentUri))
            } catch (e: Exception) {
                ""
            }
        } else {
            ""
        }

        val fullExtractedText = buildString {
            append(cleanTitle)
            append("\n\n")
            append(content)
            if (tags.isNotEmpty()) {
                append("\nTags: ")
                append(tags.joinToString(" "))
            }
            if (extractedImageText.isNotBlank()) {
                append("\n[Attached Photo OCR Extracted Text]:\n")
                append(extractedImageText)
            }
        }

        val fullExtractedTextWithEntities = extractAndAppendEntities(cleanTitle, fullExtractedText)
        val words = content.split("\\s+".toRegex()).filter { it.isNotBlank() }.size
        val primaryTag = tags.firstOrNull()?.removePrefix("#")?.replaceFirstChar { it.uppercase() } ?: "Note"
        val firstSummaryLine = content.lines().firstOrNull { it.isNotBlank() }?.take(90) ?: "Notepad memory"

        val entity = MemoryEntity(
            id = id,
            type = "note",
            title = cleanTitle,
            extractedText = fullExtractedTextWithEntities,
            imageUri = attachmentUri,
            createdAt = System.currentTimeMillis(),
            sizeText = "$words words${if (hasAttachment) " • 1 Photo" else ""}",
            summary = firstSummaryLine,
            subtitle = "Notepad • ${if (includeInSemanticSearch) "FTS4 Indexed" else "Local Storage"}${if (hasAttachment) " • 📷 Photo attached" else ""}",
            tag = primaryTag,
            isPinned = false
        )

        memoryDao.insertMemory(entity)
        memoryDao.insertFts(MemoryFtsEntity(id = id, title = cleanTitle, extractedText = fullExtractedTextWithEntities))

        // Index in Universal Search
        universalSearchRepo.insertOrUpdate(
            id = id,
            module = "Note",
            title = cleanTitle,
            contentText = fullExtractedTextWithEntities,
            metadataJson = JSONObject().apply {
                put("tags", tags.joinToString(","))
                put("has_attachment", hasAttachment)
                put("attachment_uri", attachmentUri ?: "")
            }.toString(),
            imageUri = attachmentUri
        )

        entity.toWorkspaceItem()
    }

    /**
     * Saves an Image into SQLite memories & FTS4 index.
     * Uses on-device Google ML Kit Text Recognition to extract text line-by-line.
     * Persists uploaded image file locally into app internal files.
     */
    suspend fun saveImageMemory(
        id: String = "img-${System.currentTimeMillis()}",
        title: String,
        imageUri: String?,
        amount: String = "",
        dueDate: String = "",
        includeInSearch: Boolean = true,
        fullOcrText: String = ""
    ): WorkspaceItem = withContext(Dispatchers.IO) {
        // Persist real uploaded image into app internal storage
        val permanentImageUri = if (imageUri != null) {
            try {
                val inputUri = Uri.parse(imageUri)
                if (inputUri.scheme == "file" && inputUri.path?.startsWith(context.filesDir.path) == true) {
                    imageUri
                } else {
                    val imagesDir = File(context.filesDir, "vault_images").apply { mkdirs() }
                    val destFile = File(imagesDir, "img_${id}.jpg")
                    context.contentResolver.openInputStream(inputUri)?.use { input ->
                        FileOutputStream(destFile).use { output ->
                            input.copyTo(output)
                        }
                    }
                    if (destFile.exists() && destFile.length() > 0) {
                        Uri.fromFile(destFile).toString()
                    } else {
                        imageUri
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to copy image to internal storage: $imageUri", e)
                imageUri
            }
        } else {
            null
        }

        // Run real ML Kit Text Recognition on-device or use fullOcrText passed from UI
        val ocrExtractedText = if (fullOcrText.isNotBlank()) {
            fullOcrText
        } else if (permanentImageUri != null) {
            try {
                MlKitTextExtractor.extractTextFromUri(context, Uri.parse(permanentImageUri))
            } catch (e: Exception) {
                Log.e(TAG, "Failed OCR extraction for image: $permanentImageUri", e)
                ""
            }
        } else {
            ""
        }

        val fullSearchableText = buildString {
            append(title)
            if (amount.isNotBlank()) append("\nAmount: $amount")
            if (dueDate.isNotBlank()) append("\nDue Date: $dueDate")
            if (ocrExtractedText.isNotBlank()) {
                append("\n\nExtracted OCR Text:\n")
                append(ocrExtractedText)
            }
        }

        val finalTitle = title.ifBlank { "Scanned Document" }
        val fullSearchableTextWithEntities = extractAndAppendEntities(finalTitle, fullSearchableText)

        val summaryText = when {
            ocrExtractedText.isNotBlank() -> ocrExtractedText.lines().firstOrNull { it.isNotBlank() }?.take(80) ?: "OCR text recognized on-device"
            amount.isNotBlank() -> "Amount: $amount • Due: $dueDate"
            else -> "Scanned image indexed offline"
        }

        // Deep Entity Parsing & Auto-Reminder Scheduling
        val parsedSummary = com.example.util.DocumentSummaryParser.parse(fullSearchableText, title)
        parsedSummary.dates.firstOrNull()?.let { foundDate ->
            com.example.util.SmartNotificationManager.scheduleDueDateReminder(
                context = context,
                docTitle = finalTitle,
                dueDateStr = foundDate,
                itemId = id
            )
        }

        val entity = MemoryEntity(
            id = id,
            type = "image",
            title = finalTitle,
            extractedText = fullSearchableTextWithEntities,
            imageUri = permanentImageUri,
            createdAt = System.currentTimeMillis(),
            sizeText = if (amount.isNotBlank()) "$amount • Image" else "3.2 MB • Image",
            summary = summaryText,
            subtitle = "Receipt / Document • ML Kit OCR Indexed",
            tag = "Receipt",
            isPinned = false
        )

        memoryDao.insertMemory(entity)
        memoryDao.insertFts(MemoryFtsEntity(id = id, title = finalTitle, extractedText = fullSearchableTextWithEntities))

        // Index in Universal Search
        val isResizer = finalTitle.startsWith("Resized_", ignoreCase = true) || amount.startsWith("Resized to", ignoreCase = true)
        if (isResizer) {
            val dimensionsPattern = Regex("""(\d+)x(\d+)\s*px""")
            val match = dimensionsPattern.find(amount)
            val w = match?.groupValues?.getOrNull(1) ?: "800"
            val h = match?.groupValues?.getOrNull(2) ?: "600"
            val dpiVal = if (amount.contains("DPI", ignoreCase = true)) {
                amount.substringAfter("DPI").substringBefore(" ").trim()
            } else "300 DPI"

            universalSearchRepo.insertOrUpdate(
                id = id,
                module = "Resizer",
                title = "Resized Image: $finalTitle",
                contentText = "Resized Photo\nMetadata: $amount\nFile Name: $finalTitle\nDimensions: $w x $h\nDPI: $dpiVal",
                metadataJson = JSONObject().apply {
                    put("resized_file_name", finalTitle)
                    put("dimensions", "$w x $h")
                    put("preset_type", if (amount.contains("SSC", ignoreCase = true)) "SSC" else if (amount.contains("UPSC", ignoreCase = true)) "UPSC" else "Custom")
                    put("dpi_metadata", dpiVal)
                    put("info", amount)
                }.toString(),
                imageUri = permanentImageUri
            )
        } else {
            universalSearchRepo.insertOrUpdate(
                id = id,
                module = "Image",
                title = finalTitle,
                contentText = fullSearchableTextWithEntities,
                metadataJson = JSONObject().apply {
                    put("amount", amount)
                    put("due_date", dueDate)
                    put("ocr_text", ocrExtractedText)
                }.toString(),
                imageUri = permanentImageUri
            )
        }

        entity.toWorkspaceItem()
    }

    /**
     * Saves a PDF into SQLite memories & FTS4 index.
     * Persists PDF to internal storage and renders real page 1 thumbnail image.
     */
    suspend fun savePdfMemory(
        id: String = "pdf-${System.currentTimeMillis()}",
        title: String,
        fileName: String,
        fileSize: String,
        summary: String,
        keyPoints: List<String>,
        pdfUri: Uri? = null,
        includeInSearch: Boolean = true,
        fullTranscript: String = ""
    ): WorkspaceItem = withContext(Dispatchers.IO) {
        // Persist real uploaded PDF into app internal files
        var permanentPdfFile: File? = null
        if (pdfUri != null) {
            try {
                val docsDir = File(context.filesDir, "vault_documents").apply { mkdirs() }
                permanentPdfFile = File(docsDir, "doc_${id}.pdf")
                context.contentResolver.openInputStream(pdfUri)?.use { input ->
                    FileOutputStream(permanentPdfFile).use { output ->
                        input.copyTo(output)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error copying uploaded PDF to filesDir", e)
            }
        }

        val effectivePdfUri = if (permanentPdfFile != null && permanentPdfFile.exists() && permanentPdfFile.length() > 0) {
            Uri.fromFile(permanentPdfFile)
        } else {
            pdfUri
        }

        val extractedPdfText = if (fullTranscript.isNotBlank()) {
            fullTranscript
        } else if (effectivePdfUri != null) {
            try {
                PdfTextExtractor.extractTextFromPdfUri(context, effectivePdfUri)
            } catch (e: Exception) {
                Log.e(TAG, "Error extracting text from PDF", e)
                ""
            }
        } else {
            ""
        }

        val fullText = buildString {
            append(title)
            append("\n")
            append(summary)
            append("\n")
            append(keyPoints.joinToString("\n"))
            if (extractedPdfText.isNotBlank()) {
                append("\n\nExtracted Pages Text & Full Transcript:\n")
                append(extractedPdfText)
            }
        }

        // Render and save page 1 thumbnail JPEG so Gallery & AI search have a real visual preview
        val thumbnailUriString = if (effectivePdfUri != null) {
            try {
                val pages = PdfPageRenderer.renderPdfPages(context, effectivePdfUri, maxPages = 1)
                val firstPage = pages.firstOrNull()
                if (firstPage != null) {
                    val thumbsDir = File(context.filesDir, "vault_thumbnails").apply { mkdirs() }
                    val thumbFile = File(thumbsDir, "thumb_${id}.jpg")
                    FileOutputStream(thumbFile).use { out ->
                        firstPage.compress(Bitmap.CompressFormat.JPEG, 90, out)
                    }
                    Uri.fromFile(thumbFile).toString()
                } else {
                    effectivePdfUri.toString()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed rendering PDF thumbnail", e)
                effectivePdfUri.toString()
            }
        } else {
            null
        }

        val finalTitle = title.ifBlank { fileName }
        val fullTextWithEntities = extractAndAppendEntities(finalTitle, fullText)

        val entity = MemoryEntity(
            id = id,
            type = "pdf",
            title = finalTitle,
            extractedText = fullTextWithEntities,
            imageUri = thumbnailUriString,
            createdAt = System.currentTimeMillis(),
            sizeText = fileSize.ifBlank { "1.8 MB" },
            summary = summary.ifBlank { "PDF parsed locally on device" },
            subtitle = "PDF Document • Offline FTS4 Index",
            tag = "Document",
            isPinned = false,
            driveFileId = effectivePdfUri?.toString()
        )

        memoryDao.insertMemory(entity)
        memoryDao.insertFts(MemoryFtsEntity(id = id, title = finalTitle, extractedText = fullTextWithEntities))

        // Index in Universal Search
        universalSearchRepo.insertOrUpdate(
            id = id,
            module = "PDF",
            title = finalTitle,
            contentText = fullTextWithEntities,
            metadataJson = JSONObject().apply {
                put("file_name", fileName)
                put("file_size", fileSize)
                put("summary", summary)
                put("key_points", keyPoints.joinToString(","))
                put("pdf_uri", pdfUri?.toString() ?: "")
            }.toString(),
            imageUri = thumbnailUriString
        )

        entity.toWorkspaceItem()
    }

    /**
     * Saves a voice note memory
     */
    suspend fun saveVoiceMemory(
        id: String = "voice-${System.currentTimeMillis()}",
        title: String,
        transcription: String,
        summary: String,
        hasReminder: Boolean
    ): WorkspaceItem = withContext(Dispatchers.IO) {
        val fullText = "$title\n$summary\n$transcription"
        val fullTextWithEntities = extractAndAppendEntities(title, fullText)
        val entity = MemoryEntity(
            id = id,
            type = "voice",
            title = title,
            extractedText = fullTextWithEntities,
            imageUri = null,
            createdAt = System.currentTimeMillis(),
            sizeText = "1m 45s (Audio)",
            summary = summary,
            subtitle = "Voice Note • ${if (hasReminder) "Reminder set" else "Transcribed"}",
            tag = "Voice",
            isPinned = false
        )

        memoryDao.insertMemory(entity)
        memoryDao.insertFts(MemoryFtsEntity(id = id, title = title, extractedText = fullTextWithEntities))
        entity.toWorkspaceItem()
    }

    suspend fun togglePin(item: WorkspaceItem) = withContext(Dispatchers.IO) {
        val existing = memoryDao.getMemoryById(item.id)
        if (existing != null) {
            memoryDao.updateMemory(existing.copy(isPinned = !existing.isPinned))
        }
    }

    suspend fun deleteMemory(id: String) = withContext(Dispatchers.IO) {
        val existing = memoryDao.getMemoryById(id)
        memoryDao.deleteMemoryById(id)
        universalSearchRepo.delete(id)
        if (existing != null) {
            // Clean up files
            try {
                if (!existing.imageUri.isNullOrBlank()) {
                    val uri = Uri.parse(existing.imageUri)
                    if (uri.scheme == "file") File(uri.path ?: "").delete()
                }
                if (!existing.driveFileId.isNullOrBlank()) {
                    val uri = Uri.parse(existing.driveFileId)
                    if (uri.scheme == "file") File(uri.path ?: "").delete()
                }
            } catch (_: Exception) {}
        }
    }

    suspend fun markItemSyncedToDrive(id: String, driveFileId: String? = null) = withContext(Dispatchers.IO) {
        val fileId = driveFileId ?: "drive-${System.currentTimeMillis()}"
        memoryDao.updateSyncStatus(id, true, fileId)
    }

    suspend fun getMemoryById(id: String): MemoryEntity? = withContext(Dispatchers.IO) {
        memoryDao.getMemoryById(id)
    }

    /**
     * Extension to convert MemoryEntity to WorkspaceItem model for UI
     */
    private fun MemoryEntity.toWorkspaceItem(): WorkspaceItem {
        val itemType = when (type.lowercase(Locale.ROOT)) {
            "note" -> ItemType.NOTE
            "pdf" -> ItemType.PDF
            "image" -> ItemType.IMAGE
            "voice" -> ItemType.VOICE
            else -> ItemType.NOTE
        }

        val dateFormatted = try {
            val sdf = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault())
            sdf.format(Date(createdAt))
        } catch (e: Exception) {
            "Just now"
        }

        return WorkspaceItem(
            id = id,
            title = title,
            type = itemType,
            dateModified = dateFormatted,
            sizeText = sizeText.ifBlank { if (itemType == ItemType.NOTE) "Note" else "1.2 MB" },
            summary = summary.ifBlank { extractedText.take(90) },
            subtitle = subtitle.ifBlank { "${itemType.label} • Offline FTS4 Index" },
            isPinned = isPinned,
            tag = tag ?: itemType.label,
            contentSnippet = extractedText,
            imageUri = imageUri,
            isSyncedToDrive = isSyncedToDrive,
            driveFileId = driveFileId
        )
    }
}
