package com.example

import com.example.model.CurrentScreen
import com.example.model.ItemType
import com.example.model.MessageSender
import com.example.ui.GsdcallWorkspaceViewModel
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun verify_clean_initial_empty_state() {
    val viewModel = GsdcallWorkspaceViewModel()
    assertEquals(CurrentScreen.HOME, viewModel.currentScreen.value)
    assertEquals(0, viewModel.recentItems.value.size)
    assertEquals(0, viewModel.importantItems.value.size)
    assertEquals(0, viewModel.chatMessages.value.size)
    assertEquals(0.0, viewModel.storageData.value.usedGb, 0.0001)
    assertEquals(5.0, viewModel.storageData.value.totalGb, 0.0001)
    assertEquals(0.0, viewModel.storageData.value.pdfsGb, 0.0001)
    assertEquals(0.0, viewModel.storageData.value.imagesGb, 0.0001)
    assertEquals(0.0, viewModel.storageData.value.notesGb, 0.0001)
  }

  @Test
  fun verify_add_memory_with_private_document() {
    val viewModel = GsdcallWorkspaceViewModel()
    val initialCount = viewModel.recentItems.value.size
    assertEquals(0, initialCount)

    viewModel.addMemory(
      title = "Passport Scan.pdf",
      type = ItemType.PDF,
      isPrivate = true
    )

    val updatedItems = viewModel.recentItems.value
    assertEquals(1, updatedItems.size)

    val added = updatedItems.first()
    assertEquals("Passport Scan.pdf", added.title)
    assertEquals(ItemType.PDF, added.type)
    assertEquals("Private", added.tag)
    assertTrue(added.summary.contains("Biometric locked"))
    assertTrue(viewModel.storageData.value.usedGb > 0.0)
  }

  @Test
  fun verify_interview_preparation_note_update() {
    val viewModel = GsdcallWorkspaceViewModel()
    val title = "Interview Preparation & System Design"
    val bullets = listOf(
      "- Review RAG architecture and vector database indexing",
      "- Offline-first SQLite local sync logic"
    )

    viewModel.updateNote(title, bullets)

    val updatedItem = viewModel.recentItems.value.firstOrNull {
      it.title.contains("Interview", ignoreCase = true)
    }

    assertNotNull(updatedItem)
    assertEquals("Interview Preparation & System Design", updatedItem!!.title)
    assertTrue(updatedItem.contentSnippet?.contains("Review RAG architecture and vector database indexing") == true)
    assertTrue(updatedItem.contentSnippet?.contains("Offline-first SQLite local sync logic") == true)
  }

  @Test
  fun verify_image_memory_ocr_extraction() {
    val viewModel = GsdcallWorkspaceViewModel()

    viewModel.updateExtractedMemory(
      docName = "Electricity Bill",
      amount = "₹1,240",
      dueDate = "28 Sept",
      includeInSearch = true
    )

    val updatedItem = viewModel.recentItems.value.firstOrNull {
      it.title == "Electricity Bill" || it.type == ItemType.IMAGE
    }

    assertNotNull(updatedItem)
    assertEquals("Electricity Bill", updatedItem!!.title)
    assertTrue(updatedItem.summary.contains("₹1,240"))
    assertTrue(updatedItem.summary.contains("28 Sept"))
    assertTrue(updatedItem.contentSnippet?.contains("Semantic Search: Enabled") == true)
  }

  @Test
  fun verify_voice_memories_recording_and_intent_extraction() {
    val viewModel = GsdcallWorkspaceViewModel()

    val transcription = "Kal Rahul se 5 baje meeting hai."
    val summary = "Meeting with Rahul tomorrow at 5:00 PM"

    viewModel.saveVoiceMemory(
      title = summary,
      transcription = transcription,
      summary = summary,
      hasReminder = true
    )

    val savedVoiceItem = viewModel.recentItems.value.firstOrNull {
      it.type == ItemType.VOICE && it.summary.contains("Rahul")
    }

    assertNotNull(savedVoiceItem)
    assertEquals(ItemType.VOICE, savedVoiceItem!!.type)
    assertTrue(savedVoiceItem.contentSnippet?.contains("Kal Rahul se 5 baje meeting hai.") == true)
    assertTrue(savedVoiceItem.contentSnippet?.contains("Meeting with Rahul tomorrow at 5:00 PM") == true)
    assertTrue(savedVoiceItem.contentSnippet?.contains("#rahul #meeting #5pm") == true)
    assertTrue(savedVoiceItem.contentSnippet?.contains("Tomorrow at 5:00 PM") == true)
    assertEquals("Reminder Set", savedVoiceItem.tag)
  }

  @Test
  fun verify_document_scanner_navigation() {
    val viewModel = GsdcallWorkspaceViewModel()
    assertEquals(CurrentScreen.HOME, viewModel.currentScreen.value)

    viewModel.navigateTo(CurrentScreen.DOCUMENT_SCANNER)
    assertEquals(CurrentScreen.DOCUMENT_SCANNER, viewModel.currentScreen.value)

    viewModel.navigateTo(CurrentScreen.IMAGE_MEMORY)
    assertEquals(CurrentScreen.IMAGE_MEMORY, viewModel.currentScreen.value)

    viewModel.navigateTo(CurrentScreen.AI_SEARCH)
    assertEquals(CurrentScreen.AI_SEARCH, viewModel.currentScreen.value)

    viewModel.navigateTo(CurrentScreen.HOME)
    assertEquals(CurrentScreen.HOME, viewModel.currentScreen.value)
  }

  @Test
  fun verify_notepad_full_note_save_and_navigation() {
    val viewModel = GsdcallWorkspaceViewModel()

    viewModel.navigateTo(CurrentScreen.NOTE_EDITOR)
    assertEquals(CurrentScreen.NOTE_EDITOR, viewModel.currentScreen.value)

    viewModel.saveFullNote(
      title = "Interview Preparation",
      content = "Review RAG architecture and vector database indexing\nOffline-first SQLite local sync logic",
      tags = listOf("#notes", "#work"),
      hasAttachment = true,
      includeInSemanticSearch = true
    )

    val savedNote = viewModel.recentItems.value.firstOrNull {
      it.type == ItemType.NOTE && it.title.contains("Interview")
    }

    assertNotNull(savedNote)
    assertEquals("Interview Preparation", savedNote!!.title)
    assertEquals(ItemType.NOTE, savedNote.type)
    assertTrue(savedNote.sizeText.contains("1 Photo") || savedNote.sizeText.contains("words"))
    assertTrue(savedNote.contentSnippet?.contains("#notes #work") == true)
    assertTrue(savedNote.contentSnippet?.contains("Attached Photo") == true)
    assertTrue(savedNote.contentSnippet?.contains("AI Semantic Search: Enabled") == true)

    viewModel.navigateTo(CurrentScreen.HOME)
    assertEquals(CurrentScreen.HOME, viewModel.currentScreen.value)
  }
}



